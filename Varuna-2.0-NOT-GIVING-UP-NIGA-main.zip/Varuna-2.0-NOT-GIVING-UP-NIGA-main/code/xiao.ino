// ===================================================================
// VARUNA DEBUGGER — ESP32-C3 Seeed XIAO Firmware
// Detachable Debug Circuit for VARUNA Flood Monitoring System
// ===================================================================
//
// HARDWARE:
//   - ESP32-C3 Seeed XIAO
//   - SSD1306 OLED 128x64 (I2C: SDA=GPIO6, SCL=GPIO7)
//   - 5 Push Buttons (UP, DOWN, LEFT, RIGHT, SELECT)
//   - 5 Status LEDs (MPU6050, BMP280, GPS, SIM800L, RTC)
//
// COMMUNICATION:
//   - UART RX from ESP32-S3 debug TX (GPIO20 = RX)
//   - Baud: 115200
//   - Protocol: Line-based text, prefixed with "DBG:"
//
// UI PAGES (navigate with LEFT/RIGHT buttons):
//   Page 0: OVERVIEW  — water height, zone, response, battery
//   Page 1: TILT      — theta, correctedTiltX/Y, OLP
//   Page 2: FLOOD     — zone, response, rate, sustained, peak/min
//   Page 3: PRESSURE  — current, baseline, deviation, submersion
//   Page 4: GPS       — fix, satellites, HDOP, lat, lon
//   Page 5: SIM/COMMS — available, registered, RSSI, SMS queue
//   Page 6: TIMING    — sample/transmit intervals, readings, uptime
//   Page 7: SENSORS   — active sensor, MPU, HCSR04, BMP health
//   Page 8: OBLIGHT   — on/off timing, enabled, state
//   Page 9: SYSTEM    — packets rx, bytes, uptime, free heap
//
// STATUS LEDs (ON = sensor working, OFF = sensor offline):
//   LED 0: MPU6050
//   LED 1: BMP280
//   LED 2: GPS Fix
//   LED 3: SIM800L Registered
//   LED 4: RTC Valid
//
// ===================================================================

#include <Wire.h>

/* ================================================================== */
/* ========== SSD1306 OLED DRIVER (MINIMAL, NO LIBRARY) ============= */
/* ================================================================== */
/*
 * Minimal SSD1306 driver to avoid external library dependency.
 * Supports 128x64 monochrome OLED via I2C.
 * Uses a 768-byte frame buffer (128x64 / 8 = 1024 bytes).
 * Font: built-in 5x7 pixel ASCII font.
 */

#define SSD1306_ADDR        0x3C
#define SSD1306_WIDTH       128
#define SSD1306_HEIGHT      64
#define SSD1306_PAGES       8
#define SSD1306_BUF_SIZE    1024

/* SSD1306 command constants */
#define SSD1306_CMD_DISPLAY_OFF         0xAE
#define SSD1306_CMD_DISPLAY_ON          0xAF
#define SSD1306_CMD_SET_MUX_RATIO       0xA8
#define SSD1306_CMD_SET_DISPLAY_OFFSET  0xD3
#define SSD1306_CMD_SET_START_LINE      0x40
#define SSD1306_CMD_SET_SEG_REMAP       0xA1
#define SSD1306_CMD_SET_COM_SCAN_DEC    0xC8
#define SSD1306_CMD_SET_COM_PINS        0xDA
#define SSD1306_CMD_SET_CONTRAST        0x81
#define SSD1306_CMD_ENTIRE_DISPLAY_RAM  0xA4
#define SSD1306_CMD_SET_NORMAL_DISPLAY  0xA6
#define SSD1306_CMD_SET_DISPLAY_CLK     0xD5
#define SSD1306_CMD_SET_CHARGE_PUMP     0x8D
#define SSD1306_CMD_SET_MEMORY_MODE     0x20
#define SSD1306_CMD_SET_COL_ADDR        0x21
#define SSD1306_CMD_SET_PAGE_ADDR       0x22
#define SSD1306_CMD_DEACTIVATE_SCROLL   0x2E
#define SSD1306_CMD_SET_PRECHARGE       0xD9
#define SSD1306_CMD_SET_VCOMH           0xDB

uint8_t oledBuffer[SSD1306_BUF_SIZE];
boolean oledAvailable = false;

/* 5x7 ASCII font (characters 32-126), stored in PROGMEM */
/* Each character is 5 bytes wide, each byte is a column of 8 pixels */
static const uint8_t font5x7[] PROGMEM = {
    /* Space (32) */
    0x00, 0x00, 0x00, 0x00, 0x00,
    /* ! (33) */
    0x00, 0x00, 0x5F, 0x00, 0x00,
    /* " (34) */
    0x00, 0x07, 0x00, 0x07, 0x00,
    /* # (35) */
    0x14, 0x7F, 0x14, 0x7F, 0x14,
    /* $ (36) */
    0x24, 0x2A, 0x7F, 0x2A, 0x12,
    /* % (37) */
    0x23, 0x13, 0x08, 0x64, 0x62,
    /* & (38) */
    0x36, 0x49, 0x55, 0x22, 0x50,
    /* ' (39) */
    0x00, 0x05, 0x03, 0x00, 0x00,
    /* ( (40) */
    0x00, 0x1C, 0x22, 0x41, 0x00,
    /* ) (41) */
    0x00, 0x41, 0x22, 0x1C, 0x00,
    /* * (42) */
    0x08, 0x2A, 0x1C, 0x2A, 0x08,
    /* + (43) */
    0x08, 0x08, 0x3E, 0x08, 0x08,
    /* , (44) */
    0x00, 0x50, 0x30, 0x00, 0x00,
    /* - (45) */
    0x08, 0x08, 0x08, 0x08, 0x08,
    /* . (46) */
    0x00, 0x60, 0x60, 0x00, 0x00,
    /* / (47) */
    0x20, 0x10, 0x08, 0x04, 0x02,
    /* 0 (48) */
    0x3E, 0x51, 0x49, 0x45, 0x3E,
    /* 1 (49) */
    0x00, 0x42, 0x7F, 0x40, 0x00,
    /* 2 (50) */
    0x42, 0x61, 0x51, 0x49, 0x46,
    /* 3 (51) */
    0x21, 0x41, 0x45, 0x4B, 0x31,
    /* 4 (52) */
    0x18, 0x14, 0x12, 0x7F, 0x10,
    /* 5 (53) */
    0x27, 0x45, 0x45, 0x45, 0x39,
    /* 6 (54) */
    0x3C, 0x4A, 0x49, 0x49, 0x30,
    /* 7 (55) */
    0x01, 0x71, 0x09, 0x05, 0x03,
    /* 8 (56) */
    0x36, 0x49, 0x49, 0x49, 0x36,
    /* 9 (57) */
    0x06, 0x49, 0x49, 0x29, 0x1E,
    /* : (58) */
    0x00, 0x36, 0x36, 0x00, 0x00,
    /* ; (59) */
    0x00, 0x56, 0x36, 0x00, 0x00,
    /* < (60) */
    0x00, 0x08, 0x14, 0x22, 0x41,
    /* = (61) */
    0x14, 0x14, 0x14, 0x14, 0x14,
    /* > (62) */
    0x41, 0x22, 0x14, 0x08, 0x00,
    /* ? (63) */
    0x02, 0x01, 0x51, 0x09, 0x06,
    /* @ (64) */
    0x32, 0x49, 0x79, 0x41, 0x3E,
    /* A (65) */
    0x7E, 0x11, 0x11, 0x11, 0x7E,
    /* B (66) */
    0x7F, 0x49, 0x49, 0x49, 0x36,
    /* C (67) */
    0x3E, 0x41, 0x41, 0x41, 0x22,
    /* D (68) */
    0x7F, 0x41, 0x41, 0x22, 0x1C,
    /* E (69) */
    0x7F, 0x49, 0x49, 0x49, 0x41,
    /* F (70) */
    0x7F, 0x09, 0x09, 0x01, 0x01,
    /* G (71) */
    0x3E, 0x41, 0x41, 0x51, 0x32,
    /* H (72) */
    0x7F, 0x08, 0x08, 0x08, 0x7F,
    /* I (73) */
    0x00, 0x41, 0x7F, 0x41, 0x00,
    /* J (74) */
    0x20, 0x40, 0x41, 0x3F, 0x01,
    /* K (75) */
    0x7F, 0x08, 0x14, 0x22, 0x41,
    /* L (76) */
    0x7F, 0x40, 0x40, 0x40, 0x40,
    /* M (77) */
    0x7F, 0x02, 0x04, 0x02, 0x7F,
    /* N (78) */
    0x7F, 0x04, 0x08, 0x10, 0x7F,
    /* O (79) */
    0x3E, 0x41, 0x41, 0x41, 0x3E,
    /* P (80) */
    0x7F, 0x09, 0x09, 0x09, 0x06,
    /* Q (81) */
    0x3E, 0x41, 0x51, 0x21, 0x5E,
    /* R (82) */
    0x7F, 0x09, 0x19, 0x29, 0x46,
    /* S (83) */
    0x46, 0x49, 0x49, 0x49, 0x31,
    /* T (84) */
    0x01, 0x01, 0x7F, 0x01, 0x01,
    /* U (85) */
    0x3F, 0x40, 0x40, 0x40, 0x3F,
    /* V (86) */
    0x1F, 0x20, 0x40, 0x20, 0x1F,
    /* W (87) */
    0x7F, 0x20, 0x18, 0x20, 0x7F,
    /* X (88) */
    0x63, 0x14, 0x08, 0x14, 0x63,
    /* Y (89) */
    0x03, 0x04, 0x78, 0x04, 0x03,
    /* Z (90) */
    0x61, 0x51, 0x49, 0x45, 0x43,
    /* [ (91) */
    0x00, 0x00, 0x7F, 0x41, 0x41,
    /* \ (92) */
    0x02, 0x04, 0x08, 0x10, 0x20,
    /* ] (93) */
    0x41, 0x41, 0x7F, 0x00, 0x00,
    /* ^ (94) */
    0x04, 0x02, 0x01, 0x02, 0x04,
    /* _ (95) */
    0x40, 0x40, 0x40, 0x40, 0x40,
    /* ` (96) */
    0x00, 0x01, 0x02, 0x04, 0x00,
    /* a (97) */
    0x20, 0x54, 0x54, 0x54, 0x78,
    /* b (98) */
    0x7F, 0x48, 0x44, 0x44, 0x38,
    /* c (99) */
    0x38, 0x44, 0x44, 0x44, 0x20,
    /* d (100) */
    0x38, 0x44, 0x44, 0x48, 0x7F,
    /* e (101) */
    0x38, 0x54, 0x54, 0x54, 0x18,
    /* f (102) */
    0x08, 0x7E, 0x09, 0x01, 0x02,
    /* g (103) */
    0x08, 0x14, 0x54, 0x54, 0x3C,
    /* h (104) */
    0x7F, 0x08, 0x04, 0x04, 0x78,
    /* i (105) */
    0x00, 0x44, 0x7D, 0x40, 0x00,
    /* j (106) */
    0x20, 0x40, 0x44, 0x3D, 0x00,
    /* k (107) */
    0x00, 0x7F, 0x10, 0x28, 0x44,
    /* l (108) */
    0x00, 0x41, 0x7F, 0x40, 0x00,
    /* m (109) */
    0x7C, 0x04, 0x18, 0x04, 0x78,
    /* n (110) */
    0x7C, 0x08, 0x04, 0x04, 0x78,
    /* o (111) */
    0x38, 0x44, 0x44, 0x44, 0x38,
    /* p (112) */
    0x7C, 0x14, 0x14, 0x14, 0x08,
    /* q (113) */
    0x08, 0x14, 0x14, 0x18, 0x7C,
    /* r (114) */
    0x7C, 0x08, 0x04, 0x04, 0x08,
    /* s (115) */
    0x48, 0x54, 0x54, 0x54, 0x20,
    /* t (116) */
    0x04, 0x3F, 0x44, 0x40, 0x20,
    /* u (117) */
    0x3C, 0x40, 0x40, 0x20, 0x7C,
    /* v (118) */
    0x1C, 0x20, 0x40, 0x20, 0x1C,
    /* w (119) */
    0x3C, 0x40, 0x30, 0x40, 0x3C,
    /* x (120) */
    0x44, 0x28, 0x10, 0x28, 0x44,
    /* y (121) */
    0x0C, 0x50, 0x50, 0x50, 0x3C,
    /* z (122) */
    0x44, 0x64, 0x54, 0x4C, 0x44,
    /* { (123) */
    0x00, 0x08, 0x36, 0x41, 0x00,
    /* | (124) */
    0x00, 0x00, 0x7F, 0x00, 0x00,
    /* } (125) */
    0x00, 0x41, 0x36, 0x08, 0x00,
    /* ~ (126) */
    0x10, 0x08, 0x08, 0x10, 0x08
};

/* ================================================================== */
/* ========== PIN DEFINITIONS ======================================= */
/* ================================================================== */

/* OLED I2C pins on Seeed XIAO C3 */
#define OLED_SDA_PIN    6
#define OLED_SCL_PIN    7

/* UART RX from ESP32-S3 debug TX */
#define DEBUG_RX_PIN    20

/* Push button pins (active LOW, use internal pull-up) */
#define BTN_UP_PIN      2
#define BTN_DOWN_PIN    3
#define BTN_LEFT_PIN    4
#define BTN_RIGHT_PIN   5
#define BTN_SELECT_PIN  10

/* Status LED pins (ON = sensor working, OFF = sensor offline) */
#define LED_MPU6050_PIN     8
#define LED_BMP280_PIN      9
#define LED_GPS_PIN         21
#define LED_SIM_PIN         0
#define LED_RTC_PIN         1

#define STATUS_LED_COUNT    5

const int statusLedPins[STATUS_LED_COUNT] = {
    LED_MPU6050_PIN,
    LED_BMP280_PIN,
    LED_GPS_PIN,
    LED_SIM_PIN,
    LED_RTC_PIN
};

/* LED index names for clarity */
#define LED_IDX_MPU6050     0
#define LED_IDX_BMP280      1
#define LED_IDX_GPS         2
#define LED_IDX_SIM         3
#define LED_IDX_RTC         4

/* ================================================================== */
/* ========== TIMING CONSTANTS ====================================== */
/* ================================================================== */

#define BUTTON_DEBOUNCE_MS      200UL
#define OLED_REFRESH_INTERVAL   500UL
#define LED_UPDATE_INTERVAL     1000UL
#define DATA_TIMEOUT_MS         10000UL
#define HEARTBEAT_BLINK_MS      2000UL

/* ================================================================== */
/* ========== UI PAGE DEFINITIONS =================================== */
/* ================================================================== */

#define PAGE_OVERVIEW       0
#define PAGE_TILT           1
#define PAGE_FLOOD          2
#define PAGE_PRESSURE       3
#define PAGE_GPS            4
#define PAGE_SIM            5
#define PAGE_TIMING         6
#define PAGE_SENSORS        7
#define PAGE_OBLIGHT        8
#define PAGE_SYSTEM         9
#define PAGE_COUNT          10

int currentPage = PAGE_OVERVIEW;
int previousPage = -1;

const char *pageNames[PAGE_COUNT] = {
    "OVERVIEW",
    "TILT",
    "FLOOD",
    "PRESSURE",
    "GPS",
    "SIM/COMMS",
    "TIMING",
    "SENSORS",
    "OBLIGHT",
    "SYSTEM"
};

/* ================================================================== */
/* ========== PARSED DATA FROM ESP32-S3 ============================= */
/* ================================================================== */

/* Tilt data */
float dbgTheta = 0;
float dbgTiltX = 0;
float dbgTiltY = 0;

/* Water level data */
float dbgWaterHeight = 0;
float dbgHorizontalDist = 0;
float dbgOlpLength = 0;

/* Flood data */
char dbgZone[16] = "---";
char dbgResponse[16] = "---";
float dbgRate = 0;
boolean dbgSustained = false;
float dbgPeakHeight = 0;
float dbgMinHeight = 0;
int dbgStepDown = 0;

/* Pressure data */
float dbgPressureCur = 0;
float dbgPressureBase = 0;
float dbgPressureDev = 0;
int dbgSubmersion = 0;
float dbgDepth = 0;

/* GPS data */
boolean dbgGpsFix = false;
int dbgGpsSat = 0;
float dbgGpsHdop = 99.9;
char dbgGpsLat[14] = "0.0000";
char dbgGpsLon[14] = "0.0000";

/* SIM data */
boolean dbgSimAvail = false;
boolean dbgSimReg = false;
int dbgSimRssi = 0;
int dbgSmsQueue = 0;

/* Battery */
float dbgBattery = 0;

/* Timing */
unsigned long dbgSampleInterval = 0;
unsigned long dbgTransmitInterval = 0;
int dbgReadings = 0;

/* Sensor health */
char dbgActiveSensor[12] = "---";
boolean dbgMpuHealthy = false;
boolean dbgHcsr04Avail = false;
boolean dbgBmpAvail = false;
boolean dbgRtcValid = false;

/* Obstruction light */
unsigned long dbgObOnMs = 0;
unsigned long dbgObOffMs = 0;
boolean dbgObEnabled = false;
char dbgObState[4] = "OFF";

/* Health / System */
int dbgMpuFails = 0;
unsigned long dbgUptime = 0;

/* Time data */
unsigned long dbgUnixTime = 0;
char dbgDateTime[22] = "----/--/-- --:--:--";

/* Packet statistics */
uint32_t packetsReceived = 0;
uint32_t bytesReceived = 0;
uint32_t parseErrors = 0;
unsigned long lastPacketTime = 0;
boolean dataLinkActive = false;

/* Debug circuit uptime */
unsigned long debugBootTime = 0;

/* ================================================================== */
/* ========== UART RECEIVE BUFFER =================================== */
/* ================================================================== */

#define UART_RX_BUF_SIZE 256
char uartRxBuffer[UART_RX_BUF_SIZE];
int uartRxIdx = 0;

/* ================================================================== */
/* ========== BUTTON STATE ========================================== */
/* ================================================================== */

struct ButtonState
{
    int pin;
    boolean lastState;
    unsigned long lastPressTime;
    boolean pressed;
};

ButtonState buttons[5];

#define BTN_IDX_UP      0
#define BTN_IDX_DOWN    1
#define BTN_IDX_LEFT    2
#define BTN_IDX_RIGHT   3
#define BTN_IDX_SELECT  4

/* ================================================================== */
/* ========== DISPLAY SCROLL STATE ================================== */
/* ================================================================== */

int scrollOffset = 0;
#define MAX_SCROLL 4

/* ================================================================== */
/* ========== OLED DRIVER FUNCTIONS ================================= */
/* ================================================================== */

void oledSendCommand(uint8_t cmd)
{
    Wire.beginTransmission(SSD1306_ADDR);
    Wire.write(0x00);
    Wire.write(cmd);
    Wire.endTransmission();
}

void oledSendCommandList(const uint8_t *cmds, int count)
{
    for (int i = 0; i < count; i++)
    {
        oledSendCommand(cmds[i]);
    }
}

boolean oledInit()
{
    Wire.beginTransmission(SSD1306_ADDR);
    uint8_t err = Wire.endTransmission();
    if (err != 0)
    {
        return false;
    }

    static const uint8_t initCmds[] = {
        SSD1306_CMD_DISPLAY_OFF,
        SSD1306_CMD_SET_DISPLAY_CLK, 0x80,
        SSD1306_CMD_SET_MUX_RATIO, 0x3F,
        SSD1306_CMD_SET_DISPLAY_OFFSET, 0x00,
        SSD1306_CMD_SET_START_LINE,
        SSD1306_CMD_SET_CHARGE_PUMP, 0x14,
        SSD1306_CMD_SET_MEMORY_MODE, 0x00,
        SSD1306_CMD_SET_SEG_REMAP,
        SSD1306_CMD_SET_COM_SCAN_DEC,
        SSD1306_CMD_SET_COM_PINS, 0x12,
        SSD1306_CMD_SET_CONTRAST, 0xCF,
        SSD1306_CMD_SET_PRECHARGE, 0xF1,
        SSD1306_CMD_SET_VCOMH, 0x40,
        SSD1306_CMD_ENTIRE_DISPLAY_RAM,
        SSD1306_CMD_SET_NORMAL_DISPLAY,
        SSD1306_CMD_DEACTIVATE_SCROLL,
        SSD1306_CMD_DISPLAY_ON
    };

    int cmdCount = sizeof(initCmds) / sizeof(initCmds[0]);
    oledSendCommandList(initCmds, cmdCount);

    memset(oledBuffer, 0, SSD1306_BUF_SIZE);

    return true;
}

void oledClear()
{
    memset(oledBuffer, 0, SSD1306_BUF_SIZE);
}

void oledDisplay()
{
    oledSendCommand(SSD1306_CMD_SET_COL_ADDR);
    oledSendCommand(0);
    oledSendCommand(127);
    oledSendCommand(SSD1306_CMD_SET_PAGE_ADDR);
    oledSendCommand(0);
    oledSendCommand(7);

    for (int i = 0; i < SSD1306_BUF_SIZE; i += 16)
    {
        Wire.beginTransmission(SSD1306_ADDR);
        Wire.write(0x40);
        int chunkSize = 16;
        if (i + chunkSize > SSD1306_BUF_SIZE)
        {
            chunkSize = SSD1306_BUF_SIZE - i;
        }
        for (int j = 0; j < chunkSize; j++)
        {
            Wire.write(oledBuffer[i + j]);
        }
        Wire.endTransmission();
    }
}

void oledSetPixel(int x, int y, boolean on)
{
    if (x < 0 || x >= SSD1306_WIDTH || y < 0 || y >= SSD1306_HEIGHT)
    {
        return;
    }

    int page = y / 8;
    int bit = y % 8;
    int idx = page * SSD1306_WIDTH + x;

    if (on)
    {
        oledBuffer[idx] |= (1 << bit);
    }
    else
    {
        oledBuffer[idx] &= ~(1 << bit);
    }
}

void oledDrawChar(int x, int y, char c)
{
    if (c < 32 || c > 126)
    {
        c = ' ';
    }

    int fontIdx = (c - 32) * 5;

    for (int col = 0; col < 5; col++)
    {
        uint8_t colData = pgm_read_byte(&font5x7[fontIdx + col]);
        for (int row = 0; row < 7; row++)
        {
            if (colData & (1 << row))
            {
                oledSetPixel(x + col, y + row, true);
            }
        }
    }
}

void oledDrawString(int x, int y, const char *str)
{
    int curX = x;
    while (*str)
    {
        if (curX + 5 > SSD1306_WIDTH)
        {
            break;
        }
        oledDrawChar(curX, y, *str);
        curX += 6;
        str++;
    }
}

void oledDrawStringInverse(int x, int y, const char *str)
{
    int len = strlen(str);
    int width = len * 6 + 1;
    if (width > SSD1306_WIDTH - x)
    {
        width = SSD1306_WIDTH - x;
    }

    /* Draw filled rectangle behind text */
    for (int px = x; px < x + width; px++)
    {
        for (int py = y; py < y + 8 && py < SSD1306_HEIGHT; py++)
        {
            oledSetPixel(px, py, true);
        }
    }

    /* Draw text in inverse (clear pixels) */
    int curX = x + 1;
    while (*str)
    {
        if (curX + 5 > SSD1306_WIDTH)
        {
            break;
        }

        if (*str >= 32 && *str <= 126)
        {
            int fontIdx = (*str - 32) * 5;
            for (int col = 0; col < 5; col++)
            {
                uint8_t colData = pgm_read_byte(&font5x7[fontIdx + col]);
                for (int row = 0; row < 7; row++)
                {
                    if (colData & (1 << row))
                    {
                        oledSetPixel(curX + col, y + row, false);
                    }
                }
            }
        }
        curX += 6;
        str++;
    }
}

void oledDrawHLine(int x, int y, int width)
{
    for (int i = x; i < x + width && i < SSD1306_WIDTH; i++)
    {
        oledSetPixel(i, y, true);
    }
}

void oledDrawVLine(int x, int y, int height)
{
    for (int i = y; i < y + height && i < SSD1306_HEIGHT; i++)
    {
        oledSetPixel(x, i, true);
    }
}

void oledDrawRect(int x, int y, int w, int h)
{
    oledDrawHLine(x, y, w);
    oledDrawHLine(x, y + h - 1, w);
    oledDrawVLine(x, y, h);
    oledDrawVLine(x + w - 1, y, h);
}

void oledDrawProgressBar(int x, int y, int w, int h, int percent)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;

    oledDrawRect(x, y, w, h);

    int fillWidth = ((w - 2) * percent) / 100;
    for (int px = x + 1; px < x + 1 + fillWidth; px++)
    {
        for (int py = y + 1; py < y + h - 1; py++)
        {
            oledSetPixel(px, py, true);
        }
    }
}

/* ================================================================== */
/* ========== FLOAT TO STRING HELPER ================================ */
/* ================================================================== */

void ftoa(char *buf, int bufSize, float val, int decimals)
{
    if (isnan(val))
    {
        strncpy(buf, "NaN", bufSize - 1);
        buf[bufSize - 1] = '\0';
        return;
    }
    if (isinf(val))
    {
        strncpy(buf, "Inf", bufSize - 1);
        buf[bufSize - 1] = '\0';
        return;
    }

    if (val < 0)
    {
        buf[0] = '-';
        ftoa(buf + 1, bufSize - 1, -val, decimals);
        return;
    }

    long intPart = (long)val;
    float fracPart = val - (float)intPart;

    if (decimals == 0)
    {
        snprintf(buf, bufSize, "%ld", intPart);
    }
    else if (decimals == 1)
    {
        int frac = (int)(fracPart * 10 + 0.5);
        if (frac >= 10) { intPart++; frac = 0; }
        snprintf(buf, bufSize, "%ld.%d", intPart, frac);
    }
    else if (decimals == 2)
    {
        int frac = (int)(fracPart * 100 + 0.5);
        if (frac >= 100) { intPart++; frac = 0; }
        snprintf(buf, bufSize, "%ld.%02d", intPart, frac);
    }
    else
    {
        int frac = (int)(fracPart * 1000 + 0.5);
        if (frac >= 1000) { intPart++; frac = 0; }
        snprintf(buf, bufSize, "%ld.%03d", intPart, frac);
    }
}

/* ================================================================== */
/* ========== PAGE DRAWING FUNCTIONS ================================ */
/* ================================================================== */

void drawTitleBar(const char *title, int pageNum)
{
    char header[22];
    snprintf(header, sizeof(header), " %s [%d/%d]", title, pageNum + 1, PAGE_COUNT);
    oledDrawStringInverse(0, 0, header);

    /* Data link indicator on top-right */
    if (dataLinkActive)
    {
        oledDrawString(116, 0, "RX");
    }
    else
    {
        oledDrawString(116, 0, "--");
    }
}

void drawNavArrows()
{
    /* Left arrow indicator */
    if (currentPage > 0)
    {
        oledDrawString(0, 56, "<");
    }

    /* Right arrow indicator */
    if (currentPage < PAGE_COUNT - 1)
    {
        oledDrawString(122, 56, ">");
    }

    /* Page dots at bottom center */
    int dotStartX = 64 - (PAGE_COUNT * 3);
    for (int i = 0; i < PAGE_COUNT; i++)
    {
        int dotX = dotStartX + i * 6;
        if (i == currentPage)
        {
            /* Filled dot for current page */
            oledSetPixel(dotX, 60, true);
            oledSetPixel(dotX + 1, 60, true);
            oledSetPixel(dotX, 61, true);
            oledSetPixel(dotX + 1, 61, true);
            oledSetPixel(dotX - 1, 60, true);
            oledSetPixel(dotX + 2, 60, true);
            oledSetPixel(dotX - 1, 61, true);
            oledSetPixel(dotX + 2, 61, true);
        }
        else
        {
            /* Small dot for other pages */
            oledSetPixel(dotX, 60, true);
            oledSetPixel(dotX + 1, 60, true);
        }
    }
}

void drawPageOverview()
{
    drawTitleBar("OVERVIEW", PAGE_OVERVIEW);

    char line[22];

    /* Water height - large display */
    char hStr[10];
    ftoa(hStr, sizeof(hStr), dbgWaterHeight, 1);
    snprintf(line, sizeof(line), "WATER: %s cm", hStr);
    oledDrawString(0, 12, line);

    /* Zone */
    snprintf(line, sizeof(line), "ZONE : %s", dbgZone);
    oledDrawString(0, 22, line);

    /* Response level */
    snprintf(line, sizeof(line), "RESP : %s", dbgResponse);
    oledDrawString(0, 32, line);

    /* Battery with progress bar */
    char bStr[6];
    ftoa(bStr, sizeof(bStr), dbgBattery, 0);
    snprintf(line, sizeof(line), "BATT : %s%%", bStr);
    oledDrawString(0, 42, line);
    oledDrawProgressBar(78, 42, 48, 7, (int)dbgBattery);

    drawNavArrows();
}

void drawPageTilt()
{
    drawTitleBar("TILT", PAGE_TILT);

    char line[22];
    char val[10];

    ftoa(val, sizeof(val), dbgTheta, 2);
    snprintf(line, sizeof(line), "Theta : %s deg", val);
    oledDrawString(0, 12, line);

    ftoa(val, sizeof(val), dbgTiltX, 2);
    snprintf(line, sizeof(line), "TiltX : %s", val);
    oledDrawString(0, 22, line);

    ftoa(val, sizeof(val), dbgTiltY, 2);
    snprintf(line, sizeof(line), "TiltY : %s", val);
    oledDrawString(0, 32, line);

    ftoa(val, sizeof(val), dbgOlpLength, 1);
    snprintf(line, sizeof(line), "OLP   : %s cm", val);
    oledDrawString(0, 42, line);

    ftoa(val, sizeof(val), dbgHorizontalDist, 1);
    snprintf(line, sizeof(line), "HDist : %s cm", val);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPageFlood()
{
    drawTitleBar("FLOOD", PAGE_FLOOD);

    char line[22];
    char val[10];

    snprintf(line, sizeof(line), "Zone: %s", dbgZone);
    oledDrawString(0, 12, line);

    snprintf(line, sizeof(line), "Resp: %s", dbgResponse);
    oledDrawString(0, 22, line);

    ftoa(val, sizeof(val), dbgRate, 2);
    snprintf(line, sizeof(line), "Rate: %s/15m", val);
    oledDrawString(0, 32, line);

    snprintf(line, sizeof(line), "Sust: %s  SD:%d",
             dbgSustained ? "YES" : "NO", dbgStepDown);
    oledDrawString(0, 42, line);

    ftoa(val, sizeof(val), dbgPeakHeight, 1);
    snprintf(line, sizeof(line), "Peak: %s cm", val);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPagePressure()
{
    drawTitleBar("PRESSURE", PAGE_PRESSURE);

    char line[22];
    char val[10];

    ftoa(val, sizeof(val), dbgPressureCur, 1);
    snprintf(line, sizeof(line), "Cur : %s hPa", val);
    oledDrawString(0, 12, line);

    ftoa(val, sizeof(val), dbgPressureBase, 1);
    snprintf(line, sizeof(line), "Base: %s hPa", val);
    oledDrawString(0, 22, line);

    ftoa(val, sizeof(val), dbgPressureDev, 2);
    snprintf(line, sizeof(line), "Dev : %s hPa", val);
    oledDrawString(0, 32, line);

    snprintf(line, sizeof(line), "Sub : %d", dbgSubmersion);
    oledDrawString(0, 42, line);

    ftoa(val, sizeof(val), dbgDepth, 1);
    snprintf(line, sizeof(line), "Depth: %s cm", val);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPageGps()
{
    drawTitleBar("GPS", PAGE_GPS);

    char line[22];

    snprintf(line, sizeof(line), "Fix : %s", dbgGpsFix ? "YES" : "NO");
    oledDrawString(0, 12, line);

    snprintf(line, sizeof(line), "Sat : %d", dbgGpsSat);
    oledDrawString(0, 22, line);

    char hdStr[8];
    ftoa(hdStr, sizeof(hdStr), dbgGpsHdop, 1);
    snprintf(line, sizeof(line), "HDOP: %s", hdStr);
    oledDrawString(0, 32, line);

    snprintf(line, sizeof(line), "Lat: %s", dbgGpsLat);
    oledDrawString(0, 42, line);

    snprintf(line, sizeof(line), "Lon: %s", dbgGpsLon);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPageSim()
{
    drawTitleBar("SIM/COMMS", PAGE_SIM);

    char line[22];

    snprintf(line, sizeof(line), "Avail: %s",
             dbgSimAvail ? "YES" : "NO");
    oledDrawString(0, 12, line);

    snprintf(line, sizeof(line), "Reg  : %s",
             dbgSimReg ? "YES" : "NO");
    oledDrawString(0, 22, line);

    snprintf(line, sizeof(line), "RSSI : %d", dbgSimRssi);
    oledDrawString(0, 32, line);

    /* Signal strength bar */
    int signalPercent = 0;
    if (dbgSimRssi > 0 && dbgSimRssi <= 31)
    {
        signalPercent = (dbgSimRssi * 100) / 31;
    }
    oledDrawProgressBar(66, 32, 60, 7, signalPercent);

    snprintf(line, sizeof(line), "Queue: %d SMS", dbgSmsQueue);
    oledDrawString(0, 42, line);

    /* Signal quality description */
    const char *sigQual = "NONE";
    if (dbgSimRssi >= 20) sigQual = "EXCELLENT";
    else if (dbgSimRssi >= 15) sigQual = "GOOD";
    else if (dbgSimRssi >= 10) sigQual = "OK";
    else if (dbgSimRssi >= 2) sigQual = "WEAK";

    snprintf(line, sizeof(line), "Qual : %s", sigQual);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPageTiming()
{
    drawTitleBar("TIMING", PAGE_TIMING);

    char line[22];

    snprintf(line, sizeof(line), "Sample: %lus",
             dbgSampleInterval);
    oledDrawString(0, 12, line);

    snprintf(line, sizeof(line), "Tx    : %lus",
             dbgTransmitInterval);
    oledDrawString(0, 22, line);

    snprintf(line, sizeof(line), "Reads : %d", dbgReadings);
    oledDrawString(0, 32, line);

    /* Uptime formatting */
    unsigned long uptimeSec = dbgUptime;
    unsigned long uptimeHrs = uptimeSec / 3600;
    unsigned long uptimeMins = (uptimeSec % 3600) / 60;
    unsigned long uptimeS = uptimeSec % 60;
    snprintf(line, sizeof(line), "Up: %02lu:%02lu:%02lu",
             uptimeHrs, uptimeMins, uptimeS);
    oledDrawString(0, 42, line);

    /* Date/time from S3 */
    oledDrawString(0, 52, dbgDateTime);

    drawNavArrows();
}

void drawPageSensors()
{
    drawTitleBar("SENSORS", PAGE_SENSORS);

    char line[22];

    snprintf(line, sizeof(line), "Active: %s", dbgActiveSensor);
    oledDrawString(0, 12, line);

    snprintf(line, sizeof(line), "MPU  : %s  F:%d",
             dbgMpuHealthy ? "OK" : "FAIL", dbgMpuFails);
    oledDrawString(0, 22, line);

    snprintf(line, sizeof(line), "BMP  : %s",
             dbgBmpAvail ? "OK" : "FAIL");
    oledDrawString(0, 32, line);

    snprintf(line, sizeof(line), "HCSR4: %s",
             dbgHcsr04Avail ? "OK" : "N/A");
    oledDrawString(0, 42, line);

    snprintf(line, sizeof(line), "RTC  : %s",
             dbgRtcValid ? "OK" : "FAIL");
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPageOblight()
{
    drawTitleBar("OBLIGHT", PAGE_OBLIGHT);

    char line[22];

    snprintf(line, sizeof(line), "Enable: %s",
             dbgObEnabled ? "YES" : "NO");
    oledDrawString(0, 12, line);

    snprintf(line, sizeof(line), "State : %s", dbgObState);
    oledDrawString(0, 22, line);

    snprintf(line, sizeof(line), "ON  : %lu ms", dbgObOnMs);
    oledDrawString(0, 32, line);

    snprintf(line, sizeof(line), "OFF : %lu ms", dbgObOffMs);
    oledDrawString(0, 42, line);

    unsigned long period = dbgObOnMs + dbgObOffMs;
    float duty = 0;
    if (period > 0)
    {
        duty = ((float)dbgObOnMs / (float)period) * 100.0;
    }
    char dStr[8];
    ftoa(dStr, sizeof(dStr), duty, 1);
    snprintf(line, sizeof(line), "Duty: %s%%  P:%lums", dStr, period);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawPageSystem()
{
    drawTitleBar("SYSTEM", PAGE_SYSTEM);

    char line[22];

    snprintf(line, sizeof(line), "Pkts: %lu",
             (unsigned long)packetsReceived);
    oledDrawString(0, 12, line);

    /* Bytes received in KB */
    float kbReceived = (float)bytesReceived / 1024.0;
    char kbStr[8];
    ftoa(kbStr, sizeof(kbStr), kbReceived, 1);
    snprintf(line, sizeof(line), "Data: %s KB", kbStr);
    oledDrawString(0, 22, line);

    snprintf(line, sizeof(line), "Errs: %lu",
             (unsigned long)parseErrors);
    oledDrawString(0, 32, line);

    /* Link status */
    snprintf(line, sizeof(line), "Link: %s",
             dataLinkActive ? "CONNECTED" : "NO DATA");
    oledDrawString(0, 42, line);

    /* Free heap */
    uint32_t freeHeap = ESP.getFreeHeap();
    snprintf(line, sizeof(line), "Heap: %lu B",
             (unsigned long)freeHeap);
    oledDrawString(0, 52, line);

    drawNavArrows();
}

void drawCurrentPage()
{
    oledClear();

    switch (currentPage)
    {
        case PAGE_OVERVIEW:
            drawPageOverview();
            break;
        case PAGE_TILT:
            drawPageTilt();
            break;
        case PAGE_FLOOD:
            drawPageFlood();
            break;
        case PAGE_PRESSURE:
            drawPagePressure();
            break;
        case PAGE_GPS:
            drawPageGps();
            break;
        case PAGE_SIM:
            drawPageSim();
            break;
        case PAGE_TIMING:
            drawPageTiming();
            break;
        case PAGE_SENSORS:
            drawPageSensors();
            break;
        case PAGE_OBLIGHT:
            drawPageOblight();
            break;
        case PAGE_SYSTEM:
            drawPageSystem();
            break;
        default:
            drawPageOverview();
            break;
    }

    oledDisplay();
}

/* ================================================================== */
/* ========== BUTTON HANDLING ======================================= */
/* ================================================================== */

void buttonsInit()
{
    buttons[BTN_IDX_UP].pin = BTN_UP_PIN;
    buttons[BTN_IDX_DOWN].pin = BTN_DOWN_PIN;
    buttons[BTN_IDX_LEFT].pin = BTN_LEFT_PIN;
    buttons[BTN_IDX_RIGHT].pin = BTN_RIGHT_PIN;
    buttons[BTN_IDX_SELECT].pin = BTN_SELECT_PIN;

    for (int i = 0; i < 5; i++)
    {
        pinMode(buttons[i].pin, INPUT_PULLUP);
        buttons[i].lastState = HIGH;
        buttons[i].lastPressTime = 0;
        buttons[i].pressed = false;
    }
}

void buttonsUpdate(unsigned long now)
{
    for (int i = 0; i < 5; i++)
    {
        buttons[i].pressed = false;

        boolean currentState = digitalRead(buttons[i].pin);

        /* Detect falling edge (press) with debounce */
        if (buttons[i].lastState == HIGH && currentState == LOW)
        {
            if (now - buttons[i].lastPressTime >= BUTTON_DEBOUNCE_MS)
            {
                buttons[i].pressed = true;
                buttons[i].lastPressTime = now;
            }
        }

        buttons[i].lastState = currentState;
    }
}

void handleButtons()
{
    /* LEFT — previous page */
    if (buttons[BTN_IDX_LEFT].pressed)
    {
        if (currentPage > 0)
        {
            currentPage--;
            scrollOffset = 0;
        }
        else
        {
            currentPage = PAGE_COUNT - 1;
        }
    }

    /* RIGHT — next page */
    if (buttons[BTN_IDX_RIGHT].pressed)
    {
        if (currentPage < PAGE_COUNT - 1)
        {
            currentPage++;
            scrollOffset = 0;
        }
        else
        {
            currentPage = 0;
        }
    }

    /* UP — scroll up (for future scrollable content) */
    if (buttons[BTN_IDX_UP].pressed)
    {
        if (scrollOffset > 0)
        {
            scrollOffset--;
        }
    }

    /* DOWN — scroll down */
    if (buttons[BTN_IDX_DOWN].pressed)
    {
        if (scrollOffset < MAX_SCROLL)
        {
            scrollOffset++;
        }
    }

    /* SELECT — toggle between overview and current page detail */
    if (buttons[BTN_IDX_SELECT].pressed)
    {
        if (currentPage != PAGE_OVERVIEW)
        {
            previousPage = currentPage;
            currentPage = PAGE_OVERVIEW;
        }
        else if (previousPage >= 0 && previousPage < PAGE_COUNT)
        {
            currentPage = previousPage;
        }
    }
}

/* ================================================================== */
/* ========== STATUS LED UPDATE ===================================== */
/* ================================================================== */

void statusLedsInit()
{
    for (int i = 0; i < STATUS_LED_COUNT; i++)
    {
        pinMode(statusLedPins[i], OUTPUT);
        digitalWrite(statusLedPins[i], LOW);
    }
}

void statusLedsUpdate()
{
    /* LED 0: MPU6050 — ON if healthy */
    digitalWrite(statusLedPins[LED_IDX_MPU6050],
                 dbgMpuHealthy ? HIGH : LOW);

    /* LED 1: BMP280 — ON if available */
    digitalWrite(statusLedPins[LED_IDX_BMP280],
                 dbgBmpAvail ? HIGH : LOW);

    /* LED 2: GPS — ON if fix valid */
    digitalWrite(statusLedPins[LED_IDX_GPS],
                 dbgGpsFix ? HIGH : LOW);

    /* LED 3: SIM800L — ON if registered */
    digitalWrite(statusLedPins[LED_IDX_SIM],
                 dbgSimReg ? HIGH : LOW);

    /* LED 4: RTC — ON if time valid */
    digitalWrite(statusLedPins[LED_IDX_RTC],
                 dbgRtcValid ? HIGH : LOW);
}

/* ================================================================== */
/* ========== DATA PARSER =========================================== */
/* ================================================================== */

/*
 * Parses a single "DBG:" prefixed line from the ESP32-S3.
 *
 * Format examples:
 *   DBG:PKT_START:42
 *   DBG:TIME:1706000000:2024-01-23 12:00:00
 *   DBG:TILT:THETA=12.34:TX=1.23:TY=-0.45
 *   DBG:WATER:HEIGHT=45.67:HDIST=12.3:OLP=100.0
 *   DBG:FLOOD:ZONE=WARNING:RESP=FLOOD ALERT:RATE=3.456:SUST=YES
 *   DBG:FLOOD:PEAK=123.4:MIN=10.2:STEPDN=2
 *   DBG:PRESSURE:CUR=1013.25:BASE=1013.00:DEV=0.25:SUB=0:DEPTH=0.00
 *   DBG:GPS:FIX=1:SAT=8:HDOP=1.2
 *   DBG:SIM:AVAIL=1:REG=1:RSSI=15:QUEUE=0
 *   DBG:BATT:85.3%
 *   DBG:TIMING:SAMPLE=300s:TX=300s:READINGS=42
 *   DBG:SENSOR:MPU6050:MPU=1:HCSR04=0
 *   DBG:OBLIGHT:ON=500ms:OFF=3500ms:STATE=OFF:EN=1
 *   DBG:HEALTH:MPU_FAILS=0:UPTIME=3600s:BMP=1:RTC=1
 *   DBG:PKT_END
 *   DBG:EVENT:<event_string>
 *   DBG:CAL:<phase>:<progress>/<total>
 */

/* Helper: find value after "KEY=" in a string, return pointer or NULL */
const char *findField(const char *line, const char *key)
{
    const char *pos = strstr(line, key);
    if (pos == NULL)
    {
        return NULL;
    }
    return pos + strlen(key);
}

/* Helper: extract float value after key */
float extractFloat(const char *line, const char *key, float defaultVal)
{
    const char *val = findField(line, key);
    if (val == NULL)
    {
        return defaultVal;
    }
    return atof(val);
}

/* Helper: extract int value after key */
int extractInt(const char *line, const char *key, int defaultVal)
{
    const char *val = findField(line, key);
    if (val == NULL)
    {
        return defaultVal;
    }
    return atoi(val);
}

/* Helper: extract string value after key into buffer, delimited by : or end */
void extractStr(const char *line, const char *key, char *buf, int bufSize)
{
    const char *val = findField(line, key);
    if (val == NULL)
    {
        return;
    }

    int i = 0;
    while (val[i] != '\0' && val[i] != ':' && val[i] != '\r' &&
            val[i] != '\n' && i < bufSize - 1)
    {
        buf[i] = val[i];
        i++;
    }
    buf[i] = '\0';
}

/* Helper: extract unsigned long after key (strips trailing non-digits) */
unsigned long extractUlong(const char *line, const char *key, unsigned long defaultVal)
{
    const char *val = findField(line, key);
    if (val == NULL)
    {
        return defaultVal;
    }
    return strtoul(val, NULL, 10);
}

void parseDebugLine(const char *line)
{
    /* Must start with "DBG:" */
    if (strncmp(line, "DBG:", 4) != 0)
    {
        return;
    }

    const char *payload = line + 4;

    /* PKT_START */
    if (strncmp(payload, "PKT_START:", 10) == 0)
    {
        packetsReceived++;
        lastPacketTime = millis();
        dataLinkActive = true;
        return;
    }

    /* PKT_END */
    if (strcmp(payload, "PKT_END") == 0)
    {
        return;
    }

    /* TIME line */
    if (strncmp(payload, "TIME:", 5) == 0)
    {
        const char *timeData = payload + 5;
        dbgUnixTime = strtoul(timeData, NULL, 10);

        const char *colon = strchr(timeData, ':');
        if (colon != NULL)
        {
            strncpy(dbgDateTime, colon + 1, sizeof(dbgDateTime) - 1);
            dbgDateTime[sizeof(dbgDateTime) - 1] = '\0';
            /* Trim trailing whitespace */
            int len = strlen(dbgDateTime);
            while (len > 0 && (dbgDateTime[len - 1] == '\r' ||
                               dbgDateTime[len - 1] == '\n' ||
                               dbgDateTime[len - 1] == ' '))
            {
                dbgDateTime[--len] = '\0';
            }
        }
        return;
    }

    /* TILT line */
    if (strncmp(payload, "TILT:", 5) == 0)
    {
        dbgTheta = extractFloat(payload, "THETA=", dbgTheta);
        dbgTiltX = extractFloat(payload, "TX=", dbgTiltX);
        dbgTiltY = extractFloat(payload, "TY=", dbgTiltY);
        return;
    }

    /* WATER line */
    if (strncmp(payload, "WATER:", 6) == 0)
    {
        dbgWaterHeight = extractFloat(payload, "HEIGHT=", dbgWaterHeight);
        dbgHorizontalDist = extractFloat(payload, "HDIST=", dbgHorizontalDist);
        dbgOlpLength = extractFloat(payload, "OLP=", dbgOlpLength);
        return;
    }

    /* FLOOD line (two variants) */
    if (strncmp(payload, "FLOOD:", 6) == 0)
    {
        /* Check which variant */
        if (strstr(payload, "ZONE=") != NULL)
        {
            extractStr(payload, "ZONE=", dbgZone, sizeof(dbgZone));
            extractStr(payload, "RESP=", dbgResponse, sizeof(dbgResponse));
            dbgRate = extractFloat(payload, "RATE=", dbgRate);

            const char *sustVal = findField(payload, "SUST=");
            if (sustVal != NULL)
            {
                dbgSustained = (sustVal[0] == 'Y' || sustVal[0] == 'y');
            }
        }
        else if (strstr(payload, "PEAK=") != NULL)
        {
            dbgPeakHeight = extractFloat(payload, "PEAK=", dbgPeakHeight);
            dbgMinHeight = extractFloat(payload, "MIN=", dbgMinHeight);
            dbgStepDown = extractInt(payload, "STEPDN=", dbgStepDown);
        }
        return;
    }

    /* PRESSURE line */
    if (strncmp(payload, "PRESSURE:", 9) == 0)
    {
        dbgPressureCur = extractFloat(payload, "CUR=", dbgPressureCur);
        dbgPressureBase = extractFloat(payload, "BASE=", dbgPressureBase);
        dbgPressureDev = extractFloat(payload, "DEV=", dbgPressureDev);
        dbgSubmersion = extractInt(payload, "SUB=", dbgSubmersion);
        dbgDepth = extractFloat(payload, "DEPTH=", dbgDepth);
        return;
    }

    /* GPS line */
    if (strncmp(payload, "GPS:", 4) == 0)
    {
        int fixVal = extractInt(payload, "FIX=", dbgGpsFix ? 1 : 0);
        dbgGpsFix = (fixVal != 0);
        dbgGpsSat = extractInt(payload, "SAT=", dbgGpsSat);

        /* HDOP might be stored as integer * 10 or as float */
        const char *hdopVal = findField(payload, "HDOP=");
        if (hdopVal != NULL)
        {
            dbgGpsHdop = atof(hdopVal);
        }

        /* Lat/Lon if present in GPS line (from periodic packet, not always) */
        const char *latVal = findField(payload, "LAT=");
        if (latVal != NULL)
        {
            int i = 0;
            while (latVal[i] != '\0' && latVal[i] != ':' && i < 13)
            {
                dbgGpsLat[i] = latVal[i];
                i++;
            }
            dbgGpsLat[i] = '\0';
        }

        const char *lonVal = findField(payload, "LON=");
        if (lonVal != NULL)
        {
            int i = 0;
            while (lonVal[i] != '\0' && lonVal[i] != ':' &&
                    lonVal[i] != '\r' && lonVal[i] != '\n' && i < 13)
            {
                dbgGpsLon[i] = lonVal[i];
                i++;
            }
            dbgGpsLon[i] = '\0';
        }

        return;
    }

    /* SIM line */
    if (strncmp(payload, "SIM:", 4) == 0)
    {
        int availVal = extractInt(payload, "AVAIL=", dbgSimAvail ? 1 : 0);
        dbgSimAvail = (availVal != 0);
        int regVal = extractInt(payload, "REG=", dbgSimReg ? 1 : 0);
        dbgSimReg = (regVal != 0);
        dbgSimRssi = extractInt(payload, "RSSI=", dbgSimRssi);
        dbgSmsQueue = extractInt(payload, "QUEUE=", dbgSmsQueue);
        return;
    }

    /* BATT line */
    if (strncmp(payload, "BATT:", 5) == 0)
    {
        dbgBattery = atof(payload + 5);
        return;
    }

    /* TIMING line */
    if (strncmp(payload, "TIMING:", 7) == 0)
    {
        dbgSampleInterval = extractUlong(payload, "SAMPLE=", dbgSampleInterval);
        dbgTransmitInterval = extractUlong(payload, "TX=", dbgTransmitInterval);
        dbgReadings = extractInt(payload, "READINGS=", dbgReadings);
        return;
    }

    /* SENSOR line */
    if (strncmp(payload, "SENSOR:", 7) == 0)
    {
        /* Format: DBG:SENSOR:<active>:MPU=<0|1>:HCSR04=<0|1> */
        const char *sensorPayload = payload + 7;

        /* Extract active sensor name (up to first ':') */
        int i = 0;
        while (sensorPayload[i] != '\0' && sensorPayload[i] != ':' &&
                i < (int)sizeof(dbgActiveSensor) - 1)
        {
            dbgActiveSensor[i] = sensorPayload[i];
            i++;
        }
        dbgActiveSensor[i] = '\0';

        int mpuVal = extractInt(payload, "MPU=", dbgMpuHealthy ? 1 : 0);
        dbgMpuHealthy = (mpuVal != 0);
        int hcVal = extractInt(payload, "HCSR04=", dbgHcsr04Avail ? 1 : 0);
        dbgHcsr04Avail = (hcVal != 0);
        return;
    }

    /* OBLIGHT line */
    if (strncmp(payload, "OBLIGHT:", 8) == 0)
    {
        dbgObOnMs = extractUlong(payload, "ON=", dbgObOnMs);
        dbgObOffMs = extractUlong(payload, "OFF=", dbgObOffMs);
        extractStr(payload, "STATE=", dbgObState, sizeof(dbgObState));

        int enVal = extractInt(payload, "EN=", dbgObEnabled ? 1 : 0);
        dbgObEnabled = (enVal != 0);
        return;
    }

    /* HEALTH line */
    if (strncmp(payload, "HEALTH:", 7) == 0)
    {
        dbgMpuFails = extractInt(payload, "MPU_FAILS=", dbgMpuFails);
        dbgUptime = extractUlong(payload, "UPTIME=", dbgUptime);

        int bmpVal = extractInt(payload, "BMP=", dbgBmpAvail ? 1 : 0);
        dbgBmpAvail = (bmpVal != 0);
        int rtcVal = extractInt(payload, "RTC=", dbgRtcValid ? 1 : 0);
        dbgRtcValid = (rtcVal != 0);
        return;
    }

    /* EVENT line */
    if (strncmp(payload, "EVENT:", 6) == 0)
    {
        /* Events are logged but not stored persistently on the debugger */
        /* Could add an event log page in future */
        return;
    }

    /* CAL line */
    if (strncmp(payload, "CAL:", 4) == 0)
    {
        /* Calibration progress — could show on OLED in future */
        return;
    }

    /* HANDSHAKE */
    if (strncmp(payload, "HANDSHAKE:", 10) == 0)
    {
        dataLinkActive = true;
        lastPacketTime = millis();
        return;
    }

    /* STATUS line */
    if (strncmp(payload, "STATUS:", 7) == 0)
    {
        return;
    }

    /* FLOOD_TRANS line */
    if (strncmp(payload, "FLOOD_TRANS:", 12) == 0)
    {
        return;
    }

    /* ALERT_DISPATCH line */
    if (strncmp(payload, "ALERT_DISPATCH:", 15) == 0)
    {
        return;
    }

    /* Unknown DBG line — count as parse note but not error */
}

/* ================================================================== */
/* ========== UART RECEIVE HANDLER ================================== */
/* ================================================================== */

void processUartInput()
{
    while (Serial1.available())
    {
        char c = Serial1.read();
        bytesReceived++;

        if (c == '\n' || c == '\r')
        {
            if (uartRxIdx > 0)
            {
                uartRxBuffer[uartRxIdx] = '\0';

                /* Parse the complete line */
                parseDebugLine(uartRxBuffer);

                uartRxIdx = 0;
            }
        }
        else
        {
            if (uartRxIdx < UART_RX_BUF_SIZE - 1)
            {
                uartRxBuffer[uartRxIdx++] = c;
            }
            else
            {
                /* Buffer overflow — discard and reset */
                uartRxIdx = 0;
                parseErrors++;
            }
        }
    }
}

/* ================================================================== */
/* ========== DATA LINK TIMEOUT CHECK =============================== */
/* ================================================================== */

void checkDataLinkTimeout(unsigned long now)
{
    if (dataLinkActive)
    {
        if (now - lastPacketTime > DATA_TIMEOUT_MS)
        {
            dataLinkActive = false;
        }
    }
}

/* ================================================================== */
/* ========== SPLASH SCREEN ========================================= */
/* ================================================================== */

void drawSplashScreen()
{
    oledClear();

    oledDrawString(22, 8,  "VARUNA DEBUG");
    oledDrawHLine(10, 18, 108);

    oledDrawString(16, 24, "Flood Monitor");
    oledDrawString(22, 34, "Debug System");

    oledDrawString(40, 48, "v1.0");
    oledDrawString(10, 56, "Waiting for S3...");

    oledDisplay();
}

/* ================================================================== */
/* ========== NO DATA SCREEN ======================================== */
/* ================================================================== */

void drawNoDataOverlay(unsigned long now)
{
    /* If no data for a while, show blinking "NO DATA" */
    if (!dataLinkActive)
    {
        boolean showWarning = ((now / 1000) % 2) == 0;
        if (showWarning)
        {
            oledDrawStringInverse(28, 28, " NO DATA LINK ");
        }
    }
}

/* ================================================================== */
/* ========== SETUP ================================================= */
/* ================================================================== */

void setup()
{
    /* USB Serial for local debug output from XIAO itself */
    Serial.begin(115200);

    /* UART1 for receiving debug data from ESP32-S3 */
    Serial1.begin(115200, SERIAL_8N1, DEBUG_RX_PIN, -1);

    /* I2C for OLED */
    Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
    Wire.setClock(400000);

    /* Initialize buttons */
    buttonsInit();

    /* Initialize status LEDs */
    statusLedsInit();

    /* Initialize OLED */
    delay(100);
    oledAvailable = oledInit();

    if (oledAvailable)
    {
        Serial.println("XIAO_DBG:OLED_OK");
        drawSplashScreen();
    }
    else
    {
        Serial.println("XIAO_DBG:OLED_FAIL");
    }

    /* Blink all LEDs once as startup test */
    for (int i = 0; i < STATUS_LED_COUNT; i++)
    {
        digitalWrite(statusLedPins[i], HIGH);
    }
    delay(500);
    for (int i = 0; i < STATUS_LED_COUNT; i++)
    {
        digitalWrite(statusLedPins[i], LOW);
    }

    debugBootTime = millis();
    lastPacketTime = 0;
    dataLinkActive = false;
    packetsReceived = 0;
    bytesReceived = 0;
    parseErrors = 0;
    currentPage = PAGE_OVERVIEW;
    previousPage = -1;
    scrollOffset = 0;
    uartRxIdx = 0;

    Serial.println("XIAO_DBG:READY");
    Serial.print("XIAO_DBG:RX_PIN=");
    Serial.println(DEBUG_RX_PIN);
    Serial.print("XIAO_DBG:OLED_SDA=");
    Serial.println(OLED_SDA_PIN);
    Serial.print("XIAO_DBG:OLED_SCL=");
    Serial.println(OLED_SCL_PIN);
    Serial.println("XIAO_DBG:WAITING_FOR_ESP32_S3_DATA");

    delay(2000);
}

/* ================================================================== */
/* ========== MAIN LOOP ============================================= */
/* ================================================================== */

void loop()
{
    unsigned long now = millis();

    /* ---- RECEIVE AND PARSE UART DATA FROM ESP32-S3 ---- */
    processUartInput();

    /* ---- CHECK DATA LINK TIMEOUT ---- */
    checkDataLinkTimeout(now);

    /* ---- READ BUTTONS ---- */
    buttonsUpdate(now);
    handleButtons();

    /* ---- UPDATE STATUS LEDS ---- */
    static unsigned long lastLedUpdate = 0;
    if (now - lastLedUpdate >= LED_UPDATE_INTERVAL)
    {
        lastLedUpdate = now;
        statusLedsUpdate();
    }

    /* ---- UPDATE OLED DISPLAY ---- */
    static unsigned long lastOledRefresh = 0;
    if (oledAvailable && (now - lastOledRefresh >= OLED_REFRESH_INTERVAL))
    {
        lastOledRefresh = now;
        drawCurrentPage();

        /* Overlay "NO DATA" warning if link is down */
        if (!dataLinkActive && packetsReceived > 0)
        {
            /* Only show after we had data before (not on first boot) */
            boolean showWarning = ((now / 800) % 2) == 0;
            if (showWarning)
            {
                /* Redraw with warning overlay */
                oledClear();
                drawCurrentPage();

                /* Draw warning box in center */
                for (int px = 16; px < 112; px++)
                {
                    for (int py = 24; py < 40; py++)
                    {
                        oledSetPixel(px, py, false);
                    }
                }
                oledDrawRect(16, 24, 96, 16);
                oledDrawString(20, 28, "! NO DATA LINK !");
                oledDisplay();
            }
        }
        else if (!dataLinkActive && packetsReceived == 0)
        {
            /* Still waiting for first connection — show on overview */
            if (currentPage == PAGE_OVERVIEW)
            {
                boolean showDots = ((now / 500) % 2) == 0;
                if (showDots)
                {
                    oledDrawString(10, 52, "Waiting for S3...");
                }
                else
                {
                    oledDrawString(10, 52, "Waiting for S3   ");
                }
                oledDisplay();
            }
        }
    }

    /* ---- SERIAL DEBUG OUTPUT FROM XIAO ---- */
    static unsigned long lastXiaoSerial = 0;
    if (now - lastXiaoSerial >= 5000UL)
    {
        lastXiaoSerial = now;

        Serial.print("XIAO_DBG:LINK=");
        Serial.print(dataLinkActive ? "UP" : "DOWN");
        Serial.print(" PKTS=");
        Serial.print(packetsReceived);
        Serial.print(" PAGE=");
        Serial.print(pageNames[currentPage]);
        Serial.print(" HEAP=");
        Serial.println(ESP.getFreeHeap());
    }

    /* Small delay to prevent busy-loop */
    delay(10);
}
