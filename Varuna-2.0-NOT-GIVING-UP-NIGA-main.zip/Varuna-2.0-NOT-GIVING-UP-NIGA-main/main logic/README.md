
# VARUNA — Core Algorithm Documentation

## SYSTEM 1: Dual-Threshold Flood Detection with Sustained-Rise Confirmation

---

### 1.1 Why Rate-Only Detection Fails

A single-factor trigger based on rate of change is broken in both directions.

**False Positive Scenario:**
A dry riverbed in Rajasthan sits at 8cm. Sudden monsoon rain upstream causes rapid inflow. Water rises from 8cm to 28cm in 15 minutes — a rate of 20cm/15min. A rate-only system screams FLOOD. But the river channel can hold 300cm before it threatens any settlement. The actual risk is zero. You just sent an emergency SMS to the District Collector at 2 AM for nothing.

**False Negative Scenario:**
The Brahmaputra during monsoon sits at 920cm with a danger level of 950cm. It has been rising steadily at 1.5cm/15min for 18 hours. A rate-only system with a 5cm/15min threshold sees 1.5cm and stays in NORMAL mode. In 3 hours the river will overflow. No alert was ever sent.

Both failures are unacceptable in a system designed to save lives.

---

### 1.2 The Three Detection Factors

#### Factor 1: Zone Classification (Absolute Level)

Every deployment site has four thresholds configured via SMS during installation:

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  DANGER_LEVEL  ──────── Site-specific (e.g., 250cm)            │
│                         River WILL overflow                     │
│                                                                 │
│  WARNING_LEVEL ──────── Site-specific (e.g., 180cm)            │
│                         Overflow likely within hours             │
│                                                                 │
│  ALERT_LEVEL   ──────── Site-specific (e.g., 120cm)            │
│                         Situation worth monitoring               │
│                                                                 │
│  NORMAL        ──────── Below ALERT_LEVEL                       │
│                         No concern                               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

These values vary drastically between sites. A small nala in Gujarat might have DANGER at 60cm. The Ganga at Varanasi might have DANGER at 1200cm. This is why SMS-based remote configuration exists — each device gets site-specific thresholds.

#### Factor 2: Rate of Change Classification

```
RATE = (Current_Level - Previous_Level) / Time_Interval

Categories:
  SLOW      :  rate < 2cm per 15 minutes
  MODERATE  :  2cm ≤ rate < 5cm per 15 minutes
  FAST      :  rate ≥ 5cm per 15 minutes
  FALLING   :  rate < 0 (water receding)
```

**Important normalization:** Since the adaptive sampling system (System 2) changes the sampling interval, the rate must always be normalized to a per-15-minute basis regardless of actual sampling interval. If the device sampled at a 5-minute interval and measured a 3cm rise, the normalized rate is 3cm × (15/5) = 9cm/15min = FAST.

#### Factor 3: Sustained Rise Confirmation

The system maintains a **circular buffer of the last 4 readings**. After each new reading, it checks:

```
readings[0] = oldest
readings[1] = second oldest
readings[2] = second newest
readings[3] = newest (current)

rise_count = 0
FOR i FROM 1 TO 3:
    IF readings[i] > readings[i-1]:
        rise_count = rise_count + 1

IF rise_count >= 3:
    sustained = TRUE
ELSE:
    sustained = FALSE
```

**Why 3 out of 4 and not 4 out of 4?**
Because sensor noise can cause one reading to dip slightly even during a genuine rise. Requiring perfect monotonic increase would miss real floods where one sample has minor jitter. But requiring only 2 out of 4 would be too permissive — a boat wake causing two consecutive spikes would pass.

**Why 4 readings and not 6 or 8?**
At a 30-minute normal sampling rate, 4 readings covers 2 hours — enough to confirm a genuine trend without introducing dangerous delay. At a 5-minute emergency sampling rate, 4 readings covers only 20 minutes — fast enough for flash floods.

---

### 1.3 The Complete Decision Matrix

This is the full 24-combination matrix (4 zones × 3 rate categories × 2 sustained states):

```
┌──────────┬──────────┬───────────┬───────────────┬──────────────────────────────────────────────────┐
│ Zone     │ Rate     │ Sustained │ Response      │ Actions                                          │
│          │          │           │ Level         │                                                  │
├──────────┼──────────┼───────────┼───────────────┼──────────────────────────────────────────────────┤
│ NORMAL   │ SLOW     │ NO        │ NORMAL        │ Routine logging. No action.                      │
│ NORMAL   │ SLOW     │ YES       │ NORMAL        │ Routine logging. River filling normally.          │
│ NORMAL   │ MODERATE │ NO        │ NORMAL        │ Log only. Likely transient pulse.                 │
│ NORMAL   │ MODERATE │ YES       │ WATCH         │ Increase sampling rate. No alert yet.             │
│ NORMAL   │ FAST     │ NO        │ NORMAL        │ Likely boat wake or sensor jitter. Ignore.        │
│ NORMAL   │ FAST     │ YES       │ WATCH         │ Increase sampling. River filling rapidly.          │
│          │          │           │               │ Could reach ALERT zone soon.                      │
├──────────┼──────────┼───────────┼───────────────┼──────────────────────────────────────────────────┤
│ ALERT    │ SLOW     │ NO        │ WATCH         │ Elevated logging. Monitor closely.                │
│ ALERT    │ SLOW     │ YES       │ WATCH         │ Steady rise in ALERT zone. Increase sampling.     │
│ ALERT    │ MODERATE │ NO        │ WATCH         │ May be transient. Watch next 2 readings.          │
│ ALERT    │ MODERATE │ YES       │ WARNING       │ SMS to District Office. Rising through            │
│          │          │           │               │ ALERT zone consistently.                          │
│ ALERT    │ FAST     │ NO        │ WATCH         │ Single fast reading. Could be noise. Wait for     │
│          │          │           │               │ confirmation before alerting.                     │
│ ALERT    │ FAST     │ YES       │ WARNING       │ SMS to District Office. Fast sustained rise in    │
│          │          │           │               │ ALERT zone — will reach WARNING zone soon.        │
├──────────┼──────────┼───────────┼───────────────┼──────────────────────────────────────────────────┤
│ WARNING  │ SLOW     │ NO        │ WARNING       │ SMS to District Office. Already high water.       │
│ WARNING  │ SLOW     │ YES       │ FLOOD ALERT   │ SMS to District + Panchayat. Slow but persistent  │
│          │          │           │               │ rise in WARNING zone. Overflow is hours away.     │
│ WARNING  │ MODERATE │ NO        │ WARNING       │ SMS to District. Might be transient at high level.│
│ WARNING  │ MODERATE │ YES       │ FLOOD ALERT   │ SMS + escalation. Consistent rise toward DANGER.  │
│ WARNING  │ FAST     │ NO        │ FLOOD ALERT   │ Even unsustained, FAST rise in WARNING zone is    │
│          │          │           │               │ dangerous. Alert immediately. Do NOT wait.        │
│ WARNING  │ FAST     │ YES       │ CRITICAL      │ Full escalation: SMS + Voice Call + NDRF.          │
│          │          │           │               │ River will breach within minutes.                 │
├──────────┼──────────┼───────────┼───────────────┼──────────────────────────────────────────────────┤
│ DANGER   │ SLOW     │ NO        │ FLOOD ALERT   │ Already overflowing. Full alert regardless        │
│          │          │           │               │ of rate or trend.                                │
│ DANGER   │ SLOW     │ YES       │ CRITICAL      │ Overflowing and still rising. Maximum escalation. │
│ DANGER   │ MODERATE │ NO        │ CRITICAL      │ Overflowing with significant inflow. CRITICAL.    │
│ DANGER   │ MODERATE │ YES       │ CRITICAL      │ Maximum emergency. All tiers. Voice calls.        │
│ DANGER   │ FAST     │ NO        │ CRITICAL      │ Maximum emergency regardless of sustained.        │
│ DANGER   │ FAST     │ YES       │ CRITICAL      │ Catastrophic scenario. All communication          │
│          │          │           │               │ channels activated simultaneously.                │
└──────────┴──────────┴───────────┴───────────────┴──────────────────────────────────────────────────┘
```

**Design Decisions to Notice:**

1. **WARNING + FAST + NOT sustained = FLOOD ALERT (not WATCH):** This is deliberate. When the absolute level is already in the WARNING zone, a single fast reading is too dangerous to dismiss as noise. The cost of a false positive here is an unnecessary SMS. The cost of a false negative is people drowning. The tradeoff is obvious.

2. **DANGER zone ignores sustained check almost entirely:** Once water has crossed the DANGER level, the river is already overflowing. Whether it's sustained or transient is irrelevant — the damage is happening NOW. Every combination in the DANGER zone triggers at minimum FLOOD ALERT.

3. **NORMAL + FAST + NOT sustained = NORMAL (no action):** This handles boat wakes, sensor jitter, and brief upstream pulses at low water levels. The system does not even switch to WATCH mode because one fast reading at low level with no trend confirmation is almost certainly noise.

---

### 1.4 Response Level Definitions

```
┌───────────────┬────────────────────────────────────────────────────────────────┐
│ Response      │ System Behavior                                                │
│ Level         │                                                                │
├───────────────┼────────────────────────────────────────────────────────────────┤
│ NORMAL        │ Routine operation. Log data. Transmit per normal schedule.      │
│               │ No alerts sent.                                                │
├───────────────┼────────────────────────────────────────────────────────────────┤
│ WATCH         │ Increase sampling frequency. No external alerts sent.          │
│               │ Internal flag set. System is paying attention.                 │
│               │ Data transmitted more frequently to dashboard.                 │
├───────────────┼────────────────────────────────────────────────────────────────┤
│ WARNING       │ SMS sent to Tier 1 contacts (District CWC Office).             │
│               │ Sampling and transmission at elevated rate.                    │
│               │ Dashboard shows yellow indicator.                              │
├───────────────┼────────────────────────────────────────────────────────────────┤
│ FLOOD ALERT   │ SMS to Tier 1 + Tier 2 (Panchayat, District Collector).        │
│               │ GPRS transmission every 5 minutes.                             │
│               │ Dashboard shows orange indicator.                              │
│               │ Wait 15 minutes for acknowledgment SMS.                       │
├───────────────┼────────────────────────────────────────────────────────────────┤
│ CRITICAL      │ SMS to Tier 1 + Tier 2 + Tier 3 (State Control Room, NDRF).    │
│               │ Voice calls initiated if no SMS acknowledgment.               │
│               │ Maximum sampling rate (2 min). Maximum transmit rate (2 min). │
│               │ RED LED flashing continuously.                                 │
│               │ Dashboard shows red indicator.                                 │
└───────────────┴────────────────────────────────────────────────────────────────┘
```

---

### 1.5 Stepping Down and ALL CLEAR Logic

The system cannot step down instantly. A river that recedes for 20 minutes might surge again. The step-down logic uses **hysteresis** — requiring sustained improvement before de-escalating.

```
STEP-DOWN RULES:

    CRITICAL → FLOOD ALERT:
        Water level must drop below DANGER_LEVEL
        AND remain below for 4 consecutive readings
        AND rate must be FALLING or SLOW

    FLOOD ALERT → WARNING:
        Water level must drop below WARNING_LEVEL
        AND remain below for 4 consecutive readings

    WARNING → WATCH:
        Water level must drop below ALERT_LEVEL
        AND remain below for 4 consecutive readings

    WATCH → NORMAL:
        Water level in NORMAL zone
        AND rate is SLOW or FALLING
        AND sustained rise is FALSE
        AND this condition persists for 8 consecutive readings (4 hours at normal rate)

    ALL CLEAR SMS:
        Sent ONLY when system transitions from WARNING (or above) to NORMAL
        Sent to ALL tiers that received the original alert
        Message includes: current level, time of peak, peak level reached
```

**Why 8 readings for WATCH → NORMAL?**
Rivers can have secondary surges — a first pulse recedes, then a larger second pulse arrives hours later (common in dam-fed rivers). The 4-hour confirmation window catches this.

---

### 1.6 Edge Cases

**Edge Case 1: Device Reboot — No Historical Readings**

```
ON BOOT:
    historical_buffer = EMPTY
    sustained = UNKNOWN (treated as FALSE)
    
    First reading:  zone classification ONLY (no rate, no trend)
                    If zone is DANGER → immediate FLOOD ALERT
                    If zone is WARNING → immediate WARNING
                    If zone is ALERT or NORMAL → NORMAL mode
    
    Second reading: rate can be calculated, sustained still FALSE
    
    Fourth reading: full algorithm operational
    
    SPECIAL RULE: During the first 4 readings after boot,
                  if zone is WARNING or above, skip the sustained
                  check entirely and alert based on zone + rate only.
                  Safety takes priority over false-positive avoidance
                  during cold start.
```

**Edge Case 2: Sensor Failure Mid-Cycle**

```
IF primary sensor (MPU-6050) fails:
    System CANNOT measure water level
    Send SMS: "SENSOR FAILURE - MPU6050 OFFLINE"
    Fall back to HC-SR04 ultrasonic (if available)
    If NO sensors available → send "ALL SENSORS OFFLINE" SMS
    Enter MAINTENANCE mode — transmit last known level every hour
    Do NOT send flood alerts based on stale data

IF secondary sensors fail but primary works:
    Continue normal operation with primary only
    Log sensor fault
    Reduce confidence weighting to primary-only
    Send diagnostic SMS to maintenance team
```

**Edge Case 3: Battery Critical + River in DANGER Zone**

```
This is a conflict: power management wants to shut down,
flood detection demands maximum operation.

RESOLUTION: FLOOD DETECTION WINS.

IF battery < 10% AND zone >= WARNING:
    DO NOT shut down
    Disable ALL non-essential systems:
        - GPS OFF
        - Secondary sensors OFF
        - LED OFF
        - Log to RAM only (no SD writes to save power)
    Reduce to: MPU-6050 read + SMS alert only (no GPRS)
    SMS every 5 minutes with: level, rate, battery remaining
    Accept that device may die — but it will die screaming
    the warning rather than dying silently

IF battery < 10% AND zone == NORMAL:
    Normal emergency shutdown procedure
    Send "BATTERY CRITICAL" SMS
    Graceful shutdown
    Wait for solar recharge
```

---

### 1.7 Concrete Scenario Examples

#### Scenario A: Dry-Season False Alarm (Rajasthan Tributary)

Site configuration: ALERT=60cm, WARNING=100cm, DANGER=140cm

```
┌──────────┬───────┬────────────┬─────────┬───────────┬───────────┬──────────────┐
│ Time     │ Level │ Rate       │ Zone    │ Sustained │ Decision  │ Action       │
│          │ (cm)  │ (cm/15min) │         │           │           │              │
├──────────┼───────┼────────────┼─────────┼───────────┼───────────┼──────────────┤
│ 06:00    │ 5     │ --         │ NORMAL  │ --        │ NORMAL    │ Routine log  │
│ 06:30    │ 5     │ 0          │ NORMAL  │ NO        │ NORMAL    │ Routine log  │
│ 07:00    │ 8     │ +3         │ NORMAL  │ NO        │ NORMAL    │ Routine log  │
│ 07:30    │ 19    │ +11        │ NORMAL  │ NO        │ NORMAL    │ Routine log  │
│ 08:00    │ 32    │ +13        │ NORMAL  │ YES       │ WATCH     │ Sample→15min │
│ 08:15    │ 38    │ +6         │ NORMAL  │ YES       │ WATCH     │ Keep 15min   │
│ 08:30    │ 40    │ +2         │ NORMAL  │ YES       │ NORMAL    │ Rate slowing │
│ 08:45    │ 41    │ +1         │ NORMAL  │ YES       │ NORMAL    │ Stabilizing  │
│ 09:15    │ 42    │ +0.5       │ NORMAL  │ NO        │ NORMAL    │ Back to 30m  │
│ 09:45    │ 41    │ -0.5       │ NORMAL  │ NO        │ NORMAL    │ Routine      │
└──────────┴───────┴────────────┴─────────┴───────────┴───────────┴──────────────┘

Result: Water rose from 5cm to 42cm (fast initially). 
        System entered WATCH briefly, NEVER sent any SMS.
        Correct behavior — the river was just filling from dry season low.
        No false alarm. No wasted SMS. No officer woken up.
```

#### Scenario B: Slow Monsoon Rise (Brahmaputra)

Site configuration: ALERT=800cm, WARNING=900cm, DANGER=950cm

```
┌──────────┬───────┬────────────┬─────────┬───────────┬──────────────┬────────────────────────┐
│ Time     │ Level │ Rate       │ Zone    │ Sustained │ Decision     │ Action                 │
│          │ (cm)  │ (cm/15min) │         │           │              │                        │
├──────────┼───────┼────────────┼─────────┼───────────┼──────────────┼────────────────────────┤
│ Day 1    │ 750   │ +0.5       │ NORMAL  │ YES       │ NORMAL       │ Routine. Slow rise     │
│ 06:00    │       │            │         │           │              │ is expected in monsoon │
│ Day 1    │ 780   │ +1.0       │ NORMAL  │ YES       │ NORMAL       │ Still well within      │
│ 18:00    │       │            │         │           │              │ NORMAL zone            │
│ Day 2    │ 805   │ +0.8       │ ALERT   │ YES       │ WATCH        │ Crossed ALERT.         │
│ 06:00    │       │            │         │           │              │ Sampling→15min         │
│ Day 2    │ 830   │ +1.0       │ ALERT   │ YES       │ WARNING      │ Moderate sustained     │
│ 18:00    │       │            │         │           │              │ rise in ALERT zone.    │
│          │       │            │         │           │              │ SMS to District.       │
│ Day 3    │ 870   │ +1.3       │ ALERT   │ YES       │ WARNING      │ Continued SMS updates  │
│ 06:00    │       │            │         │           │              │                        │
│ Day 3    │ 905   │ +1.2       │ WARNING │ YES       │ FLOOD ALERT  │ Crossed WARNING.       │
│ 18:00    │       │            │         │           │              │ SMS to District +      │
│          │       │            │         │           │              │ Panchayat. Sample→5min │
│ Day 4    │ 935   │ +1.0       │ WARNING │ YES       │ FLOOD ALERT  │ Approaching DANGER     │
│ 06:00    │       │            │         │           │              │                        │
│ Day 4    │ 952   │ +0.6       │ DANGER  │ YES       │ CRITICAL     │ Crossed DANGER.        │
│ 18:00    │       │            │         │           │              │ ALL TIERS alerted.     │
│          │       │            │         │           │              │ Voice calls. NDRF.     │
└──────────┴───────┴────────────┴─────────┴───────────┴──────────────┴────────────────────────┘

Result: Rate NEVER exceeded 1.5cm/15min (well below the naive 5cm threshold).
        A rate-only system would have NEVER triggered.
        This system correctly escalated through every tier over 4 days.
        District office had 2 days of advance warning.
```

#### Scenario C: Flash Flood (Small Tributary, Uttarakhand)

Site configuration: ALERT=40cm, WARNING=65cm, DANGER=85cm

```
┌──────────┬───────┬────────────┬─────────┬───────────┬──────────────┬─────────────────────────┐
│ Time     │ Level │ Rate       │ Zone    │ Sustained │ Decision     │ Action                  │
│          │ (cm)  │ (cm/15min) │         │           │              │                         │
├──────────┼───────┼────────────┼─────────┼───────────┼──────────────┼─────────────────────────┤
│ 14:00    │ 15    │ 0          │ NORMAL  │ NO        │ NORMAL       │ Routine                 │
│ 14:30    │ 16    │ +1         │ NORMAL  │ NO        │ NORMAL       │ Routine                 │
│ 15:00    │ 25    │ +9         │ NORMAL  │ NO        │ NORMAL       │ Fast but unsustained.   │
│          │       │            │         │           │              │ Could be noise. Wait.   │
│ 15:30    │ 44    │ +19        │ ALERT   │ YES       │ WARNING      │ Shot into ALERT zone.   │
│          │       │            │         │           │              │ Sustained rapid rise.   │
│          │       │            │         │           │              │ SMS sent. Sample→5min.  │
│ 15:35    │ 52    │ +24        │ ALERT   │ YES       │ WARNING      │ Still climbing fast     │
│ 15:40    │ 61    │ +27        │ ALERT   │ YES       │ WARNING      │ Approaching WARNING     │
│ 15:45    │ 72    │ +33        │ WARNING │ YES       │ CRITICAL     │ WARNING + FAST +        │
│          │       │            │         │           │              │ SUSTAINED = CRITICAL.   │
│          │       │            │         │           │              │ ALL TIERS. Voice calls. │
│ 15:50    │ 81    │ +27        │ WARNING │ YES       │ CRITICAL     │ Still rising. Continued │
│          │       │            │         │           │              │ alerts.                 │
│ 15:55    │ 88    │ +21        │ DANGER  │ YES       │ CRITICAL     │ DANGER zone breached.   │
│ 16:00    │ 91    │ +9         │ DANGER  │ YES       │ CRITICAL     │ Rate slowing. Peak near │
│ 16:10    │ 89    │ -3         │ DANGER  │ NO        │ CRITICAL     │ Still in DANGER.        │
│          │       │            │         │           │              │ No step-down yet.       │
│ 16:30    │ 78    │ -5.5       │ WARNING │ NO        │ FLOOD ALERT  │ Dropped below DANGER.   │
│          │       │            │         │           │              │ Still in WARNING.       │
│ 17:30    │ 55    │ -3.8       │ ALERT   │ NO        │ WATCH        │ Receding. Still ALERT.  │
│ 19:30    │ 30    │ -2         │ NORMAL  │ NO        │ NORMAL       │ ALL CLEAR sent.         │
└──────────┴───────┴────────────┴─────────┴───────────┴──────────────┴─────────────────────────┘

Result: From first significant reading (15:00) to CRITICAL alert (15:45) = 45 minutes.
        In a 15-min fixed system, the device would have readings at 15:00, 15:15, 15:30, 15:45.
        With adaptive sampling, once WATCH was entered, the system switched to 5-min sampling
        and captured the rise in much higher resolution.
        Total time from dry stream to DANGER zone: ~55 minutes.
```

#### Scenario D: Dam Release Event

Site configuration: ALERT=100cm, WARNING=160cm, DANGER=200cm

```
┌──────────┬───────┬────────────┬─────────┬───────────┬──────────────┬─────────────────────────┐
│ Time     │ Level │ Rate       │ Zone    │ Sustained │ Decision     │ Action                  │
│          │ (cm)  │ (cm/15min) │         │           │              │                         │
├──────────┼───────┼────────────┼─────────┼───────────┼──────────────┼─────────────────────────┤
│ 10:00    │ 45    │ 0          │ NORMAL  │ NO        │ NORMAL       │ Routine                 │
│ 10:30    │ 45    │ 0          │ NORMAL  │ NO        │ NORMAL       │ Routine                 │
│ 11:00    │ 46    │ +1         │ NORMAL  │ NO        │ NORMAL       │ Routine                 │
│ 11:30    │ 85    │ +39        │ NORMAL  │ NO        │ NORMAL       │ MASSIVE spike but       │
│          │       │            │         │           │              │ still NORMAL zone and   │
│          │       │            │         │           │              │ NOT yet sustained.      │
│          │       │            │         │           │              │ This is the critical    │
│          │       │            │         │           │              │ gap — see note below.   │
│ 11:45    │ 130   │ +45        │ ALERT   │ YES       │ WARNING      │ NOW sustained + ALERT   │
│          │       │            │         │           │              │ zone. SMS sent.         │
│          │       │            │         │           │              │ Sample→5min.            │
│ 11:50    │ 155   │ +75        │ ALERT   │ YES       │ WARNING      │ Rocketing upward        │
│ 11:55    │ 175   │ +60        │ WARNING │ YES       │ CRITICAL     │ WARNING + FAST +        │
│          │       │            │         │           │              │ SUSTAINED = CRITICAL    │
│ 12:00    │ 210   │ +105       │ DANGER  │ YES       │ CRITICAL     │ DANGER zone. All tiers. │
│ 12:05    │ 225   │ +45        │ DANGER  │ YES       │ CRITICAL     │ Peak approaching        │
│ 12:15    │ 230   │ +7.5       │ DANGER  │ YES       │ CRITICAL     │ Rate slowing            │
│ 12:30    │ 228   │ -1.3       │ DANGER  │ NO        │ CRITICAL     │ Still in DANGER zone    │
└──────────┴───────┴────────────┴─────────┴───────────┴──────────────┴─────────────────────────┘
```

**Critical Note on the 11:30 Reading:**

At 11:30, the water jumped from 46cm to 85cm in 30 minutes. The rate is extreme (39cm/30min = 19.5cm/15min normalized). But the system classified this as NORMAL because:
- Zone = NORMAL (85cm < ALERT at 100cm)
- Sustained = NO (only 1 out of the last 4 readings shows a rise pattern — the previous three were flat)

**Is this a flaw?** Partially. In a dam release scenario, the water wall arrives as a near-instantaneous step function, not a gradual rise. The sustained-rise check introduces a one-cycle delay.

**Mitigation already built in:** The adaptive sampling system (System 2) would have increased sampling to 15 minutes when it detected the FAST rate at 11:30. So the next reading comes at 11:45 (15 min later) instead of 12:00 (30 min later). By 11:45, the system has entered ALERT zone AND has sustained confirmation, triggering WARNING. By 11:55 — only 25 minutes after the wave arrived — the system is at CRITICAL.

**Could we improve further?** Yes. One possible addition:

```
OVERRIDE RULE: If rate > 30cm/15min (extreme rate) AND zone is ALERT or above,
               skip the sustained check entirely and trigger immediately.
               
               A 30cm/15min rate is physically impossible from noise, waves,
               or boats. It can ONLY come from a dam release or landslide dam
               breach. Do not wait for confirmation.
```

This override adds a fourth fast-path rule that bypasses the sustained check for physically unmistakable events.

---

---

## SYSTEM 2: Adaptive Sampling Rate with Decoupled Sensing and Transmission

---

### 2.1 The Cost Asymmetry

Not all device operations cost the same amount of energy. This is the foundational insight:

```
┌─────────────────────────────────┬────────────┬──────────┬──────────────┐
│ Operation                       │ Power Draw │ Duration │ Energy Cost  │
│                                 │ (Watts)    │ (sec)    │ (Wh)         │
├─────────────────────────────────┼────────────┼──────────┼──────────────┤
│ Wake Raspberry Pi from idle     │ 4.0        │ 3        │ 0.0033       │
│ Read sensors (I2C + GPIO)       │ 0.5        │ 2        │ 0.0003       │
│ Process data (calculate + log)  │ 4.0        │ 2        │ 0.0022       │
│ SENSOR READING TOTAL            │ --         │ 7        │ 0.0058       │
├─────────────────────────────────┼────────────┼──────────┼──────────────┤
│ GSM module wake + register      │ 3.0        │ 10       │ 0.0083       │
│ GPRS data transmit              │ 6.0        │ 20       │ 0.0333       │
│ TRANSMISSION TOTAL              │ --         │ 30       │ 0.0416       │
├─────────────────────────────────┼────────────┼──────────┼──────────────┤
│ RATIO: Transmit / Sample        │            │          │ 7.2×         │
└─────────────────────────────────┴────────────┴──────────┴──────────────┘
```

Transmitting data is **7 times more expensive** than reading a sensor. This means:
- You can sample 7 times for the energy cost of 1 transmission
- Sampling frequently but transmitting infrequently is almost free compared to the naive approach of transmitting every reading

---

### 2.2 The Adaptive Sampling Table

The algorithm sets BOTH intervals after every reading cycle:

```
┌─────────────────────────────┬──────────┬──────────┬────────────────────────────────────────┐
│ Condition                   │ Sample   │ Transmit │ Rationale                              │
│                             │ Interval │ Interval │                                        │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ NORMAL zone                 │          │          │ Nothing happening. Maximize battery     │
│ Rate SLOW                   │ 30 min   │ 60 min   │ life. Sample 2× per transmit to catch  │
│ Battery > 20%               │          │          │ onset of change.                       │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ NORMAL zone                 │          │          │ Rate interesting but level safe.        │
│ Rate MODERATE or FAST       │ 15 min   │ 30 min   │ Sample faster to build trend data.     │
│ Battery > 20%               │          │          │ Transmit moderately.                   │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ ALERT zone                  │          │          │ Situation worth monitoring.             │
│ Any rate                    │ 10 min   │ 15 min   │ Dashboard needs frequent updates.      │
│ Battery > 20%               │          │          │ Trend data critical for prediction.    │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ WARNING zone                │          │          │ Danger approaching.                    │
│ OR any zone + FAST rate     │ 5 min    │ 5 min    │ Every reading transmitted immediately. │
│ AND sustained               │          │          │ Authorities need real-time data.       │
│ Battery > 10%               │          │          │                                        │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ DANGER zone                 │          │          │ Maximum urgency. Lives at risk.         │
│ Battery > 5%                │ 2 min    │ 2 min    │ Every reading transmitted. Accept high  │
│                             │          │          │ power draw — emergency overrides all.  │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ LOW BATTERY (< 20%)         │          │          │ Stretch remaining power. Accept lower   │
│ + NORMAL zone               │ 60 min   │ 120 min  │ resolution since risk is low.          │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ LOW BATTERY (< 20%)         │          │          │ Battery low BUT flood risk exists.      │
│ + ALERT zone                │ 15 min   │ 30 min   │ Compromise: slower than ideal but      │
│                             │          │          │ still monitoring the situation.         │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ LOW BATTERY (< 20%)         │          │          │ Battery dying but river dangerous.      │
│ + WARNING or DANGER zone    │ 5 min    │ 5 min    │ FLOOD DETECTION OVERRIDES POWER        │
│                             │          │          │ CONSERVATION. Device may die but it     │
│                             │          │          │ will die transmitting warnings.         │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ CRITICAL BATTERY (< 10%)    │          │          │ Near shutdown. Absolute minimum.        │
│ + NORMAL zone               │ 120 min  │ SMS only │ No GPRS. Single SMS every 2 hours.     │
│                             │          │ 240 min  │ Preserve power for potential emergency. │
├─────────────────────────────┼──────────┼──────────┼────────────────────────────────────────┤
│ CRITICAL BATTERY (< 10%)    │          │          │ Dying device, dangerous river.          │
│ + WARNING or DANGER zone    │ 5 min    │ SMS only │ No GPRS (too expensive). SMS-only       │
│                             │          │ 5 min    │ alerts every 5 min until battery dies.  │
└─────────────────────────────┴──────────┴──────────┴────────────────────────────────────────┘
```

---

### 2.3 Power Consumption Comparison

This table proves the adaptive approach works:

```
┌──────────────────┬─────────┬──────────────┬─────────┬──────────┬─────────┬──────────────┐
│ Strategy         │ Samples │ Transmissions│ Sensor  │ Transmit │ Total   │ Battery Life │
│                  │ per Day │ per Day      │ Energy  │ Energy   │ Active  │ (240Wh batt, │
│                  │         │              │ (Wh)    │ (Wh)     │ (Wh/day)│ 40.8Wh base) │
├──────────────────┼─────────┼──────────────┼─────────┼──────────┼─────────┼──────────────┤
│ Fixed 2 min      │ 720     │ 720          │ 4.2     │ 30.0     │ 75.0    │ 2.1 days     │
│ Fixed 5 min      │ 288     │ 288          │ 1.7     │ 12.0     │ 54.5    │ 3.4 days     │
│ Fixed 15 min     │ 96      │ 96           │ 0.6     │ 4.0      │ 45.4    │ 4.3 days     │
│ Fixed 30 min     │ 48      │ 48           │ 0.3     │ 2.0      │ 43.1    │ 4.6 days     │
│ Fixed 60 min     │ 24      │ 24           │ 0.1     │ 1.0      │ 41.9    │ 4.8 days     │
│ ADAPTIVE (calm)  │ 48      │ 24           │ 0.3     │ 1.0      │ 42.1    │ 4.7 days     │
│ ADAPTIVE (flood) │ 288     │ 288          │ 1.7     │ 12.0     │ 54.5    │ 3.4 days     │
└──────────────────┴─────────┴──────────────┴─────────┴──────────┴─────────┴──────────────┘
```

**Key insight from the numbers:**

During calm periods (95% of the year), the adaptive system consumes **42.1 Wh/day** — nearly identical to fixed 60-minute sampling (41.9 Wh/day) and significantly less than fixed 15-minute sampling (45.4 Wh/day).

During a flood event (maybe 5–15 days per year), it consumes 54.5 Wh/day — same as fixed 5-minute. But this is acceptable because:
1. It only happens during emergencies when data resolution matters more than battery life
2. Solar and wind charging typically continue during floods (rain ≠ no sunlight all day, and monsoon winds are strong)
3. Even at 54.5 Wh/day, the battery lasts 3.4 days — well above the 3-day autonomy requirement

**Annual weighted average** (assuming 350 calm days + 15 flood days):
```
Annual avg = (350 × 42.1 + 15 × 54.5) / 365 = 42.6 Wh/day
```

This is essentially the same as 30-minute fixed sampling across the entire year, while providing 2-minute resolution when lives are at risk.

---

### 2.4 The Feedback Loop Between System 1 and System 2

These two systems are not independent. They form a **closed feedback loop**:

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  SYSTEM 1 (Flood Detection)                                         │
│      │                                                              │
│      │  Outputs: Zone, Rate, Response Level                         │
│      │                                                              │
│      ▼                                                              │
│  SYSTEM 2 (Adaptive Sampling)                                       │
│      │                                                              │
│      │  Sets: Sample Interval, Transmit Interval                    │
│      │                                                              │
│      ▼                                                              │
│  More/fewer data points collected                                   │
│      │                                                              │
│      │  Affects: Rate calculation accuracy,                         │
│      │           Sustained-rise buffer fill rate,                   │
│      │           Trend detection sensitivity                        │
│      │                                                              │
│      ▼                                                              │
│  SYSTEM 1 (next cycle — better or worse data to work with)          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**The feedback is positive in the right direction:**
- When conditions are dangerous → System 1 escalates → System 2 samples faster → System 1 gets MORE data points → sustained-rise buffer fills faster → detection improves → alerts are faster
- When conditions are calm → System 1 stays NORMAL → System 2 samples slowly → System 1 gets fewer data points → but it doesn't need them → power is conserved

**Potential negative feedback issue:**
In LOW BATTERY + NORMAL mode, sampling is at 60 minutes. The sustained-rise buffer takes 4 readings = 4 hours to fill. If a flash flood arrives during this window, the system is BLIND for up to 4 hours.

**Mitigation:** The rate calculation still works on any two consecutive readings. Even at 60-minute intervals, a jump from 30cm to 90cm will show rate = 60cm/60min = 15cm/15min normalized = FAST. This immediately triggers the adaptive system to increase sampling to 15 minutes, and within 45 minutes (3 more readings), the sustained buffer is populated.

The worst case is a 60-minute blind spot at the start of a flood during low battery — an unavoidable tradeoff. The override rule (WARNING/DANGER zone ignores battery conservation) ensures that once the water reaches a dangerous absolute level, the system responds at full speed regardless of battery.

---

### 2.5 The Complete Adaptive Algorithm Logic Flow

```
AFTER EACH SENSOR READING:

1.  Get outputs from System 1:
        zone = current zone classification
        rate_category = SLOW / MODERATE / FAST
        response_level = NORMAL / WATCH / WARNING / FLOOD ALERT / CRITICAL
    
2.  Read battery percentage:
        battery = read_battery_voltage() → convert to percentage

3.  Determine sample_interval and transmit_interval:

        IF battery < 10%:                              [CRITICAL BATTERY]
            IF zone >= WARNING:
                sample_interval  = 5 min
                transmit_mode    = SMS_ONLY
                transmit_interval = 5 min
            ELSE:
                sample_interval  = 120 min
                transmit_mode    = SMS_ONLY
                transmit_interval = 240 min
        
        ELSE IF battery < 20%:                         [LOW BATTERY]
            IF zone >= WARNING:
                sample_interval  = 5 min               [FLOOD OVERRIDES POWER]
                transmit_interval = 5 min
            ELSE IF zone == ALERT:
                sample_interval  = 15 min
                transmit_interval = 30 min
            ELSE:
                sample_interval  = 60 min
                transmit_interval = 120 min
        
        ELSE:                                          [NORMAL BATTERY]
            IF zone == DANGER:
                sample_interval  = 2 min
                transmit_interval = 2 min
            ELSE IF zone == WARNING OR (rate == FAST AND sustained == TRUE):
                sample_interval  = 5 min
                transmit_interval = 5 min
            ELSE IF zone == ALERT:
                sample_interval  = 10 min
                transmit_interval = 15 min
            ELSE IF rate_category == MODERATE OR rate_category == FAST:
                sample_interval  = 15 min
                transmit_interval = 30 min
            ELSE:
                sample_interval  = 30 min
                transmit_interval = 60 min

4.  Determine if this cycle should transmit:
        IF time_since_last_transmit >= transmit_interval:
            transmit_now = TRUE
            Payload includes: current reading + all buffered readings since last transmit
        ELSE:
            transmit_now = FALSE
            Store reading in local buffer only

5.  Set next wake-up timer:
        set_alarm(sample_interval)
        enter_low_power_sleep()
```

---

### 2.6 Edge Case: Transmission Failure During High-Frequency Mode

```
IF transmit_now == TRUE but GPRS fails:
    
    Attempt 1: GPRS POST
    Attempt 2: GPRS POST (retry)
    Attempt 3: GPRS POST (retry)
    
    All failed?
        IF response_level >= FLOOD ALERT:
            Fall back to SMS immediately
            Send compressed alert via SMS
            SMS is slower but works on 2G
        ELSE:
            Store in local queue
            Will batch-upload on next successful transmission
    
    Do NOT extend the sampling interval due to transmission failure.
    Continue reading sensors at the set sample_interval.
    The local buffer grows until transmission succeeds.
    
    IF local buffer exceeds 500 readings:
        Compress and archive to USB drive
        Continue buffering new readings in RAM
```

---

## HTML Tables

### Table 1: Decision Matrix

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Flood Detection Decision Matrix</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #1a1a2e;
            color: #ffffff;
            padding: 14px 12px;
            text-align: left;
            font-size: 0.95em;
            border: 1px solid #333;
        }
        tbody td {
            padding: 12px;
            border: 1px solid #ddd;
            font-size: 0.9em;
            vertical-align: top;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .zone-normal { color: #2e7d32; font-weight: bold; }
        .zone-alert { color: #f57f17; font-weight: bold; }
        .zone-warning { color: #e65100; font-weight: bold; }
        .zone-danger { color: #b71c1c; font-weight: bold; }
        .resp-normal { background-color: #e8f5e9; }
        .resp-watch { background-color: #fff9c4; }
        .resp-warning { background-color: #ffe0b2; }
        .resp-flood { background-color: #ffccbc; }
        .resp-critical { background-color: #ffcdd2; }
    </style>
</head>
<body>

<table>
    <caption>VARUNA Flood Detection Decision Matrix — All 24 Combinations</caption>
    <thead>
        <tr>
            <th>Zone</th>
            <th>Rate</th>
            <th>Sustained</th>
            <th>Response Level</th>
            <th>Actions Taken</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="zone-normal">NORMAL</td>
            <td>SLOW</td>
            <td>NO</td>
            <td class="resp-normal">NORMAL</td>
            <td>Routine logging. No action.</td>
        </tr>
        <tr>
            <td class="zone-normal">NORMAL</td>
            <td>SLOW</td>
            <td>YES</td>
            <td class="resp-normal">NORMAL</td>
            <td>Routine logging. River filling normally.</td>
        </tr>
        <tr>
            <td class="zone-normal">NORMAL</td>
            <td>MODERATE</td>
            <td>NO</td>
            <td class="resp-normal">NORMAL</td>
            <td>Log only. Likely transient pulse.</td>
        </tr>
        <tr>
            <td class="zone-normal">NORMAL</td>
            <td>MODERATE</td>
            <td>YES</td>
            <td class="resp-watch">WATCH</td>
            <td>Increase sampling rate. No alert yet.</td>
        </tr>
        <tr>
            <td class="zone-normal">NORMAL</td>
            <td>FAST</td>
            <td>NO</td>
            <td class="resp-normal">NORMAL</td>
            <td>Likely boat wake or sensor jitter. Ignore.</td>
        </tr>
        <tr>
            <td class="zone-normal">NORMAL</td>
            <td>FAST</td>
            <td>YES</td>
            <td class="resp-watch">WATCH</td>
            <td>Increase sampling. River filling rapidly. Could reach ALERT zone soon.</td>
        </tr>
        <tr>
            <td class="zone-alert">ALERT</td>
            <td>SLOW</td>
            <td>NO</td>
            <td class="resp-watch">WATCH</td>
            <td>Elevated logging. Monitor closely.</td>
        </tr>
        <tr>
            <td class="zone-alert">ALERT</td>
            <td>SLOW</td>
            <td>YES</td>
            <td class="resp-watch">WATCH</td>
            <td>Steady rise in ALERT zone. Increase sampling.</td>
        </tr>
        <tr>
            <td class="zone-alert">ALERT</td>
            <td>MODERATE</td>
            <td>NO</td>
            <td class="resp-watch">WATCH</td>
            <td>May be transient. Watch next 2 readings.</td>
        </tr>
        <tr>
            <td class="zone-alert">ALERT</td>
            <td>MODERATE</td>
            <td>YES</td>
            <td class="resp-warning">WARNING</td>
            <td>SMS to District Office. Rising through ALERT zone consistently.</td>
        </tr>
        <tr>
            <td class="zone-alert">ALERT</td>
            <td>FAST</td>
            <td>NO</td>
            <td class="resp-watch">WATCH</td>
            <td>Single fast reading. Could be noise. Wait for confirmation.</td>
        </tr>
        <tr>
            <td class="zone-alert">ALERT</td>
            <td>FAST</td>
            <td>YES</td>
            <td class="resp-warning">WARNING</td>
            <td>SMS to District Office. Fast sustained rise — will reach WARNING soon.</td>
        </tr>
        <tr>
            <td class="zone-warning">WARNING</td>
            <td>SLOW</td>
            <td>NO</td>
            <td class="resp-warning">WARNING</td>
            <td>SMS to District Office. Already high water.</td>
        </tr>
        <tr>
            <td class="zone-warning">WARNING</td>
            <td>SLOW</td>
            <td>YES</td>
            <td class="resp-flood">FLOOD ALERT</td>
            <td>SMS to District + Panchayat. Slow but persistent rise. Overflow hours away.</td>
        </tr>
        <tr>
            <td class="zone-warning">WARNING</td>
            <td>MODERATE</td>
            <td>NO</td>
            <td class="resp-warning">WARNING</td>
            <td>SMS to District. Might be transient at high level.</td>
        </tr>
        <tr>
            <td class="zone-warning">WARNING</td>
            <td>MODERATE</td>
            <td>YES</td>
            <td class="resp-flood">FLOOD ALERT</td>
            <td>SMS + escalation. Consistent rise toward DANGER.</td>
        </tr>
        <tr>
            <td class="zone-warning">WARNING</td>
            <td>FAST</td>
            <td>NO</td>
            <td class="resp-flood">FLOOD ALERT</td>
            <td>Even unsustained, FAST rise in WARNING zone is dangerous. Alert immediately.</td>
        </tr>
        <tr>
            <td class="zone-warning">WARNING</td>
            <td>FAST</td>
            <td>YES</td>
            <td class="resp-critical">CRITICAL</td>
            <td>Full escalation: SMS + Voice Call + NDRF. River will breach within minutes.</td>
        </tr>
        <tr>
            <td class="zone-danger">DANGER</td>
            <td>SLOW</td>
            <td>NO</td>
            <td class="resp-flood">FLOOD ALERT</td>
            <td>Already overflowing. Full alert regardless of rate or trend.</td>
        </tr>
        <tr>
            <td class="zone-danger">DANGER</td>
            <td>SLOW</td>
            <td>YES</td>
            <td class="resp-critical">CRITICAL</td>
            <td>Overflowing and still rising. Maximum escalation.</td>
        </tr>
        <tr>
            <td class="zone-danger">DANGER</td>
            <td>MODERATE</td>
            <td>NO</td>
            <td class="resp-critical">CRITICAL</td>
            <td>Overflowing with significant inflow. CRITICAL.</td>
        </tr>
        <tr>
            <td class="zone-danger">DANGER</td>
            <td>MODERATE</td>
            <td>YES</td>
            <td class="resp-critical">CRITICAL</td>
            <td>Maximum emergency. All tiers. Voice calls.</td>
        </tr>
        <tr>
            <td class="zone-danger">DANGER</td>
            <td>FAST</td>
            <td>NO</td>
            <td class="resp-critical">CRITICAL</td>
            <td>Maximum emergency regardless of sustained status.</td>
        </tr>
        <tr>
            <td class="zone-danger">DANGER</td>
            <td>FAST</td>
            <td>YES</td>
            <td class="resp-critical">CRITICAL</td>
            <td>Catastrophic scenario. All communication channels activated simultaneously.</td>
        </tr>
    </tbody>
</table>

</body>
</html>
```

---

### Table 2: Response Level Definitions

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Response Level Definitions</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #1a1a2e;
            color: #ffffff;
            padding: 14px 12px;
            text-align: left;
            border: 1px solid #333;
        }
        tbody td {
            padding: 12px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
    </style>
</head>
<body>

<table>
    <caption>Response Level Definitions and System Behavior</caption>
    <thead>
        <tr>
            <th>Response Level</th>
            <th>System Behavior</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>NORMAL</strong></td>
            <td>Routine operation. Log data. Transmit per normal schedule. No alerts sent.</td>
        </tr>
        <tr>
            <td><strong>WATCH</strong></td>
            <td>Increase sampling frequency. No external alerts sent. Internal flag set. System is paying attention. Data transmitted more frequently to dashboard.</td>
        </tr>
        <tr>
            <td><strong>WARNING</strong></td>
            <td>SMS sent to Tier 1 contacts (District CWC Office). Sampling and transmission at elevated rate. Dashboard shows yellow indicator.</td>
        </tr>
        <tr>
            <td><strong>FLOOD ALERT</strong></td>
            <td>SMS to Tier 1 + Tier 2 (Panchayat, District Collector). GPRS transmission every 5 minutes. Dashboard shows orange indicator. Wait 15 minutes for acknowledgment SMS.</td>
        </tr>
        <tr>
            <td><strong>CRITICAL</strong></td>
            <td>SMS to Tier 1 + Tier 2 + Tier 3 (State Control Room, NDRF). Voice calls initiated if no SMS acknowledgment. Maximum sampling rate (2 min). Maximum transmit rate (2 min). RED LED flashing continuously. Dashboard shows red indicator.</td>
        </tr>
    </tbody>
</table>

</body>
</html>
```

---

### Table 3: Per-Operation Energy Cost

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Per-Operation Energy Cost</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #1a1a2e;
            color: #ffffff;
            padding: 14px 12px;
            text-align: center;
            border: 1px solid #333;
        }
        thead th:first-child {
            text-align: left;
        }
        tbody td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        tbody td:first-child {
            text-align: left;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .subtotal {
            font-weight: bold;
            background-color: #e8eaf6 !important;
        }
        .ratio {
            font-weight: bold;
            background-color: #fff3e0 !important;
        }
    </style>
</head>
<body>

<table>
    <caption>Per-Operation Energy Cost Breakdown</caption>
    <thead>
        <tr>
            <th>Operation</th>
            <th>Power Draw (W)</th>
            <th>Duration (sec)</th>
            <th>Energy Cost (Wh)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Wake Raspberry Pi from idle</td>
            <td>4.0</td>
            <td>3</td>
            <td>0.0033</td>
        </tr>
        <tr>
            <td>Read sensors (I2C + GPIO)</td>
            <td>0.5</td>
            <td>2</td>
            <td>0.0003</td>
        </tr>
        <tr>
            <td>Process data (calculate + log)</td>
            <td>4.0</td>
            <td>2</td>
            <td>0.0022</td>
        </tr>
        <tr class="subtotal">
            <td>SENSOR READING TOTAL</td>
            <td>—</td>
            <td>7</td>
            <td>0.0058</td>
        </tr>
        <tr>
            <td>GSM module wake + register</td>
            <td>3.0</td>
            <td>10</td>
            <td>0.0083</td>
        </tr>
        <tr>
            <td>GPRS data transmit</td>
            <td>6.0</td>
            <td>20</td>
            <td>0.0333</td>
        </tr>
        <tr class="subtotal">
            <td>TRANSMISSION TOTAL</td>
            <td>—</td>
            <td>30</td>
            <td>0.0416</td>
        </tr>
        <tr class="ratio">
            <td>RATIO (Transmit / Sample)</td>
            <td>—</td>
            <td>4.3×</td>
            <td>7.2×</td>
        </tr>
    </tbody>
</table>

</body>
</html>
```

---

### Table 4: Adaptive Sampling Intervals

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Adaptive Sampling Intervals</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #1a1a2e;
            color: #ffffff;
            padding: 14px 12px;
            text-align: left;
            border: 1px solid #333;
        }
        tbody td {
            padding: 12px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .override {
            background-color: #ffebee !important;
            font-weight: bold;
        }
    </style>
</head>
<body>

<table>
    <caption>Adaptive Sampling and Transmission Intervals by Condition</caption>
    <thead>
        <tr>
            <th>Condition</th>
            <th>Sample Interval</th>
            <th>Transmit Interval</th>
            <th>Rationale</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>NORMAL zone, SLOW rate, Battery &gt; 20%</td>
            <td>30 min</td>
            <td>60 min</td>
            <td>Nothing happening. Maximize battery life. Sample 2× per transmit to catch onset of change.</td>
        </tr>
        <tr>
            <td>NORMAL zone, MODERATE or FAST rate, Battery &gt; 20%</td>
            <td>15 min</td>
            <td>30 min</td>
            <td>Rate interesting but level safe. Sample faster to build trend data.</td>
        </tr>
        <tr>
            <td>ALERT zone, any rate, Battery &gt; 20%</td>
            <td>10 min</td>
            <td>15 min</td>
            <td>Situation worth monitoring. Dashboard needs frequent updates. Trend data critical.</td>
        </tr>
        <tr>
            <td>WARNING zone OR (FAST + Sustained), Battery &gt; 10%</td>
            <td>5 min</td>
            <td>5 min</td>
            <td>Danger approaching. Every reading transmitted immediately. Authorities need real-time data.</td>
        </tr>
        <tr>
            <td>DANGER zone, Battery &gt; 5%</td>
            <td>2 min</td>
            <td>2 min</td>
            <td>Maximum urgency. Lives at risk. Accept high power draw.</td>
        </tr>
        <tr>
            <td>LOW BATTERY (&lt; 20%) + NORMAL zone</td>
            <td>60 min</td>
            <td>120 min</td>
            <td>Stretch remaining power. Accept lower resolution since risk is low.</td>
        </tr>
        <tr>
            <td>LOW BATTERY (&lt; 20%) + ALERT zone</td>
            <td>15 min</td>
            <td>30 min</td>
            <td>Compromise: slower than ideal but still monitoring.</td>
        </tr>
        <tr class="override">
            <td>LOW BATTERY (&lt; 20%) + WARNING or DANGER zone</td>
            <td>5 min</td>
            <td>5 min</td>
            <td>FLOOD DETECTION OVERRIDES POWER CONSERVATION. Device may die but will die transmitting warnings.</td>
        </tr>
        <tr>
            <td>CRITICAL BATTERY (&lt; 10%) + NORMAL zone</td>
            <td>120 min</td>
            <td>240 min (SMS only)</td>
            <td>Near shutdown. Absolute minimum. No GPRS. Single SMS every 4 hours.</td>
        </tr>
        <tr class="override">
            <td>CRITICAL BATTERY (&lt; 10%) + WARNING or DANGER zone</td>
            <td>5 min</td>
            <td>5 min (SMS only)</td>
            <td>Dying device, dangerous river. No GPRS. SMS-only alerts every 5 min until battery dies.</td>
        </tr>
    </tbody>
</table>

</body>
</html>
```

---

### Table 5: Power Consumption Comparison

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Power Consumption Comparison</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #1a1a2e;
            color: #ffffff;
            padding: 14px 10px;
            text-align: center;
            border: 1px solid #333;
            font-size: 0.9em;
        }
        thead th:first-child {
            text-align: left;
        }
        tbody td {
            padding: 12px 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        tbody td:first-child {
            text-align: left;
            font-weight: bold;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .highlight {
            background-color: #e8f5e9 !important;
            font-weight: bold;
        }
        .flood-row {
            background-color: #fff3e0 !important;
        }
        tfoot td {
            padding: 12px;
            border: 1px solid #ddd;
            font-style: italic;
            font-size: 0.85em;
            background-color: #fafafa;
        }
    </style>
</head>
<body>

<table>
    <caption>Daily Power Consumption: Fixed vs. Adaptive Sampling Strategies (240Wh Battery, 40.8Wh Baseline)</caption>
    <thead>
        <tr>
            <th>Strategy</th>
            <th>Samples / Day</th>
            <th>Transmissions / Day</th>
            <th>Sensor Energy (Wh)</th>
            <th>Transmit Energy (Wh)</th>
            <th>Total Active (Wh/day)</th>
            <th>Battery Life (days)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Fixed 2 min</td>
            <td>720</td>
            <td>720</td>
            <td>4.2</td>
            <td>30.0</td>
            <td>75.0</td>
            <td>2.1</td>
        </tr>
        <tr>
            <td>Fixed 5 min</td>
            <td>288</td>
            <td>288</td>
            <td>1.7</td>
            <td>12.0</td>
            <td>54.5</td>
            <td>3.4</td>
        </tr>
        <tr>
            <td>Fixed 15 min</td>
            <td>96</td>
            <td>96</td>
            <td>0.6</td>
            <td>4.0</td>
            <td>45.4</td>
            <td>4.3</td>
        </tr>
        <tr>
            <td>Fixed 30 min</td>
            <td>48</td>
            <td>48</td>
            <td>0.3</td>
            <td>2.0</td>
            <td>43.1</td>
            <td>4.6</td>
        </tr>
        <tr>
            <td>Fixed 60 min</td>
            <td>24</td>
            <td>24</td>
            <td>0.1</td>
            <td>1.0</td>
            <td>41.9</td>
            <td>4.8</td>
        </tr>
        <tr class="highlight">
            <td>ADAPTIVE (calm period)</td>
            <td>48</td>
            <td>24</td>
            <td>0.3</td>
            <td>1.0</td>
            <td>42.1</td>
            <td>4.7</td>
        </tr>
        <tr class="flood-row">
            <td>ADAPTIVE (flood event)</td>
            <td>288</td>
            <td>288</td>
            <td>1.7</td>
            <td>12.0</td>
            <td>54.5</td>
            <td>3.4</td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="7">Battery life = 240Wh ÷ (Active Energy + 40.8Wh baseline). Adaptive calm ≈ Fixed 60min power with 30-min sample resolution. Adaptive flood ≈ Fixed 5min power with 5-min resolution. Annual weighted average (350 calm + 15 flood days): 42.6 Wh/day = 4.7 days autonomy.</td>
        </tr>
    </tfoot>
</table>

</body>
</html>
```

---

### Table 6: Scenario A — Dry-Season False Alarm

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Scenario A: Dry-Season False Alarm</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        h2 {
            color: #1a1a2e;
        }
        p {
            color: #333;
            line-height: 1.6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #2e7d32;
            color: #ffffff;
            padding: 12px 8px;
            text-align: center;
            border: 1px solid #1b5e20;
            font-size: 0.85em;
        }
        thead th:first-child {
            text-align: left;
        }
        tbody td {
            padding: 10px 8px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 0.9em;
        }
        tbody td:first-child {
            text-align: left;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .result {
            margin-top: 16px;
            padding: 16px;
            background-color: #e8f5e9;
            border-left: 4px solid #2e7d32;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Scenario A: Dry-Season False Alarm — Rajasthan Tributary</h2>
<p>Site thresholds: ALERT = 60cm, WARNING = 100cm, DANGER = 140cm</p>

<table>
    <caption>Reading-by-Reading Analysis</caption>
    <thead>
        <tr>
            <th>Time</th>
            <th>Level (cm)</th>
            <th>Rate (cm/15min)</th>
            <th>Zone</th>
            <th>Sustained</th>
            <th>Decision</th>
            <th>Sample Interval</th>
            <th>Transmit Interval</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>06:00</td>
            <td>5</td>
            <td>—</td>
            <td>NORMAL</td>
            <td>—</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>06:30</td>
            <td>5</td>
            <td>0</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>07:00</td>
            <td>8</td>
            <td>+3</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>07:30</td>
            <td>19</td>
            <td>+11</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>15 min</td>
            <td>30 min</td>
        </tr>
        <tr>
            <td>08:00</td>
            <td>32</td>
            <td>+13</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>WATCH</td>
            <td>15 min</td>
            <td>30 min</td>
        </tr>
        <tr>
            <td>08:15</td>
            <td>38</td>
            <td>+6</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>WATCH</td>
            <td>15 min</td>
            <td>30 min</td>
        </tr>
        <tr>
            <td>08:30</td>
            <td>40</td>
            <td>+2</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>08:45</td>
            <td>41</td>
            <td>+1</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>09:15</td>
            <td>42</td>
            <td>+0.5</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>09:45</td>
            <td>41</td>
            <td>−0.5</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
    </tbody>
</table>

<div class="result">
    RESULT: Water rose from 5cm to 42cm (fast initially). System entered WATCH briefly, 
    NEVER sent any SMS. No false alarm. No wasted SMS credits. No officer woken up. 
    Correct behavior — the river was just filling from dry season low.
</div>

</body>
</html>
```

---

### Table 7: Scenario B — Slow Monsoon Rise

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Scenario B: Slow Monsoon Rise</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        h2 {
            color: #1a1a2e;
        }
        p {
            color: #333;
            line-height: 1.6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #e65100;
            color: #ffffff;
            padding: 12px 8px;
            text-align: center;
            border: 1px solid #bf360c;
            font-size: 0.85em;
        }
        thead th:first-child {
            text-align: left;
        }
        tbody td {
            padding: 10px 8px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 0.9em;
        }
        tbody td:first-child {
            text-align: left;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .escalation {
            background-color: #ffccbc !important;
            font-weight: bold;
        }
        .critical {
            background-color: #ffcdd2 !important;
            font-weight: bold;
        }
        .result {
            margin-top: 16px;
            padding: 16px;
            background-color: #fff3e0;
            border-left: 4px solid #e65100;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Scenario B: Slow Monsoon Rise — Brahmaputra</h2>
<p>Site thresholds: ALERT = 800cm, WARNING = 900cm, DANGER = 950cm</p>

<table>
    <caption>Reading-by-Reading Analysis</caption>
    <thead>
        <tr>
            <th>Time</th>
            <th>Level (cm)</th>
            <th>Rate (cm/15min)</th>
            <th>Zone</th>
            <th>Sustained</th>
            <th>Decision</th>
            <th>Sample Interval</th>
            <th>Transmit Interval</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Day 1 06:00</td>
            <td>750</td>
            <td>+0.5</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>Day 1 18:00</td>
            <td>780</td>
            <td>+1.0</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>Day 2 06:00</td>
            <td>805</td>
            <td>+0.8</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WATCH</td>
            <td>10 min</td>
            <td>15 min</td>
        </tr>
        <tr class="escalation">
            <td>Day 2 18:00</td>
            <td>830</td>
            <td>+1.0</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>10 min</td>
            <td>15 min</td>
        </tr>
        <tr class="escalation">
            <td>Day 3 06:00</td>
            <td>870</td>
            <td>+1.3</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>10 min</td>
            <td>15 min</td>
        </tr>
        <tr class="escalation">
            <td>Day 3 18:00</td>
            <td>905</td>
            <td>+1.2</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>FLOOD ALERT</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr class="escalation">
            <td>Day 4 06:00</td>
            <td>935</td>
            <td>+1.0</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>FLOOD ALERT</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr class="critical">
            <td>Day 4 18:00</td>
            <td>952</td>
            <td>+0.6</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
    </tbody>
</table>

<div class="result">
    RESULT: Rate NEVER exceeded 1.5cm/15min — well below the naive 5cm/15min threshold. 
    A rate-only system would have NEVER triggered any alert. This system correctly escalated 
    through every tier over 4 days. District office had 2 full days of advance warning. 
    This is the scenario that justifies zone-based detection.
</div>

</body>
</html>
```

---

### Table 8: Scenario C — Flash Flood

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Scenario C: Flash Flood</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        h2 {
            color: #1a1a2e;
        }
        p {
            color: #333;
            line-height: 1.6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #b71c1c;
            color: #ffffff;
            padding: 12px 8px;
            text-align: center;
            border: 1px solid #7f0000;
            font-size: 0.85em;
        }
        thead th:first-child {
            text-align: left;
        }
        tbody td {
            padding: 10px 8px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 0.9em;
        }
        tbody td:first-child {
            text-align: left;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .critical {
            background-color: #ffcdd2 !important;
            font-weight: bold;
        }
        .receding {
            background-color: #c8e6c9 !important;
        }
        .clear {
            background-color: #a5d6a7 !important;
            font-weight: bold;
        }
        .result {
            margin-top: 16px;
            padding: 16px;
            background-color: #ffebee;
            border-left: 4px solid #b71c1c;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Scenario C: Flash Flood — Small Tributary, Uttarakhand</h2>
<p>Site thresholds: ALERT = 40cm, WARNING = 65cm, DANGER = 85cm</p>

<table>
    <caption>Reading-by-Reading Analysis</caption>
    <thead>
        <tr>
            <th>Time</th>
            <th>Level (cm)</th>
            <th>Rate (cm/15min)</th>
            <th>Zone</th>
            <th>Sustained</th>
            <th>Decision</th>
            <th>Sample Interval</th>
            <th>Transmit Interval</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>14:00</td>
            <td>15</td>
            <td>0</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>14:30</td>
            <td>16</td>
            <td>+1</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>15:00</td>
            <td>25</td>
            <td>+9</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>15 min</td>
            <td>30 min</td>
        </tr>
        <tr>
            <td>15:15</td>
            <td>38</td>
            <td>+13</td>
            <td>NORMAL</td>
            <td>YES</td>
            <td>WATCH</td>
            <td>15 min</td>
            <td>30 min</td>
        </tr>
        <tr>
            <td>15:30</td>
            <td>44</td>
            <td>+6</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr>
            <td>15:35</td>
            <td>52</td>
            <td>+24</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr>
            <td>15:40</td>
            <td>61</td>
            <td>+27</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr class="critical">
            <td>15:45</td>
            <td>72</td>
            <td>+33</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>15:47</td>
            <td>78</td>
            <td>+45</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>15:49</td>
            <td>83</td>
            <td>+37.5</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>15:51</td>
            <td>88</td>
            <td>+37.5</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>15:55</td>
            <td>91</td>
            <td>+11.25</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="receding">
            <td>16:10</td>
            <td>89</td>
            <td>−1.3</td>
            <td>DANGER</td>
            <td>NO</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="receding">
            <td>16:30</td>
            <td>78</td>
            <td>−5.5</td>
            <td>WARNING</td>
            <td>NO</td>
            <td>FLOOD ALERT</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr class="receding">
            <td>17:30</td>
            <td>55</td>
            <td>−3.8</td>
            <td>ALERT</td>
            <td>NO</td>
            <td>WATCH</td>
            <td>10 min</td>
            <td>15 min</td>
        </tr>
        <tr class="clear">
            <td>19:30</td>
            <td>30</td>
            <td>−2.0</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
    </tbody>
</table>

<div class="result">
    RESULT: From first significant reading (15:00) to CRITICAL alert (15:45) = 45 minutes. 
    With adaptive sampling, once WATCH was entered, the system switched to faster sampling 
    and captured the rise in high resolution. System correctly escalated, correctly 
    de-escalated, and sent ALL CLEAR at 19:30. Total event duration: 5.5 hours.
</div>

</body>
</html>
```

---

### Table 9: Scenario D — Dam Release

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARUNA - Scenario D: Dam Release Event</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }
        h2 {
            color: #1a1a2e;
        }
        p {
            color: #333;
            line-height: 1.6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            background-color: #fff;
        }
        caption {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 12px;
            color: #1a1a2e;
            text-align: left;
        }
        thead th {
            background-color: #4a148c;
            color: #ffffff;
            padding: 12px 8px;
            text-align: center;
            border: 1px solid #311b92;
            font-size: 0.85em;
        }
        thead th:first-child {
            text-align: left;
        }
        tbody td {
            padding: 10px 8px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 0.9em;
        }
        tbody td:first-child {
            text-align: left;
        }
        tbody tr:nth-child(even) {
            background-color: #f0f4f8;
        }
        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tbody tr:hover {
            background-color: #e3edf7;
        }
        .gap {
            background-color: #fff9c4 !important;
            font-style: italic;
        }
        .critical {
            background-color: #ffcdd2 !important;
            font-weight: bold;
        }
        .result {
            margin-top: 16px;
            padding: 16px;
            background-color: #f3e5f5;
            border-left: 4px solid #4a148c;
            font-weight: bold;
        }
        .note {
            margin-top: 16px;
            padding: 16px;
            background-color: #fff8e1;
            border-left: 4px solid #f57f17;
            font-size: 0.95em;
        }
    </style>
</head>
<body>

<h2>Scenario D: Dam Release Event</h2>
<p>Site thresholds: ALERT = 100cm, WARNING = 160cm, DANGER = 200cm</p>

<table>
    <caption>Reading-by-Reading Analysis</caption>
    <thead>
        <tr>
            <th>Time</th>
            <th>Level (cm)</th>
            <th>Rate (cm/15min)</th>
            <th>Zone</th>
            <th>Sustained</th>
            <th>Decision</th>
            <th>Sample Interval</th>
            <th>Transmit Interval</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>10:00</td>
            <td>45</td>
            <td>0</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>10:30</td>
            <td>45</td>
            <td>0</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr>
            <td>11:00</td>
            <td>46</td>
            <td>+1</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL</td>
            <td>30 min</td>
            <td>60 min</td>
        </tr>
        <tr class="gap">
            <td>11:30</td>
            <td>85</td>
            <td>+39</td>
            <td>NORMAL</td>
            <td>NO</td>
            <td>NORMAL*</td>
            <td>15 min</td>
            <td>30 min</td>
        </tr>
        <tr>
            <td>11:45</td>
            <td>130</td>
            <td>+45</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr>
            <td>11:50</td>
            <td>155</td>
            <td>+75</td>
            <td>ALERT</td>
            <td>YES</td>
            <td>WARNING</td>
            <td>5 min</td>
            <td>5 min</td>
        </tr>
        <tr class="critical">
            <td>11:55</td>
            <td>175</td>
            <td>+60</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>11:57</td>
            <td>192</td>
            <td>+127.5</td>
            <td>WARNING</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>11:59</td>
            <td>205</td>
            <td>+97.5</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>12:01</td>
            <td>215</td>
            <td>+75</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>12:05</td>
            <td>225</td>
            <td>+37.5</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr class="critical">
            <td>12:15</td>
            <td>230</td>
            <td>+7.5</td>
            <td>DANGER</td>
            <td>YES</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
        <tr>
            <td>12:30</td>
            <td>228</td>
            <td>−1.3</td>
            <td>DANGER</td>
            <td>NO</td>
            <td>CRITICAL</td>
            <td>2 min</td>
            <td>2 min</td>
        </tr>
    </tbody>
</table>

<div class="note">
    <strong>*Critical Note on 11:30 Reading:</strong> At 11:30, water jumped from 46cm to 85cm 
    (rate = 39cm/15min normalized). The system classified this as NORMAL because: Zone = NORMAL 
    (85cm &lt; ALERT at 100cm) and Sustained = NO (previous 3 readings were flat). However, the 
    adaptive sampling system immediately reduced the interval to 15 minutes due to the FAST rate 
    detection. This meant the next reading came at 11:45 instead of 12:00, saving 15 minutes of 
    response time.<br><br>
    <strong>Proposed Override Rule:</strong> If rate &gt; 30cm/15min (extreme rate) AND zone is 
    ALERT or above, skip the sustained check entirely. A 30cm/15min rate is physically impossible 
    from noise, waves, or boats — it can ONLY come from a dam release or landslide dam breach.
</div>

<div class="result">
    RESULT: From dam release wave arrival (11:30) to CRITICAL alert (11:55) = 25 minutes. 
    The adaptive sampling system compressed this window by switching to 15-min then 5-min then 
    2-min intervals as the situation escalated. Without adaptive sampling (fixed 30-min), the 
    system would not have reached CRITICAL until 12:30 — a full 35 minutes later.
</div>

</body>
</html>
```

---



# VARUNA Field Device — Complete Technical Documentation

## Dual-MCU Architecture: XIAO ESP32-C3 (Brain) + STM32 Blue Pill (Comms)

---

# SECTION 1: SYSTEM OVERVIEW

## 1.1 Purpose

VARUNA is an autonomous, battery-powered water level monitoring device designed for deployment in Indian rivers. It measures water level using an MPU6050 IMU mounted on a tethered floating buoy, detects flood conditions using a dual-threshold algorithm with sustained-rise confirmation, transmits data via GSM/GPRS through a SIM800L module, and operates for 4-10 months on a single battery charge depending on flood activity.

## 1.2 Architecture Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                    VARUNA FIELD DEVICE                           │
│                                                                 │
│  ┌──────────────┐         ┌──────────────────┐                  │
│  │  XIAO        │  UART   │  STM32           │                  │
│  │  ESP32-C3    │◄───────►│  Blue Pill        │                  │
│  │              │         │                  │                  │
│  │  BRAIN       │  INT    │  COMMS SLAVE     │                  │
│  │  - Sensors   │◄────────│  - SIM800L       │                  │
│  │  - Logic     │         │  - GPS           │                  │
│  │  - Storage   │         │  - SMS           │                  │
│  │  - Sleep     │         │  - GPRS          │                  │
│  └──────┬───────┘         └──────────────────┘                  │
│         │ I2C                                                   │
│    ┌────┴────────────────┐                                      │
│    │  MPU6050 (0x69)     │                                      │
│    │  BMP180  (0x77)     │                                      │
│    │  DS3231  (0x68)     │                                      │
│    └─────────────────────┘                                      │
│                                                                 │
│  ┌─────────────────────┐                                        │
│  │  8×18650 1S8P       │                                        │
│  │  3.7V  20,000mAh    │                                        │
│  │  74 Wh total        │                                        │
│  └─────────────────────┘                                        │
└─────────────────────────────────────────────────────────────────┘
```

## 1.3 Role Assignment

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  XIAO ESP32-C3 (BRAIN)              STM32 BLUE PILL (COMMS SLAVE)       │
│  ─────────────────────              ─────────────────────────────       │
│  Always present (deep sleep)        Normally HARD OFF via MOSFET        │
│  Wakes on timer                     Powered on only for transmission    │
│  Reads MPU6050, BMP180, DS3231      Handles SIM800L AT commands         │
│  Runs flood detection algorithm     Handles GPS fix acquisition         │
│  Runs adaptive sampling logic       Sends/receives SMS                  │
│  Stores data to flash               Sends GPRS HTTP POST               │
│  Decides if transmission needed     Parses incoming SMS commands        │
│  Dumps data to STM32 via UART       Returns results to XIAO            │
│  Goes back to deep sleep            Gets powered OFF when done          │
│                                                                         │
│  Awake: 5-7 seconds per cycle       Awake: 60-120 sec per transmit     │
│  Sleep current: 5 μA                Off current: 0 μA (hard off)       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

# SECTION 2: COMPLETE HARDWARE SPECIFICATION

## 2.1 Bill of Materials

```
┌────────────────────────────┬─────────────────────────────┬─────┬───────────────────────────┐
│ Component                  │ Specification               │ Qty │ Purpose                   │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ XIAO ESP32-C3              │ RISC-V 160MHz, 400KB SRAM   │  1  │ Main processor (brain)    │
│                            │ 4MB flash, deep sleep 5μA   │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ STM32F103C8T6 Blue Pill    │ ARM Cortex-M3 72MHz         │  1  │ Communication controller  │
│                            │ 64KB flash, 20KB SRAM       │     │                           │
│                            │ 3 hardware UARTs            │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ MPU6050 Breakout           │ 3-axis accel + 3-axis gyro  │  1  │ Tilt angle measurement    │
│                            │ I2C, ±2g/±250°/s            │     │ Water level calculation   │
│                            │ AD0 pin pulled HIGH → 0x69  │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ BMP180 (HW-116) Breakout   │ Barometric pressure sensor  │  1  │ Underwater detection      │
│                            │ I2C, 300-1100 hPa range     │     │ Atmospheric pressure      │
│                            │ Address: 0x77               │     │ Temperature monitoring     │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ DS3231 RTC Module          │ ±2ppm accuracy              │  1  │ Accurate timestamps       │
│                            │ I2C, coin cell backup       │     │ Survives power loss       │
│                            │ Address: 0x68               │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ SIM800L Module             │ GSM/GPRS 2G                 │  1  │ SMS alerts + GPRS data    │
│                            │ Quad-band 850/900/1800/1900 │     │ Operating: 3.4V-4.4V      │
│                            │ Peak current: 2A            │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ NEO-6M GPS Module          │ GPS L1 frequency            │  1  │ Location on tamper/detach │
│                            │ UART 9600 baud              │     │ Cold start: 27s typical   │
│                            │ Backup battery on module    │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ 18650 Li-Ion Cells         │ 3.7V 2500mAh each           │  8  │ Power source              │
│                            │ Wired 1S8P (parallel)       │     │ Total: 3.7V 20,000mAh    │
│                            │                             │     │ Energy: 74 Wh             │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ XIAO Seeed Power Board     │ Battery management          │  1  │ Charging, regulation      │
│                            │ 3.3V LDO output             │     │ Battery protection        │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ P-Channel MOSFET           │ SI2301 or equivalent        │  2  │ Hard power switches       │
│                            │ Low Rds(on), logic-level    │     │ Sensor rail + Comms rail  │
│                            │ gate                        │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ 10kΩ Pull-up Resistors     │ 1/4W                        │  2  │ MOSFET gate pull-ups      │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ 100kΩ + 100kΩ Resistors    │ 1/4W                        │  2  │ Battery voltage divider   │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ 1000μF Electrolytic Cap    │ 6.3V or higher              │  1  │ SIM800L transmit spike    │
│                            │                             │     │ absorption                │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ 100μF Electrolytic Cap     │ 6.3V or higher              │  1  │ SIM800L secondary filter  │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ ePTFE Membrane Patch       │ IP67 breathable vent        │  1  │ Waterproof BMP180 port    │
│                            │ Adhesive backing            │     │ Allows air, blocks water  │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ Waterproof Enclosure       │ IP67 rated, ABS/PC          │  1  │ Electronics housing       │
│                            │ Cable glands for wires      │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ OLP Rope/Cable             │ Stainless steel cable       │  1  │ Tether buoy to anchor     │
│                            │ User-specified length       │     │                           │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ Floating Buoy              │ Closed-cell EVA foam        │  1  │ Floats on water surface   │
│                            │ UV-resistant                │     │ MPU6050 mounted on top    │
├────────────────────────────┼─────────────────────────────┼─────┼───────────────────────────┤
│ Anchor Assembly            │ Stainless steel             │  1  │ Fixed to riverbed/bank    │
│                            │ Concrete base               │     │                           │
└────────────────────────────┴─────────────────────────────┴─────┴───────────────────────────┘
```

## 2.2 Complete Wiring Diagram

```
                    BATTERY PACK (8×18650 1S8P)
                    3.0V (empty) — 3.7V (nominal) — 4.2V (full)
                         │
                         │
              ┌──────────┴──────────┐
              │                     │
              │  XIAO POWER BOARD   │
              │  (Battery Mgmt)     │
              │                     │
              │  BAT+ ────────────────────────┐
              │  BAT- ────────────────────────┐│
              │                     │         ││
              │  3.3V OUT ──┐       │         ││
              │  GND    ──┐ │       │         ││
              └───────────┼─┼───────┘         ││
                          │ │                 ││
                ┌─────────┘ │                 ││
                │    ┌──────┘                 ││
                │    │                        ││
           GND  │  3.3V                       ││
                │    │                        ││
    ┌───────────┴────┴───────────┐            ││
    │     XIAO ESP32-C3          │            ││
    │                            │            ││
    │  D0 (GPIO2)  ──── MOSFET_1 GATE ──┐    ││
    │  D1 (GPIO3)  ──── MOSFET_2 GATE ──┼─┐  ││
    │  D2 (GPIO4)  ──── VBAT DIVIDER ───┘ │  ││
    │  D3 (GPIO5)  ──── STM32 PB0 (INT)   │  ││
    │  D4 (GPIO6)  ──── I2C SDA ──────────┼──┼┼──┐
    │  D5 (GPIO7)  ──── I2C SCL ──────────┼──┼┼──┼──┐
    │  D6 (GPIO21) ──── USB DEBUG TX      │  ││  │  │
    │  D7 (GPIO20) ──── USB DEBUG RX      │  ││  │  │
    │  D8 (GPIO8)  ──── STM32 PA10 (RX)   │  ││  │  │
    │  D9 (GPIO9)  ──── STM32 PA9  (TX)   │  ││  │  │
    │  D10(GPIO10) ──── FREE (spare)      │  ││  │  │
    │                            │         │  ││  │  │
    └────────────────────────────┘         │  ││  │  │
                                           │  ││  │  │
                                           │  ││  │  │
    ═══════════════════════════════════════╪══╪╪══╪══╪═══
    MOSFET_1 (SENSOR POWER RAIL)          │  ││  │  │
    ═══════════════════════════════════════╪══╪╪══╪══╪═══
                                           │  ││  │  │
    P-MOSFET SI2301                        │  ││  │  │
    ┌──────────┐                           │  ││  │  │
    │ Source ───┤── 3.3V (from power board) │  ││  │  │
    │ Gate  ────┤── D0 + 10kΩ pull-up ─────┘  ││  │  │
    │ Drain ────┤── SENSOR 3.3V RAIL           ││  │  │
    └──────────┘         │                     ││  │  │
                         │                     ││  │  │
              ┌──────────┴──────────┐          ││  │  │
              │                     │          ││  │  │
        ┌─────┴─────┐  ┌───────────┴───┐      ││  │  │
        │  MPU6050   │  │   BMP180      │      ││  │  │
        │  (0x69)    │  │   (0x77)      │      ││  │  │
        │            │  │               │      ││  │  │
        │  VCC ──────┤  │  VCC ─────────┤      ││  │  │
        │  GND ──────┤  │  GND ─────────┤      ││  │  │
        │  SDA ──────┼──┤  SDA ─────────┼──────┼┼──┘  │
        │  SCL ──────┼──┤  SCL ─────────┼──────┼┼─────┘
        │  AD0 ── 3.3V  │               │      ││
        │  (=0x69)   │  │  ePTFE over   │      ││
        └────────────┘  │  sensor port  │      ││
                        └───────────────┘      ││
                                               ││
    DS3231 RTC (always on via coin cell):       ││
    ┌────────────┐                              ││
    │  DS3231    │                              ││
    │  (0x68)    │                              ││
    │            │                              ││
    │  VCC ── coin cell (independent)           ││
    │  GND ── system GND                        ││
    │  SDA ─────────────────────────────────────┼┤ (same I2C bus)
    │  SCL ─────────────────────────────────────┤│ (same I2C bus)
    │  SQW ── not connected                     ││
    └────────────┘                              ││
                                                ││
    NOTE: DS3231 powered by its own coin cell.  ││
    I2C pull-ups provided by one of the modules.││
    DS3231 is readable on I2C even when sensor  ││
    MOSFET is OFF because it has its own power. ││
                                                ││
                                                ││
    ═════════════════════════════════════════════╪╪═══
    MOSFET_2 (COMMS POWER RAIL)                 ││
    ═════════════════════════════════════════════╪╪═══
                                                ││
    P-MOSFET SI2301                             ││
    ┌──────────┐                                ││
    │ Source ───┤── 3.3V (for STM32 + GPS)      ││
    │ Gate  ────┤── D1 + 10kΩ pull-up ──────────┘│
    │ Drain ────┤── COMMS 3.3V RAIL               │
    └──────────┘         │                        │
                         │                        │
    ┌────────────────────┴───────────────┐        │
    │           STM32 BLUE PILL          │        │
    │                                    │        │
    │  3.3V ── COMMS RAIL               │        │
    │  GND  ── SYSTEM GND               │        │
    │                                    │        │
    │  PA9  (UART1 TX) ── XIAO D9 ──────┤────────┘
    │  PA10 (UART1 RX) ── XIAO D8       │
    │  PA2  (UART2 TX) ── SIM800L RX    │
    │  PA3  (UART2 RX) ── SIM800L TX    │
    │  PB10 (UART3 TX) ── (unused)      │
    │  PB11 (UART3 RX) ── GPS TX        │
    │  PB0  (GPIO OUT) ── XIAO D3 (INT) │
    │  PB1  (GPIO OUT) ── SIM800L RST   │
    │  PC13 (LED)       ── status LED   │
    │                                    │
    └────────────────────────────────────┘
              │                │
    ┌─────────┴────┐   ┌──────┴───────┐
    │  SIM800L     │   │  NEO-6M GPS  │
    │              │   │              │
    │  VCC ────────┤   │  VCC ────────┤── COMMS 3.3V RAIL
    │  *** NOTE ** │   │  GND ────────┤── SYSTEM GND
    │  SIM800L VCC │   │  TX  ────────┤── STM32 PB11
    │  connects    │   │  RX  ────────┤── (not connected)
    │  DIRECTLY to │   │              │
    │  BATTERY     │   └──────────────┘
    │  through a   │
    │  SEPARATE    │
    │  MOSFET      │
    │  (see below) │
    │              │
    │  GND ────────┤── SYSTEM GND
    │  TX  ────────┤── STM32 PA3
    │  RX  ────────┤── STM32 PA2
    │  RST ────────┤── STM32 PB1
    │              │
    └──────────────┘


    SIM800L POWER (SEPARATE FROM COMMS RAIL):

    BATTERY+ ── P-MOSFET_3 ──┬── SIM800L VCC
    (3.7V)      (controlled   │
                 by STM32     ├── 1000μF cap
                 PB1 or       │
                 tied to      ├── 100μF cap
                 MOSFET_2     │
                 gate)        └── GND
                 
    WHY SEPARATE: SIM800L needs 3.4V-4.4V and draws 2A peaks.
    The 3.3V regulator CANNOT supply this.
    SIM800L connects directly to the 3.7V battery pack.
    The 1000μF + 100μF capacitors absorb 2A transmit spikes.
    
    SIMPLIFICATION: MOSFET_3 gate can be tied to MOSFET_2 gate
    so both STM32 and SIM800L power on/off together.
    This uses no extra GPIO pin.


    BATTERY VOLTAGE MONITORING:

    BATTERY+ ──[100kΩ]──┬──[100kΩ]── GND
                        │
                        └── XIAO D2 (ADC)
    
    Divider ratio: 1:2
    At 4.2V battery: ADC reads 2.1V
    At 3.7V battery: ADC reads 1.85V
    At 3.0V battery: ADC reads 1.5V
    
    XIAO ADC range: 0-3.3V (12-bit = 0-4095)
    Battery voltage = ADC_reading × 2 × (3.3 / 4095)
```

## 2.3 I2C Address Map

```
┌──────────┬────────────────┬──────────────────────────────────────┐
│ Address  │ Device         │ Notes                                │
├──────────┼────────────────┼──────────────────────────────────────┤
│ 0x68     │ DS3231 RTC     │ Fixed address, cannot change         │
│          │                │ Powered by coin cell, always on I2C  │
├──────────┼────────────────┼──────────────────────────────────────┤
│ 0x69     │ MPU6050        │ AD0 pin connected to 3.3V            │
│          │                │ Powered by MOSFET_1 (sensor rail)    │
├──────────┼────────────────┼──────────────────────────────────────┤
│ 0x77     │ BMP180         │ Default address                      │
│          │                │ Powered by MOSFET_1 (sensor rail)    │
├──────────┼────────────────┼──────────────────────────────────────┤
│ 0x57     │ DS3231 EEPROM  │ AT24C32 on DS3231 board              │
│          │                │ Can be used for config backup         │
└──────────┴────────────────┴──────────────────────────────────────┘

No conflicts. All devices on same I2C bus.
```

---

# SECTION 3: POWER SYSTEM ARCHITECTURE

## 3.1 Power Flow Diagram

```
    8×18650 BATTERY PACK (1S8P, 3.7V 20Ah)
    ┌─────────────────────────────────────┐
    │  Cell 1 ─┐                          │
    │  Cell 2 ─┤                          │
    │  Cell 3 ─┤                          │
    │  Cell 4 ─┼── ALL IN PARALLEL ── BAT+│──┬──────────────────────────┐
    │  Cell 5 ─┤                     BAT- │──┤                          │
    │  Cell 6 ─┤                          │  │                          │
    │  Cell 7 ─┤                          │  │                          │
    │  Cell 8 ─┘                          │  │                          │
    └─────────────────────────────────────┘  │                          │
                                             │                          │
                              ┌──────────────┴──┐          ┌────────────┴───┐
                              │ XIAO POWER BOARD │          │  MOSFET_3      │
                              │                  │          │  (P-Channel)   │
                              │  Input: 3.0-4.2V │          │                │
                              │  Output: 3.3V    │          │  Gate: tied to │
                              │  Quiescent: 0.5mA│          │  MOSFET_2 gate │
                              │                  │          │                │
                              │  3.3V ───────┐   │          │  Drain: ───────┤
                              │  GND  ───────┤   │          │  SIM800L VCC   │
                              └──────────────┘   │          │  (3.4-4.4V)    │
                                    │        │   │          │                │
                                    │        │   │          │  1000μF + 100μF│
                                    │        │   │          │  caps to GND   │
                              ┌─────┴─┐      │   │          └────────────────┘
                              │3.3V   │      │   │
                              │ALWAYS │      │   │
                              │ON     │      │   │
                              │       │      │   │
                         ┌────┴──┐ ┌──┴──────┴───┴──┐
                         │ XIAO  │ │   MOSFET_1     │ MOSFET_2    │
                         │ESP32  │ │ (Sensor Rail)  │(Comms Rail) │
                         │       │ │                │             │
                         │5μA    │ │  3.3V switched │ 3.3V switched
                         │sleep  │ │       │        │      │
                         └───────┘ │  ┌────┴────┐   │ ┌────┴─────┐
                                   │  │MPU6050  │   │ │STM32     │
                                   │  │BMP180   │   │ │NEO GPS   │
                                   │  │         │   │ │          │
                                   │  │OFF when │   │ │OFF when  │
                                   │  │not      │   │ │not       │
                                   │  │reading  │   │ │sending   │
                                   │  └─────────┘   │ └──────────┘
                                   └────────────────┘
```

## 3.2 Power Consumption Per State

```
┌─────────────────────────────────┬────────────┬───────────┬──────────────┐
│ State                           │ Components │ Power     │ Duration     │
│                                 │ Active     │ (mW)      │              │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ DEEP SLEEP                      │ XIAO(sleep)│ 1.87      │ 2 min -      │
│ (between all operations)        │ Power board│           │ 120 min      │
│                                 │            │           │              │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ SENSOR READING                  │ XIAO       │ 313.5     │ 5 seconds    │
│ (wake, read, process, sleep)    │ MPU6050    │           │              │
│                                 │ BMP180     │           │              │
│                                 │ DS3231*    │           │              │
│                                 │            │           │ *coin cell   │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ TRANSMIT PHASE A                │ XIAO       │ 500       │ 5 seconds    │
│ (XIAO dumps data to STM32)      │ STM32      │           │              │
│                                 │            │           │              │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ TRANSMIT PHASE B                │ STM32      │ 2200      │ 60-90        │
│ (STM32 handles SIM800L)         │ SIM800L    │           │ seconds      │
│ (XIAO returns to deep sleep)    │            │           │              │
│                                 │            │           │              │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ TRANSMIT PHASE C                │ XIAO       │ 500       │ 3 seconds    │
│ (STM32 wakes XIAO with results) │ STM32      │           │              │
│                                 │            │           │              │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ GPS FIX                         │ STM32      │ 2550      │ 30-90        │
│ (only on detachment)            │ SIM800L    │           │ seconds      │
│                                 │ GPS        │           │              │
├─────────────────────────────────┼────────────┼───────────┼──────────────┤
│ SIM800L 2A PEAK                 │ SIM800L    │ 8000      │ 0.5-2        │
│ (during RF transmit burst)      │            │ (peak)    │ seconds      │
│ (absorbed by capacitors)        │            │           │              │
└─────────────────────────────────┴────────────┴───────────┴──────────────┘
```

## 3.3 Energy Per Operation

```
┌───────────────────────────────────┬──────────────┬───────────────────────┐
│ Operation                         │ Energy (mWh) │ Calculation           │
├───────────────────────────────────┼──────────────┼───────────────────────┤
│ One sensor reading cycle          │ 0.435        │ 313.5mW × 5s / 3600  │
├───────────────────────────────────┼──────────────┼───────────────────────┤
│ One transmission cycle (no GPS)   │ 56.3         │ Phase A + B + C       │
│   Phase A: XIAO→STM32 dump       │   0.694      │ 500mW × 5s / 3600    │
│   Phase B: STM32→SIM800L         │   55.0       │ 2200mW × 90s / 3600  │
│   Phase C: STM32→XIAO response   │   0.417      │ 500mW × 3s / 3600    │
│   Phase D: XIAO processes + off  │   0.167      │ 300mW × 2s / 3600    │
├───────────────────────────────────┼──────────────┼───────────────────────┤
│ One transmission cycle (with GPS) │ 72.7         │ Phase B extended by   │
│                                   │              │ 90s GPS at +350mW    │
├───────────────────────────────────┼──────────────┼───────────────────────┤
│ One hour of deep sleep            │ 1.87         │ 1.87mW × 1h          │
├───────────────────────────────────┼──────────────┼───────────────────────┤
│ One full day of deep sleep only   │ 44.9         │ 1.87mW × 24h         │
└───────────────────────────────────┴──────────────┴───────────────────────┘
```

## 3.4 Battery Voltage to Percentage Mapping

```
18650 Li-Ion Discharge Curve (1S8P, under light load):

    Voltage    State of Charge    System Action
    ───────    ───────────────    ─────────────────────────
    4.20V      100%               Fully charged
    4.10V      ~90%               
    4.00V      ~80%               
    3.90V      ~70%               
    3.80V      ~55%               
    3.70V      ~40%               Battery > 30% checks pass
    3.65V      ~30%               Enter CONSERVE mode
    3.60V      ~20%               Enter DEEP CONSERVE mode
    3.50V      ~10%               Enter HIBERNATION mode
    3.40V      ~5%                SIM800L minimum voltage
    3.30V      ~2%                XIAO may brownout
    3.00V      0%                 Cell damage if discharged further

    PRACTICAL CUTOFFS:
    Full operation:     > 3.60V  (> 20%)
    Conservation mode:  3.50-3.60V (10-20%)
    Hibernation:        3.40-3.50V (5-10%)
    Emergency shutdown: < 3.40V (SIM800L dies, save state, halt)
```

---

# SECTION 4: FLASH MEMORY LAYOUT AND DATA STORAGE

## 4.1 XIAO ESP32-C3 Flash Partition Table

```
TOTAL FLASH: 4 MB (4,194,304 bytes)

┌────────────────┬──────────┬──────────────────────────────────┐
│ Partition      │ Size     │ Purpose                          │
├────────────────┼──────────┼──────────────────────────────────┤
│ bootloader     │ 0.03 MB  │ ESP32-C3 bootloader              │
│ partition table│ 0.003 MB │ Partition definitions             │
│ nvs            │ 0.02 MB  │ Configuration key-value store     │
│ app            │ 1.5 MB   │ Firmware binary                   │
│ littlefs       │ 2.0 MB   │ Data log filesystem               │
│ coredump       │ 0.065 MB │ Crash dump (debug)                │
│ reserved       │ ~0.38 MB │ Alignment and spare               │
└────────────────┴──────────┴──────────────────────────────────┘
```

## 4.2 NVS (Non-Volatile Storage) Keys

```
CONFIGURATION STORED IN NVS:
┌──────────────────────┬────────┬──────────────────────────────────┐
│ Key                  │ Type   │ Description                      │
├──────────────────────┼────────┼──────────────────────────────────┤
│ olp_length           │ float  │ OLP rope length in cm            │
│ alert_level          │ float  │ Alert zone threshold (cm)        │
│ warning_level        │ float  │ Warning zone threshold (cm)      │
│ danger_level         │ float  │ Danger zone threshold (cm)       │
│ device_id            │ string │ Unique device identifier         │
│ phone_1              │ string │ Tier 1 alert phone number        │
│ phone_2              │ string │ Tier 2 alert phone number        │
│ phone_3              │ string │ Tier 3 alert phone number        │
│ apn                  │ string │ GPRS APN for SIM card            │
│ server_url           │ string │ GPRS HTTP POST endpoint          │
│ ref_tilt_x           │ float  │ Calibration reference tilt X     │
│ ref_tilt_y           │ float  │ Calibration reference tilt Y     │
│ gyro_offset_x        │ float  │ Gyroscope X offset               │
│ gyro_offset_y        │ float  │ Gyroscope Y offset               │
│ last_tx_timestamp    │ uint32 │ Last successful transmission     │
│ write_pointer        │ uint32 │ Current position in data log     │
│ detach_flag          │ uint8  │ 1 if tether detachment detected  │
│ current_mode         │ uint8  │ Current operating mode           │
│ pressure_baseline    │ float  │ Rolling atmospheric pressure avg │
│ boot_count           │ uint32 │ Number of boots (debug)          │
└──────────────────────┴────────┴──────────────────────────────────┘
```

## 4.3 Data Log Record Format

```
EACH READING = 32 BYTES:

Byte Offset   Size    Type     Field
───────────   ────    ────     ─────────────────────────────
0-3           4       uint32   Timestamp (Unix epoch seconds)
4-5           2       uint16   Water level × 100 (cm, 0.01 resolution)
6-7           2       int16    Rate of change × 100 (cm/15min, signed)
8             1       uint8    Zone (0=NORMAL,1=ALERT,2=WARNING,3=DANGER)
9             1       uint8    Response level (0-4)
10-11         2       uint16   Battery voltage × 1000 (volts)
12-13         2       int16    Corrected tilt X × 100 (degrees)
14-15         2       int16    Corrected tilt Y × 100 (degrees)
16-17         2       uint16   Theta × 100 (degrees, total tilt)
18-21         4       float    BMP pressure (hPa)
22            1       uint8    BMP temperature × 2 (°C, 0.5 resolution)
23            1       uint8    Flags bitfield:
                                 bit 0: sustained rise (1=yes)
                                 bit 1: underwater detected (1=yes)
                                 bit 2: detachment detected (1=yes)
                                 bit 3: tamper detected (1=yes)
                                 bit 4: sensor fault (1=yes)
                                 bit 5: GPS fix included (1=yes)
                                 bit 6: transmission attempted (1=yes)
                                 bit 7: transmission successful (1=yes)
24-27         4       float    GPS latitude (0.0 if no fix)
28-31         4       float    GPS longitude (0.0 if no fix)
───────────────────────────────────────────────────────────────
TOTAL: 32 bytes per record

STORAGE CAPACITY:
    2 MB LittleFS ÷ 32 bytes = 65,536 records maximum
    At 48 readings/day (NORMAL mode) = 1,365 days = 3.7 years
    At 288 readings/day (FLOOD mode) = 227 days
    At 720 readings/day (CRITICAL mode) = 91 days

DATA IS CIRCULAR:
    When write_pointer reaches 65,536, it wraps to 0
    Oldest untransmitted data is overwritten
    In practice this never happens because data is 
    marked as transmitted and the pointer advances
```

---

# SECTION 5: COMMUNICATION PROTOCOL

## 5.1 XIAO ↔ STM32 UART Protocol

```
PHYSICAL: UART at 115200 baud, 8N1
XIAO UART1 TX (D8/GPIO8) → STM32 UART1 RX (PA10)
XIAO UART1 RX (D9/GPIO9) ← STM32 UART1 TX (PA9)
STM32 PB0 (GPIO) → XIAO D3 (GPIO5) interrupt wire

ALL MESSAGES: ASCII text, newline terminated (\n)
DIRECTION INDICATOR: → means XIAO to STM32, ← means STM32 to XIAO
```

### 5.1.1 Boot Handshake

```
POWER ON SEQUENCE:
    1. XIAO sets MOSFET_2 gate LOW (powers on comms rail)
    2. STM32 boots (~100ms)
    3. STM32 initializes UARTs
    
    ← "READY\n"                          STM32 reports ready
    → "ACK\n"                            XIAO acknowledges
```

### 5.1.2 Data Transmission Command

```
→ "TX:DATA:<count>\n"                   XIAO tells STM32 how many records

    For each record:
→ "R:<timestamp>,<level>,<rate>,<zone>,<response>,<battery>,<pressure>,<temp>,<flags>\n"

→ "TX:END\n"                            XIAO signals end of data

    STM32 processes and transmits via SIM800L...

← "TX:OK:<ack_id>\n"                    Success, server acknowledged
    OR
← "TX:FAIL:<error_code>\n"              Failed, XIAO keeps data in queue
    Error codes:
        1 = SIM800L not responding
        2 = No network registration
        3 = GPRS attach failed
        4 = HTTP POST failed
        5 = Server returned error
        6 = Timeout
```

### 5.1.3 SMS Alert Command

```
→ "SMS:ALERT:<phone>,<message>\n"       Send SMS alert

← "SMS:OK\n"                            SMS sent successfully
    OR
← "SMS:FAIL\n"                          SMS failed
```

### 5.1.4 GPS Fix Command

```
→ "GPS:FIX\n"                           Request GPS coordinates

← "GPS:OK:<lat>,<lon>,<hdop>\n"         Fix obtained
    OR
← "GPS:NOFIX\n"                         No fix after timeout
```

### 5.1.5 SMS Command Relay

```
← "CMD:SET_THRESHOLD:<alert>,<warning>,<danger>\n"
← "CMD:SET_OLP:<value>\n"
← "CMD:CAL\n"
← "CMD:STATUS\n"
← "CMD:RESET\n"
← "CMD:MODE:<mode>\n"

→ "CMD:ACK\n"                           XIAO acknowledges command
```

### 5.1.6 Shutdown Command

```
→ "SHUTDOWN\n"                          XIAO tells STM32 to prepare for power off

← "SHUTDOWN:OK\n"                       STM32 confirms ready for power off

    XIAO sets MOSFET_2 gate HIGH (powers off comms rail)
    STM32 loses power immediately
```

### 5.1.7 Interrupt Wire Protocol

```
STM32 PB0 → XIAO D3 (GPIO5)

ACTIVE LOW PULSE:
    STM32 pulls PB0 LOW for 100ms then releases
    XIAO configured with ext0 wakeup on GPIO5 falling edge
    XIAO wakes from deep sleep
    XIAO reads UART for pending messages from STM32

USE CASES:
    1. STM32 finished transmitting, has results to deliver
    2. STM32 received an incoming SMS command
    3. STM32 detected a SIM800L error that needs XIAO attention
```

## 5.2 STM32 ↔ SIM800L AT Command Sequences

### 5.2.1 SIM800L Initialization

```
STM32 sends (UART2, 9600 baud initially):

    "AT\r\n"                    → expect "OK"
    Wait 1 second
    "AT\r\n"                    → expect "OK" (confirm baud)
    "ATE0\r\n"                  → expect "OK" (disable echo)
    "AT+CMGF=1\r\n"             → expect "OK" (SMS text mode)
    "AT+CPIN?\r\n"              → expect "+CPIN: READY"
    
    IF "+CPIN: SIM PIN":
        "AT+CPIN=\"1234\"\r\n"  → enter PIN if needed
    
    Wait for network registration:
    LOOP (max 30 seconds):
        "AT+CREG?\r\n"          → look for "+CREG: 0,1" or "+CREG: 0,5"
        IF registered: break
        Wait 2 seconds
    
    IF not registered after 30s:
        Return error to XIAO: "TX:FAIL:2\n"
        Abort
    
    "AT+CSQ\r\n"                → get signal strength
    Parse "+CSQ: <rssi>,<ber>"
    IF rssi < 5: weak signal warning
```

### 5.2.2 GPRS Data Transmission

```
    "AT+SAPBR=3,1,\"CONTYPE\",\"GPRS\"\r\n"    → OK
    "AT+SAPBR=3,1,\"APN\",\"<apn>\"\r\n"        → OK
    "AT+SAPBR=1,1\r\n"                          → OK (open bearer)
    Wait 3 seconds
    
    "AT+HTTPINIT\r\n"                            → OK
    "AT+HTTPPARA=\"CID\",1\r\n"                  → OK
    "AT+HTTPPARA=\"URL\",\"<server_url>\"\r\n"   → OK
    "AT+HTTPPARA=\"CONTENT\",\"application/json\"\r\n" → OK
    
    Calculate JSON payload length
    "AT+HTTPDATA=<length>,10000\r\n"             → DOWNLOAD
    Send JSON payload bytes
    Wait for "OK"
    
    "AT+HTTPACTION=1\r\n"                        → OK
    Wait for "+HTTPACTION: 1,<status>,<length>"
    
    IF status == 200:
        "AT+HTTPREAD\r\n"                        → read response
        Parse server response
        Transmission successful
    ELSE:
        Transmission failed
    
    "AT+HTTPTERM\r\n"                            → OK
    "AT+SAPBR=0,1\r\n"                           → OK (close bearer)
```

### 5.2.3 SMS Sending

```
    "AT+CMGF=1\r\n"                             → OK (text mode)
    "AT+CMGS=\"<phone_number>\"\r\n"             → > (prompt)
    Send message body (max 160 chars)
    Send 0x1A (Ctrl+Z)                           → +CMGS: <id>
    Wait for "OK"
```

### 5.2.4 SMS Receiving (Check for Commands)

```
    "AT+CMGL=\"REC UNREAD\"\r\n"
    
    IF response contains "+CMGL:":
        Parse each SMS:
            Extract sender number
            Extract message body
            
            IF sender in authorized list:
                Parse command
                Relay to XIAO: "CMD:<command>\n"
            
            Delete processed SMS:
            "AT+CMGD=<index>\r\n"                → OK
```

## 5.3 JSON Payload Format (GPRS to Server)

```
{
    "device_id": "VARUNA-001",
    "firmware_version": "1.0.0",
    "batch_timestamp": 1700000000,
    "battery": {
        "voltage": 3.72,
        "percentage": 42,
        "mode": "NORMAL"
    },
    "location": {
        "latitude": 0.0,
        "longitude": 0.0,
        "fix": false
    },
    "config": {
        "olp_length": 100.0,
        "alert_level": 120.0,
        "warning_level": 180.0,
        "danger_level": 250.0
    },
    "system": {
        "mode": "NORMAL",
        "response_level": "NORMAL",
        "uptime_hours": 720,
        "boot_count": 3,
        "sensor_status": "ALL_OK",
        "gsm_signal": 15,
        "sample_interval_min": 30,
        "transmit_interval_min": 480
    },
    "readings": [
        {
            "timestamp": 1699999200,
            "water_level_cm": 87.32,
            "rate_cm_per_15min": 0.45,
            "theta_deg": 29.15,
            "tilt_x_deg": 22.40,
            "tilt_y_deg": 18.70,
            "zone": "NORMAL",
            "response": "NORMAL",
            "sustained_rise": false,
            "pressure_hpa": 1013.25,
            "temperature_c": 32.5,
            "underwater": false,
            "flags": 0
        },
        {
            "timestamp": 1700001000,
            "water_level_cm": 87.55,
            ...
        }
    ]
}
```

## 5.4 SMS Alert Formats

```
FLOOD WARNING SMS:
    "[VARUNA-WARN] Site:<id> Level:<X>cm(<zone>) Rise:<Y>cm/15m Time:<HH:MM DD-MMM> Batt:<Z>%"

FLOOD CRITICAL SMS:
    "[VARUNA-CRIT] Site:<id> Level:<X>cm DANGER! Rise:<Y>cm/15m Time:<HH:MM DD-MMM> Batt:<Z>% IMMEDIATE ACTION REQUIRED"

UNDERWATER SMS:
    "[VARUNA-SUBMERGE] Site:<id> BUOY UNDERWATER Pressure:<X>hPa Depth:~<Y>cm Time:<HH:MM DD-MMM>"

DETACHMENT SMS:
    "[VARUNA-TAMPER] Site:<id> TETHER DETACHED GPS:<lat>,<lon> Last level:<X>cm Time:<HH:MM DD-MMM>"

LOW BATTERY SMS:
    "[VARUNA-BATT] Site:<id> Battery:<X>% (<Y>V) Mode:<mode> Est remaining:<Z> days"

ALL CLEAR SMS:
    "[VARUNA-CLEAR] Site:<id> Level:<X>cm STABLE Peak was:<Y>cm at <HH:MM> Now NORMAL"

SENSOR FAULT SMS:
    "[VARUNA-FAULT] Site:<id> Sensor:<name> Status:FAIL Readings continue with remaining sensors"

BOOT SMS:
    "[VARUNA-BOOT] Site:<id> Online Batt:<X>% FW:<ver> Mode:<mode>"
```

## 5.5 Incoming SMS Commands

```
┌───────────────────────────────────┬─────────────────────────────────────┐
│ Command SMS Text                  │ Action                              │
├───────────────────────────────────┼─────────────────────────────────────┤
│ STATUS                            │ Reply with device status SMS        │
├───────────────────────────────────┼─────────────────────────────────────┤
│ SET THRESHOLD <a>,<w>,<d>         │ Update alert/warning/danger levels  │
│ Example: SET THRESHOLD 120,180,250│ Values in cm                        │
├───────────────────────────────────┼─────────────────────────────────────┤
│ SET OLP <value>                   │ Update OLP rope length              │
│ Example: SET OLP 150.0            │ Value in cm                         │
├───────────────────────────────────┼─────────────────────────────────────┤
│ CALIBRATE                         │ Recalibrate MPU6050 zero reference  │
│                                   │ Device must be level and still      │
├───────────────────────────────────┼─────────────────────────────────────┤
│ RESET                             │ Reboot device                       │
├───────────────────────────────────┼─────────────────────────────────────┤
│ MODE <mode>                       │ Force operating mode                │
│ Example: MODE NORMAL              │ NORMAL, WATCH, WARNING, FLOOD       │
├───────────────────────────────────┼─────────────────────────────────────┤
│ LOGS <n>                          │ Reply with last n readings          │
│ Example: LOGS 5                   │ Sent as multiple SMS if needed      │
├───────────────────────────────────┼─────────────────────────────────────┤
│ GPS                               │ Get GPS fix and reply with location │
├───────────────────────────────────┼─────────────────────────────────────┤
│ HELP                              │ Reply with list of commands         │
└───────────────────────────────────┴─────────────────────────────────────┘

AUTHORIZATION:
    Only SMS from phone numbers stored in NVS (phone_1, phone_2, phone_3)
    are processed. All other SMS are deleted without action.
```

---

# SECTION 6: XIAO ESP32-C3 FIRMWARE — COMPLETE LOGIC

## 6.1 Initialization (First Boot)

```
POWER ON:

    1.  Initialize serial debug (UART0, 115200 baud) [D6/D7]
    2.  Initialize UART1 (115200 baud) [D8 TX, D9 RX] — for STM32
    3.  Initialize I2C bus [D4 SDA, D5 SCL] — 100kHz
    4.  Initialize GPIO:
            D0 (GPIO2) = OUTPUT, HIGH (MOSFET_1 OFF — sensor rail off)
            D1 (GPIO3) = OUTPUT, HIGH (MOSFET_2 OFF — comms rail off)
            D2 (GPIO4) = ANALOG INPUT (battery voltage ADC)
            D3 (GPIO5) = INPUT with PULLUP (STM32 interrupt, active LOW)
    
    5.  Check NVS for existing configuration:
            IF "boot_count" key exists:
                Load all configuration from NVS
                Increment boot_count
                This is a RESTART, not first boot
            ELSE:
                First boot — set defaults:
                    olp_length = 100.0
                    alert_level = 120.0
                    warning_level = 180.0
                    danger_level = 250.0
                    device_id = "VARUNA-001"
                    phone_1 = "" (must be configured via SMS)
                    apn = "internet" (default)
                    server_url = "" (must be configured)
                    boot_count = 1
                Save to NVS
    
    6.  Read DS3231 RTC via I2C (address 0x68):
            DS3231 is always powered by coin cell
            No MOSFET switch needed to read it
            Get current Unix timestamp
            IF RTC reads year < 2024: RTC not set, use boot_count as relative time
    
    7.  Read battery voltage:
            ADC reading on D2
            battery_voltage = adc_value × 2 × (3.3 / 4095)
            battery_percentage = voltage_to_percentage(battery_voltage)
            
            IF battery_voltage < 3.40V:
                Battery critically low
                Cannot operate SIM800L
                Enter EMERGENCY HIBERNATE immediately
                Set deep sleep timer to 4 hours
                Go to sleep
    
    8.  POWER ON SENSOR RAIL (D0 → LOW):
            Wait 50ms for MPU6050 and BMP180 to stabilize
    
    9.  Verify MPU6050 on I2C bus:
            Read WHO_AM_I register (0x75) at address 0x69
            Expected: 0x68
            IF not found:
                Log error: "MPU6050 NOT FOUND AT 0x69"
                Try address 0x68 (maybe AD0 is not pulled high)
                IF still not found:
                    CRITICAL FAILURE — primary sensor missing
                    Power on comms rail
                    Send "SENSOR FAULT" SMS
                    Enter MAINTENANCE mode
                    Halt
    
    10. Verify BMP180 on I2C bus:
            Read chip ID register at address 0x77
            BMP180 ID = 0x55, BMP280 ID = 0x58
            IF not found:
                Log warning: "BMP180 NOT FOUND"
                Set bmp_available = FALSE
                Continue without pressure data
                Underwater detection disabled
    
    11. Configure MPU6050:
            Write register 0x6B = 0x00 (wake up from sleep)
            Wait 100ms
            Write register 0x19 = 0x07 (sample rate divider, 125Hz)
            Write register 0x1A = 0x03 (DLPF ~44Hz bandwidth)
            Write register 0x1B = 0x00 (gyroscope ±250°/s)
            Write register 0x1C = 0x00 (accelerometer ±2g)
    
    12. PERFORM FULL CALIBRATION:
            (See Section 6.3 for complete calibration procedure)
            Store calibration values in NVS
    
    13. Read initial BMP180 pressure:
            Store as initial pressure_baseline
            Save to NVS
    
    14. Initialize data storage:
            Mount LittleFS partition
            IF mount fails: format and remount
            Open or create data log file
            Read write_pointer from NVS (or start at 0)
    
    15. Initialize circular buffers:
            sustained_rise_buffer[4] = {0, 0, 0, 0}
            sustained_buffer_index = 0
            pressure_history[48] = all zeros (24-hour rolling window)
            pressure_history_index = 0
    
    16. POWER OFF SENSOR RAIL (D0 → HIGH)
    
    17. Determine initial operating mode:
            IF battery_percentage > 50: mode = NORMAL
            IF battery_percentage 30-50: mode = NORMAL (but will conserve transmit)
            IF battery_percentage 15-30: mode = CONSERVE
            IF battery_percentage < 15: mode = HIBERNATE
    
    18. POWER ON COMMS RAIL (D1 → LOW):
            Wait for STM32 boot
            Wait for "READY\n" on UART1
            Send boot notification SMS:
                "[VARUNA-BOOT] Site:<id> Online Batt:<X>% FW:1.0 Mode:<mode>"
            Send initial data point via GPRS
            Check for any pending SMS commands
            Process commands if any
            Send "SHUTDOWN\n" to STM32
            Wait for "SHUTDOWN:OK\n"
    
    19. POWER OFF COMMS RAIL (D1 → HIGH)
    
    20. Set initial sample and transmit intervals based on mode
    
    21. Configure deep sleep:
            esp_sleep_enable_timer_wakeup(sample_interval_microseconds)
            esp_sleep_enable_ext0_wakeup(GPIO5, LOW)  — STM32 interrupt
    
    22. Enter deep sleep
```

## 6.2 Main Wake Cycle

```
═══════════════════════════════════════════════════════════
MAIN WAKE CYCLE
Called every time XIAO wakes from deep sleep
═══════════════════════════════════════════════════════════

STEP 0: DETERMINE WAKE REASON
    wake_reason = esp_sleep_get_wakeup_cause()
    
    IF wake_reason == TIMER:
        Normal scheduled wake — proceed with sensor reading
    
    IF wake_reason == EXT0 (GPIO5 interrupt from STM32):
        STM32 has something to tell us
        But STM32 should only interrupt during transmission
        This means we were sleeping during Phase B
        Jump to PHASE C (receive STM32 response)
    
    IF wake_reason == UNDEFINED:
        Power-on reset or brownout recovery
        Jump to INITIALIZATION (Section 6.1)


STEP 1: READ RTC TIMESTAMP
    current_timestamp = read_ds3231_unix_time()
    (DS3231 is on coin cell, readable without MOSFET)


STEP 2: READ BATTERY VOLTAGE
    adc_raw = analogRead(D2)
    battery_voltage = adc_raw × 2 × (3.3 / 4095.0)
    battery_percentage = voltage_to_percentage(battery_voltage)
    
    IF battery_voltage < 3.40V:
        EMERGENCY: Battery cannot power SIM800L
        
        IF current response_level >= WARNING:
            Attempt ONE last SMS (SIM800L may fail at this voltage):
                Power on comms
                Send: "[VARUNA-BATT] CRITICAL <voltage>V SHUTTING DOWN"
                Power off comms
        
        Save all state to NVS
        Enter deep sleep for 4 hours
        On next wake: check battery again, repeat until charged or dead


STEP 3: POWER ON SENSOR RAIL
    digitalWrite(D0, LOW)     — MOSFET_1 on
    delay(50)                 — wait for sensor power stabilization


STEP 4: INITIALIZE MPU6050 (quick init, not full calibration)
    Write register 0x6B = 0x00 (wake from sleep)
    delay(20)
    Write config registers (0x19, 0x1A, 0x1B, 0x1C)
    delay(10)


STEP 5: READ MPU6050 — MULTI-SAMPLE WITH OUTLIER REJECTION
    
    sample_buffer_ax[10]
    sample_buffer_ay[10]
    sample_buffer_az[10]
    
    FOR i = 0 TO 9:
        Read 14 bytes from register 0x3B at address 0x69
        Parse accX, accY, accZ (int16, big-endian)
        
        sample_buffer_ax[i] = accX / 16384.0
        sample_buffer_ay[i] = accY / 16384.0
        sample_buffer_az[i] = accZ / 16384.0
        
        delay(20)      — 20ms between samples = 50Hz effective rate
    
    Sort each buffer
    Discard 2 lowest and 2 highest from each (indices 0,1 and 8,9)
    Average indices 2 through 7 (6 samples):
    
    ax = average(sample_buffer_ax[2..7])
    ay = average(sample_buffer_ay[2..7])
    az = average(sample_buffer_az[2..7])
    
    Validate total acceleration magnitude:
    total_g = sqrt(ax² + ay² + az²)
    IF total_g < 0.7 OR total_g > 1.3:
        Sensor may be malfunctioning or device is being moved
        Set sensor_fault_flag = TRUE
        Use previous reading as fallback


STEP 6: CALCULATE TILT ANGLES (TANGENTIAL MOUNTING)
    
    Accelerometer angles (Z is UP from buoy surface):
        accTiltX = atan2(ay, az) × 180.0 / π
        accTiltY = atan2(ax, az) × 180.0 / π
    
    Subtract calibration reference:
        correctedTiltX = accTiltX - refTiltX
        correctedTiltY = accTiltY - refTiltY
    
    Total tilt angle from vertical:
        theta = sqrt(correctedTiltX² + correctedTiltY²)
        IF theta > 90.0: theta = 90.0
        IF theta < 0.0:  theta = 0.0
    
    NOTE: No complementary filter used.
          With 30-minute gaps between readings, gyroscope integration
          is meaningless. Pure accelerometer with multi-sample averaging
          provides ±0.5° accuracy, which is sufficient.
          At OLP=100cm, ±0.5° = ±0.04cm error at θ=30°.


STEP 7: CALCULATE WATER LEVEL
    
    thetaRad = theta × π / 180.0
    waterHeight = olpLength × cos(thetaRad)
    horizontalDist = olpLength × sin(thetaRad)


STEP 8: READ BMP180 PRESSURE AND TEMPERATURE
    
    IF bmp_available:
        Read BMP180 uncompensated temperature (register sequence)
        Read BMP180 uncompensated pressure (register sequence)
        Apply BMP180 compensation algorithm (datasheet formulas)
        Result: current_pressure (hPa), current_temperature (°C)
    ELSE:
        current_pressure = 0.0
        current_temperature = 0.0


STEP 9: POWER OFF SENSOR RAIL
    digitalWrite(D0, HIGH)    — MOSFET_1 off
    MPU6050 and BMP180 lose power immediately
    No shutdown sequence needed — they have no state to save


STEP 10: UNDERWATER DETECTION (BMP180 pressure analysis)
    
    IF bmp_available:
        Load pressure_baseline from NVS (rolling 48-reading average)
        deviation = current_pressure - pressure_baseline
        
        IF deviation > 15.0 hPa:
            CONFIRMED UNDERWATER
            estimated_depth_cm = deviation / 0.981
            underwater_flag = TRUE
            force_transmit = TRUE
        
        ELSE IF deviation > 8.0 hPa:
            SUSPECT UNDERWATER
            submersion_suspect = TRUE
            Reduce sample interval for next cycle to verify
        
        ELSE IF deviation < 5.0 hPa:
            NORMAL atmospheric variation
            Update pressure_baseline rolling average:
                pressure_history[pressure_history_index] = current_pressure
                pressure_history_index = (pressure_history_index + 1) % 48
                pressure_baseline = average(pressure_history, non-zero entries)
                Save pressure_baseline to NVS
        
        SPECIAL CASE: IF current_pressure < 300 OR current_pressure > 1200:
            BMP sensor failure (reading out of range)
            bmp_available = FALSE
            sensor_fault_flag = TRUE


STEP 11: LOAD PREVIOUS READING FROM FLASH
    
    previous_record = read_record_from_flash(write_pointer - 1)
    previous_waterHeight = decode_level(previous_record)
    previous_timestamp = decode_timestamp(previous_record)


STEP 12: CALCULATE RATE OF CHANGE
    
    time_elapsed_seconds = current_timestamp - previous_timestamp
    
    IF time_elapsed_seconds <= 0 OR time_elapsed_seconds > 86400:
        Invalid time gap (RTC error or first reading)
        rate_per_15min = 0.0
        rate_category = SLOW
    ELSE:
        level_change = waterHeight - previous_waterHeight
        rate_per_15min = level_change × (900.0 / time_elapsed_seconds)
        
        Normalize to per-15-minute regardless of actual sample interval
        
        IF rate_per_15min < 2.0:   rate_category = SLOW
        ELSE IF rate_per_15min < 5.0: rate_category = MODERATE
        ELSE:                      rate_category = FAST
        
        IF rate_per_15min < 0:     rate_direction = FALLING
        ELSE:                      rate_direction = RISING


STEP 13: UPDATE SUSTAINED-RISE BUFFER
    
    sustained_rise_buffer[sustained_buffer_index] = waterHeight
    sustained_buffer_index = (sustained_buffer_index + 1) % 4
    
    Count consecutive rises:
    rise_count = 0
    FOR i = 1 TO 3:
        idx_current = (sustained_buffer_index - 4 + i + 4) % 4
        idx_previous = (sustained_buffer_index - 4 + i - 1 + 4) % 4
        IF sustained_rise_buffer[idx_current] > sustained_rise_buffer[idx_previous]:
            rise_count = rise_count + 1
    
    IF rise_count >= 3:
        sustained = TRUE
    ELSE:
        sustained = FALSE
    
    COLD START OVERRIDE:
        IF boot_count <= 4 (fewer than 4 readings since boot):
            sustained = FALSE
            UNLESS zone >= WARNING:
                sustained = TRUE (safety override)


STEP 14: DETERMINE ZONE
    
    IF waterHeight > danger_level:    zone = DANGER
    ELSE IF waterHeight > warning_level: zone = WARNING
    ELSE IF waterHeight > alert_level:   zone = ALERT
    ELSE:                                zone = NORMAL


STEP 15: APPLY DECISION MATRIX
    
    Lookup response_level from the 24-combination matrix:
    
    ┌──────────┬──────────┬───────────┬───────────────┐
    │ Zone     │ Rate     │ Sustained │ Response      │
    ├──────────┼──────────┼───────────┼───────────────┤
    │ NORMAL   │ SLOW     │ NO        │ NORMAL        │
    │ NORMAL   │ SLOW     │ YES       │ NORMAL        │
    │ NORMAL   │ MODERATE │ NO        │ NORMAL        │
    │ NORMAL   │ MODERATE │ YES       │ WATCH         │
    │ NORMAL   │ FAST     │ NO        │ NORMAL        │
    │ NORMAL   │ FAST     │ YES       │ WATCH         │
    │ ALERT    │ SLOW     │ NO        │ WATCH         │
    │ ALERT    │ SLOW     │ YES       │ WATCH         │
    │ ALERT    │ MODERATE │ NO        │ WATCH         │
    │ ALERT    │ MODERATE │ YES       │ WARNING       │
    │ ALERT    │ FAST     │ NO        │ WATCH         │
    │ ALERT    │ FAST     │ YES       │ WARNING       │
    │ WARNING  │ SLOW     │ NO        │ WARNING       │
    │ WARNING  │ SLOW     │ YES       │ FLOOD_ALERT   │
    │ WARNING  │ MODERATE │ NO        │ WARNING       │
    │ WARNING  │ MODERATE │ YES       │ FLOOD_ALERT   │
    │ WARNING  │ FAST     │ NO        │ FLOOD_ALERT   │
    │ WARNING  │ FAST     │ YES       │ CRITICAL      │
    │ DANGER   │ SLOW     │ NO        │ FLOOD_ALERT   │
    │ DANGER   │ SLOW     │ YES       │ CRITICAL      │
    │ DANGER   │ MODERATE │ NO        │ CRITICAL      │
    │ DANGER   │ MODERATE │ YES       │ CRITICAL      │
    │ DANGER   │ FAST     │ NO        │ CRITICAL      │
    │ DANGER   │ FAST     │ YES       │ CRITICAL      │
    └──────────┴──────────┴───────────┴───────────────┘
    
    EXTREME RATE OVERRIDE:
        IF rate_per_15min > 30.0 AND zone >= ALERT:
            response_level = CRITICAL
            (Dam release or landslide — physically unmistakable)


STEP 16: TETHER DETACHMENT DETECTION
    
    Load previous_theta from previous record
    
    Check 1: Sudden large angle change
        IF abs(theta - previous_theta) > 15.0:
            detach_suspect = TRUE
    
    Check 2: Sustained near-zero theta with normal pressure
        IF theta < 3.0 for last 6 consecutive readings:
            IF NOT underwater_flag (BMP pressure normal):
                IF previous normal theta was > 10.0:
                    CONFIRMED DETACHMENT
                    detach_flag = TRUE
                    Save detach_flag to NVS
                    force_transmit = TRUE
                    gps_needed = TRUE
    
    Check 3: Inverted buoy
        IF az < -0.3:
            Buoy is upside down
            tamper_flag = TRUE
            force_transmit = TRUE
            gps_needed = TRUE


STEP 17: DETERMINE ADAPTIVE INTERVALS
    
    Based on response_level, zone, and battery_percentage:
    
    IF detach_flag:
        Load detach_timestamp from NVS
        hours_since_detach = (current_timestamp - detach_timestamp) / 3600
        
        IF hours_since_detach < 24:
            sample_interval = 5 min
            transmit_interval = 30 min
            gps_on_transmit = TRUE
        ELSE:
            sample_interval = 240 min (4 hours)
            transmit_interval = 720 min (12 hours)
            gps_on_transmit = TRUE
    
    ELSE IF battery_percentage < 5:
        EMERGENCY HIBERNATE
        sample_interval = 240 min
        transmit_interval = 0 (no transmission, save power)
        IF zone >= WARNING:
            sample_interval = 30 min
            transmit_interval = 60 min (SMS only)
    
    ELSE IF battery_percentage < 15:
        IF zone >= WARNING:
            sample_interval = 5 min
            transmit_interval = 15 min (SMS only, no GPRS)
        ELSE IF zone == ALERT:
            sample_interval = 15 min
            transmit_interval = 120 min
        ELSE:
            sample_interval = 120 min
            transmit_interval = 2880 min (48 hours)
    
    ELSE IF battery_percentage < 30:
        IF zone >= WARNING:
            sample_interval = 5 min
            transmit_interval = 30 min
        ELSE IF zone == ALERT:
            sample_interval = 15 min
            transmit_interval = 120 min
        ELSE:
            sample_interval = 60 min
            transmit_interval = 1440 min (24 hours)
    
    ELSE IF battery_percentage < 50:
        IF zone == DANGER:
            sample_interval = 2 min
            transmit_interval = 15 min
        ELSE IF zone == WARNING OR (rate_category == FAST AND sustained):
            sample_interval = 5 min
            transmit_interval = 30 min
        ELSE IF zone == ALERT:
            sample_interval = 10 min
            transmit_interval = 60 min
        ELSE IF rate_category == MODERATE OR rate_category == FAST:
            sample_interval = 15 min
            transmit_interval = 240 min (4 hours)
        ELSE:
            sample_interval = 30 min
            transmit_interval = 720 min (12 hours)
    
    ELSE:  (battery > 50%)
        IF zone == DANGER:
            sample_interval = 2 min
            transmit_interval = 15 min
        ELSE IF zone == WARNING OR (rate_category == FAST AND sustained):
            sample_interval = 5 min
            transmit_interval = 15 min
        ELSE IF zone == ALERT:
            sample_interval = 10 min
            transmit_interval = 60 min
        ELSE IF rate_category == MODERATE OR rate_category == FAST:
            sample_interval = 15 min
            transmit_interval = 120 min (2 hours)
        ELSE:
            sample_interval = 30 min
            transmit_interval = 480 min (8 hours)


STEP 18: STORE READING TO FLASH
    
    Build 32-byte record:
        Pack timestamp, water level, rate, zone, response level,
        battery voltage, tilt X, tilt Y, theta, pressure,
        temperature, flags (sustained, underwater, detach, tamper,
        sensor fault, GPS, tx attempted, tx success)
        GPS lat/lon = 0.0 unless GPS fix available
    
    Write record to LittleFS at current write_pointer position
    write_pointer = (write_pointer + 1) % 65536
    Save write_pointer to NVS


STEP 19: CHECK IF TRANSMISSION IS DUE
    
    last_tx = load last_tx_timestamp from NVS
    time_since_tx = current_timestamp - last_tx
    minutes_since_tx = time_since_tx / 60
    
    transmission_needed = FALSE
    
    IF minutes_since_tx >= transmit_interval:
        transmission_needed = TRUE
    
    FORCE TRANSMIT OVERRIDES:
        IF force_transmit:
            transmission_needed = TRUE
        
        IF response_level >= WARNING AND previous_response_level < WARNING:
            transmission_needed = TRUE (escalation just happened)
        
        IF response_level == CRITICAL AND previous_response_level < CRITICAL:
            transmission_needed = TRUE (critical escalation)
        
        IF underwater_flag AND NOT previous_underwater_flag:
            transmission_needed = TRUE (newly submerged)
        
        IF detach_flag AND NOT previous_detach_flag:
            transmission_needed = TRUE (newly detached)
        
        IF tamper_flag:
            transmission_needed = TRUE
    
    Save current response_level as previous for next cycle


STEP 20: EXECUTE TRANSMISSION OR SLEEP
    
    IF transmission_needed:
        Go to TRANSMISSION PROCEDURE (Step 21)
    ELSE:
        Go to SLEEP (Step 22)


STEP 21: TRANSMISSION PROCEDURE
    
    ──── PHASE A: XIAO prepares and dumps data to STM32 ────
    
    Power on comms rail: digitalWrite(D1, LOW)
    Wait 200ms for STM32 + SIM800L power stabilization
    
    Wait for "READY\n" on UART1 (timeout: 5 seconds)
    IF timeout:
        Retry power cycle (D1 HIGH, wait 1s, D1 LOW)
        Wait for "READY\n" (timeout: 5 seconds)
        IF still timeout:
            Log comms failure
            Power off comms rail
            Go to SLEEP with transmission marked as failed
    
    Count pending (untransmitted) records in flash:
        Scan backwards from write_pointer
        Count records where flags.tx_success == 0
        Limit to 48 records maximum per batch (24 hours at 30-min rate)
    
    Send: "TX:DATA:<count>\n"
    
    FOR each pending record (oldest first):
        Read record from flash
        Format as CSV:
        Send: "R:<timestamp>,<level>,<rate>,<zone>,<response>,<battery>,<pressure>,<temp>,<flags>\n"
    
    Send: "TX:END\n"
    
    IF response_level >= WARNING:
        Determine which phones to alert:
            WARNING:     phone_1 only
            FLOOD_ALERT: phone_1 + phone_2
            CRITICAL:    phone_1 + phone_2 + phone_3
        
        Format alert message
        Send: "SMS:ALERT:<phone>,<message>\n" for each phone
    
    IF underwater_flag AND newly detected:
        Send: "SMS:ALERT:<phone_1>,[VARUNA-SUBMERGE]...\n"
    
    IF detach_flag OR tamper_flag:
        Send: "GPS:FIX\n"
        Wait for GPS response before sending SMS
    
    IF response_level transitioned from >= WARNING to NORMAL:
        IF this is sustained for 8 consecutive readings:
            Send: "SMS:ALERT:<all_phones>,[VARUNA-CLEAR]...\n"
    
    ──── XIAO goes to deep sleep, waits for STM32 interrupt ────
    
    Configure deep sleep:
        esp_sleep_enable_ext0_wakeup(GPIO5, LOW)
        Also set timer wakeup as safety (120 seconds)
        If STM32 doesn't interrupt within 120s, wake up anyway
    
    Enter deep sleep
    
    ──── PHASE B: STM32 handles everything (XIAO is sleeping) ────
    
    (This runs on STM32 firmware — see Section 7)
    
    ──── PHASE C: STM32 wakes XIAO with results ────
    
    XIAO wakes from deep sleep (ext0 interrupt on GPIO5)
    
    Read all pending UART1 messages from STM32:
        "TX:OK:<ack_id>\n"     → mark records as transmitted
        "TX:FAIL:<code>\n"     → keep records in queue
        "SMS:OK\n"             → log SMS success
        "SMS:FAIL\n"           → log SMS failure  
        "GPS:OK:<lat>,<lon>,<hdop>\n" → store GPS coordinates
        "GPS:NOFIX\n"          → log GPS failure
        "CMD:<command>\n"      → process SMS command (see Step 21a)
    
    IF TX:OK received:
        Mark all transmitted records: flags.tx_success = 1
        Update last_tx_timestamp in NVS
    
    IF GPS:OK received:
        Store coordinates in NVS
        IF detach_flag:
            Update latest GPS in detachment tracking log
    
    Send: "SHUTDOWN\n"
    Wait for: "SHUTDOWN:OK\n" (timeout: 2 seconds)
    
    Power off comms rail: digitalWrite(D1, HIGH)
    
    Go to SLEEP (Step 22)


STEP 21a: PROCESS SMS COMMANDS
    
    FOR each "CMD:<command>\n" received:
    
        IF command == "SET_THRESHOLD:<a>,<w>,<d>":
            Parse alert, warning, danger values
            Validate: 0 < alert < warning < danger < 10000
            IF valid:
                Save to NVS
                alert_level = a
                warning_level = w  
                danger_level = d
                Send reply SMS: "THRESHOLDS SET: A=<a> W=<w> D=<d>"
            ELSE:
                Send reply SMS: "INVALID THRESHOLD VALUES"
        
        IF command == "SET_OLP:<value>":
            Parse OLP value
            Validate: 0 < value < 10000
            IF valid:
                olpLength = value
                Save to NVS
                Send reply SMS: "OLP SET TO <value> CM"
        
        IF command == "CAL":
            Set calibration_pending flag
            Calibration will execute on next sensor reading cycle
            Send reply SMS: "CALIBRATION SCHEDULED FOR NEXT CYCLE"
        
        IF command == "STATUS":
            Format status message with all current values
            Send reply SMS: 
                "Site:<id> Level:<X>cm Zone:<zone> 
                 Rate:<Y>cm/15m Batt:<Z>% Mode:<mode>
                 Uptime:<H>h Temp:<T>°C Press:<P>hPa"
        
        IF command == "RESET":
            Send reply SMS: "RESETTING IN 10 SECONDS"
            Power off comms rail
            delay(10000)
            esp_restart()
        
        IF command == "LOGS <n>":
            Read last n records from flash
            Format into SMS messages (max 3 SMS)
            Queue for transmission
        
        IF command == "GPS":
            gps_needed = TRUE (will execute on next transmit cycle)
            Send reply SMS: "GPS FIX SCHEDULED"


STEP 22: ENTER DEEP SLEEP
    
    IF calibration_pending:
        Perform calibration before sleeping (see Section 6.3)
        Clear calibration_pending flag
    
    Configure wake sources:
        esp_sleep_enable_timer_wakeup(sample_interval × 60 × 1000000)
        esp_sleep_enable_ext0_wakeup(GPIO5, LOW)
    
    Save current mode and intervals to NVS (for recovery after power loss)
    
    esp_deep_sleep_start()
    
    ─── Device is now consuming 5 μA ───
    ─── Next wake in sample_interval minutes ───
```

## 6.3 Calibration Procedure

```
═══════════════════════════════════════════════════════════
CALIBRATION (full or recalibration)
═══════════════════════════════════════════════════════════

PRECONDITIONS:
    Sensor rail must be ON
    MPU6050 must be initialized
    Buoy must be LEVEL and STILL
    Rope must hang VERTICALLY (buoy directly above anchor)

STEP 1: GYROSCOPE OFFSET CALIBRATION
    
    Even though we don't use the gyro in the main loop,
    calibrate it anyway for potential future use.
    
    sum_gx = 0, sum_gy = 0
    FOR i = 0 TO 999:
        Read gyroX, gyroY from MPU6050
        sum_gx += gyroX
        sum_gy += gyroY
        delay(2)
    
    gyroOffsetX = sum_gx / 1000.0
    gyroOffsetY = sum_gy / 1000.0
    
    Save gyroOffsetX, gyroOffsetY to NVS

STEP 2: ACCELEROMETER ZERO REFERENCE
    
    sum_ax = 0, sum_ay = 0, sum_az = 0
    valid_count = 0
    
    FOR i = 0 TO 499:
        Read accX, accY, accZ from MPU6050
        ax = accX / 16384.0
        ay = accY / 16384.0
        az = accZ / 16384.0
        
        total_g = sqrt(ax² + ay² + az²)
        
        IF total_g > 0.9 AND total_g < 1.1:
            sum_ax += ax
            sum_ay += ay
            sum_az += az
            valid_count += 1
        
        delay(3)
    
    IF valid_count > 100:
        refAccX = sum_ax / valid_count
        refAccY = sum_ay / valid_count
        refAccZ = sum_az / valid_count
    ELSE:
        Insufficient valid samples — sensor was moving
        Use single reading as fallback (less accurate)
        Read one sample
        refAccX = accX / 16384.0
        refAccY = accY / 16384.0
        refAccZ = accZ / 16384.0
    
    Calculate reference tilt angles (tangential mounting):
        refTiltX = atan2(refAccY, refAccZ) × 180.0 / π
        refTiltY = atan2(refAccX, refAccZ) × 180.0 / π
    
    Save refTiltX, refTiltY to NVS
    
    At this point:
        correctedTiltX = measuredTiltX - refTiltX = 0°
        correctedTiltY = measuredTiltY - refTiltY = 0°
        theta = 0° → waterHeight = olpLength × cos(0°) = olpLength
        This calibration position = maximum water height reading
```

## 6.4 Step-Down and ALL CLEAR Logic

```
═══════════════════════════════════════════════════════════
RESPONSE LEVEL STEP-DOWN (De-escalation)
═══════════════════════════════════════════════════════════

The system uses HYSTERESIS to prevent oscillation between 
alert levels. Stepping down requires SUSTAINED improvement.

MAINTAINED IN NVS:
    consecutive_below_danger = 0  (count of readings below danger level)
    consecutive_below_warning = 0
    consecutive_below_alert = 0
    consecutive_normal_stable = 0

AFTER EACH READING (in Step 15):
    
    IF waterHeight < danger_level:
        consecutive_below_danger += 1
    ELSE:
        consecutive_below_danger = 0
    
    IF waterHeight < warning_level:
        consecutive_below_warning += 1
    ELSE:
        consecutive_below_warning = 0
    
    IF waterHeight < alert_level:
        consecutive_below_alert += 1
    ELSE:
        consecutive_below_alert = 0
    
    IF zone == NORMAL AND rate_category == SLOW AND NOT sustained:
        consecutive_normal_stable += 1
    ELSE:
        consecutive_normal_stable = 0

STEP-DOWN RULES:

    CRITICAL → FLOOD_ALERT:
        IF consecutive_below_danger >= 4 AND rate_direction == FALLING:
            response_level = FLOOD_ALERT
    
    FLOOD_ALERT → WARNING:
        IF consecutive_below_warning >= 4:
            response_level = WARNING
    
    WARNING → WATCH:
        IF consecutive_below_alert >= 4:
            response_level = WATCH
    
    WATCH → NORMAL:
        IF consecutive_normal_stable >= 8:
            response_level = NORMAL
    
    (4 readings at 5-min interval = 20 minutes for fast step-down)
    (4 readings at 30-min interval = 2 hours for slow step-down)
    (8 readings at 30-min interval = 4 hours for WATCH→NORMAL)

ALL CLEAR SMS:
    IF response_level transitions from >= WARNING to NORMAL:
        Send to all phones that received alerts:
            "[VARUNA-CLEAR] Site:<id> Level:<X>cm STABLE 
             Peak:<Y>cm at <HH:MM DD-MMM> Now NORMAL"
        
        Save peak level and peak time for reference
```

---

# SECTION 7: STM32 BLUE PILL FIRMWARE — COMPLETE LOGIC

```
═══════════════════════════════════════════════════════════
STM32 FIRMWARE
Communication slave controller
═══════════════════════════════════════════════════════════

HARDWARE UARTs:
    UART1 (PA9 TX, PA10 RX)  → XIAO ESP32-C3 at 115200 baud
    UART2 (PA2 TX, PA3 RX)   → SIM800L at 9600 baud (auto-baud)
    UART3 (PB11 RX only)     → NEO-6M GPS at 9600 baud

GPIO:
    PB0  = OUTPUT → XIAO interrupt wire (active LOW pulse)
    PB1  = OUTPUT → SIM800L RST/power key
    PC13 = OUTPUT → onboard LED

NOTE: STM32 has NO persistent storage across power cycles.
      It is hard-powered-off between transmission cycles.
      All configuration comes from XIAO via UART commands.
      It is a STATELESS communication proxy.


═════════════════════
BOOT SEQUENCE
═════════════════════

    1. Initialize system clock (72 MHz)
    2. Initialize UART1 (115200, XIAO)
    3. Initialize UART2 (9600, SIM800L)
    4. Initialize UART3 (9600, GPS RX only)
    5. Initialize GPIO (PB0 HIGH, PB1 LOW, PC13 OFF)
    6. Send "READY\n" on UART1
    7. Wait for commands from XIAO
    8. LED ON (PC13 LOW on Blue Pill = LED ON)


═════════════════════
MAIN COMMAND LOOP
═════════════════════

    WHILE TRUE:
        IF data available on UART1:
            Read line (until \n)
            Parse command
            Execute command handler
        
        No timeout needed — XIAO will cut power when done


═════════════════════
COMMAND HANDLERS
═════════════════════

──── HANDLER: "TX:DATA:<count>\n" ────

    record_count = parse count from message
    
    Allocate buffer for records (in RAM, max 48 records)
    
    FOR i = 0 TO record_count - 1:
        Read "R:<csv_data>\n" from UART1
        Parse and store in buffer
        IF parse error: skip record
    
    Wait for "TX:END\n"
    
    ── Initialize SIM800L ──
    
    Toggle SIM800L power key (PB1):
        PB1 HIGH for 1 second, then LOW
        Wait 3 seconds for SIM800L boot
    
    Send "AT\r\n" on UART2
    Wait for "OK" (timeout 5 seconds)
    IF no response:
        Retry AT 3 times with 2-second gaps
        IF still no response:
            Send "TX:FAIL:1\n" to XIAO via UART1
            Pulse PB0 LOW for 100ms (interrupt XIAO)
            RETURN
    
    Send "ATE0\r\n" → expect OK
    Send "AT+CMGF=1\r\n" → expect OK
    
    Check SIM status:
    Send "AT+CPIN?\r\n"
    IF "+CPIN: SIM PIN" → send PIN
    IF "+CPIN: READY" → continue
    IF error → "TX:FAIL:1\n", pulse interrupt, RETURN
    
    Wait for network registration:
    FOR attempt = 0 TO 14:   (30 seconds total)
        Send "AT+CREG?\r\n"
        IF "+CREG: 0,1" OR "+CREG: 0,5":
            registered = TRUE
            BREAK
        delay(2000)
    
    IF NOT registered:
        Send "TX:FAIL:2\n" to XIAO
        Pulse PB0 LOW (interrupt XIAO)
        RETURN
    
    Get signal strength:
    Send "AT+CSQ\r\n"
    Parse RSSI value (0-31, 99=error)
    Store for reporting
    
    ── Establish GPRS Connection ──
    
    Send "AT+SAPBR=3,1,\"CONTYPE\",\"GPRS\"\r\n" → OK
    Send "AT+SAPBR=3,1,\"APN\",\"<apn>\"\r\n" → OK
    Send "AT+SAPBR=1,1\r\n" → OK
    Wait 5 seconds
    
    Send "AT+SAPBR=2,1\r\n" → verify IP assigned
    IF no IP:
        Send "TX:FAIL:3\n"
        Pulse interrupt
        RETURN
    
    ── Build JSON Payload ──
    
    Build JSON string in RAM buffer (max ~4KB):
        Include device_id, battery, location, config from XIAO data
        Include all reading records
        (See Section 5.3 for JSON format)
    
    Calculate payload_length = strlen(json_buffer)
    
    ── HTTP POST ──
    
    Send "AT+HTTPINIT\r\n" → OK
    Send "AT+HTTPPARA=\"CID\",1\r\n" → OK
    Send "AT+HTTPPARA=\"URL\",\"<server_url>\"\r\n" → OK
    Send "AT+HTTPPARA=\"CONTENT\",\"application/json\"\r\n" → OK
    
    Send "AT+HTTPDATA=<payload_length>,10000\r\n" → DOWNLOAD
    Send json_buffer bytes on UART2
    Wait for "OK" (timeout 10 seconds)
    
    Send "AT+HTTPACTION=1\r\n" → OK
    Wait for "+HTTPACTION: 1,<status>,<datalen>"
    Timeout: 30 seconds
    
    IF status == 200:
        Send "AT+HTTPREAD\r\n"
        Read server response
        Parse acknowledgment ID if present
        tx_result = "TX:OK:<ack_id>"
    ELSE:
        tx_result = "TX:FAIL:5"
    
    Send "AT+HTTPTERM\r\n" → OK
    Send "AT+SAPBR=0,1\r\n" → OK (close bearer)
    
    ── Check for Incoming SMS ──
    
    Send "AT+CMGL=\"REC UNREAD\"\r\n"
    
    IF response contains "+CMGL:":
        FOR each SMS:
            Parse index, sender number, message body
            
            Check if sender is authorized:
                Compare with known phone numbers
                (Phone numbers received from XIAO in TX:DATA header
                 or hardcoded in STM32 firmware)
            
            IF authorized:
                Parse command from message body
                Store command for relay to XIAO
            
            Delete SMS:
            Send "AT+CMGD=<index>\r\n" → OK
    
    ── Send Results to XIAO ──
    
    Send tx_result + "\n" via UART1 (e.g., "TX:OK:12345\n")
    
    FOR each received SMS command:
        Send "CMD:<command>\n" via UART1
    
    Send signal strength: "SIGNAL:<rssi>\n"
    
    Pulse PB0 LOW for 100ms (interrupt XIAO to wake up)
    
    Wait for XIAO response on UART1:
        "CMD:ACK\n" → commands acknowledged
        "SHUTDOWN\n" → prepare for power off
    
    Send "SHUTDOWN:OK\n"
    LED OFF
    
    ── STM32 will lose power when XIAO cuts MOSFET_2 ──


──── HANDLER: "SMS:ALERT:<phone>,<message>\n" ────

    IF SIM800L not initialized: initialize (same as above)
    
    Send "AT+CMGF=1\r\n" → OK
    Send "AT+CMGS=\"<phone>\"\r\n" → > prompt
    Send <message> on UART2
    Send 0x1A (Ctrl+Z)
    Wait for "+CMGS:" response (timeout 30 seconds)
    
    IF success:
        Send "SMS:OK\n" to XIAO via UART1
    ELSE:
        Send "SMS:FAIL\n" to XIAO via UART1


──── HANDLER: "GPS:FIX\n" ────

    GPS module is on the comms power rail, already powered
    GPS UART3 is already receiving NMEA sentences
    
    Start parsing NMEA from UART3:
    
    timeout_start = millis()
    fix_obtained = FALSE
    
    WHILE millis() - timeout_start < 90000:   (90 second timeout)
        Read line from UART3
        
        IF line starts with "$GPRMC" OR "$GNRMC":
            Parse RMC sentence:
                Field 2: Status (A=active/valid, V=void)
                Field 3,4: Latitude, N/S
                Field 5,6: Longitude, E/W
            
            IF status == 'A':
                Parse latitude and longitude as decimal degrees
                fix_obtained = TRUE
                BREAK
        
        IF line starts with "$GPGGA" OR "$GNGGA":
            Parse GGA sentence:
                Field 2,3: Latitude, N/S
                Field 4,5: Longitude, E/W
                Field 6: Fix quality (0=invalid, 1=GPS, 2=DGPS)
                Field 8: HDOP
            
            IF fix quality >= 1:
                Parse latitude, longitude, HDOP
                fix_obtained = TRUE
                BREAK
    
    IF fix_obtained:
        Send "GPS:OK:<lat>,<lon>,<hdop>\n" to XIAO via UART1
    ELSE:
        Send "GPS:NOFIX\n" to XIAO via UART1


──── HANDLER: "SHUTDOWN\n" ────

    Power down SIM800L gracefully:
    Send "AT+CPOWD=1\r\n" → "NORMAL POWER DOWN"
    Wait 2 seconds
    
    Send "SHUTDOWN:OK\n" to XIAO via UART1
    LED OFF (PC13 HIGH)
    
    Enter infinite loop (wait for power cut):
    WHILE TRUE:
        __WFI()    (wait for interrupt — lowest power active state)
```

---

# SECTION 8: COMPLETE ADAPTIVE SAMPLING TABLE

```
┌───────────────────────────────────┬──────────┬──────────┬──────────┬───────────┬──────────┐
│ Condition                         │ Sample   │ Transmit │ Transmit │ Daily     │ Battery  │
│                                   │ Interval │ Interval │ Method   │ Energy    │ Life     │
│                                   │ (min)    │ (min)    │          │ (mWh/day) │ (days)   │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ NORMAL zone + SLOW rate           │          │          │          │           │          │
│ Battery > 50%                     │ 30       │ 480      │ GPRS     │ 214       │ 294      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ NORMAL zone + SLOW rate           │          │          │          │           │          │
│ Battery 30-50%                    │ 30       │ 720      │ GPRS     │ 157       │ 401      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ NORMAL zone + MODERATE/FAST rate  │          │          │          │           │          │
│ Battery > 50%                     │ 15       │ 120      │ GPRS     │ 706       │ 89       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ NORMAL zone + MODERATE/FAST rate  │          │          │          │           │          │
│ Battery 30-50%                    │ 15       │ 240      │ GPRS     │ 414       │ 152      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ ALERT zone                        │          │          │          │           │          │
│ Battery > 50%                     │ 10       │ 60       │ GPRS     │ 1,409     │ 45       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ ALERT zone                        │          │          │          │           │          │
│ Battery 30-50%                    │ 10       │ 60       │ GPRS     │ 1,409     │ 45       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ WARNING zone or FAST+SUSTAINED    │          │          │          │           │          │
│ Battery > 50%                     │ 5        │ 15       │ GPRS+SMS │ 5,445     │ 11.6     │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ WARNING zone or FAST+SUSTAINED    │          │          │          │           │          │
│ Battery 30-50%                    │ 5        │ 30       │ GPRS+SMS │ 2,753     │ 23       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ DANGER zone                       │          │          │          │           │          │
│ Battery > 50%                     │ 2        │ 15       │ GPRS+SMS │ 5,445     │ 11.6     │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ DANGER zone                       │          │          │          │           │          │
│ Battery 15-50%                    │ 2        │ 15       │ GPRS+SMS │ 5,445     │ 11.6     │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ LOW BATTERY (15-30%)              │          │          │          │           │          │
│ + NORMAL zone                     │ 60       │ 1440     │ GPRS     │ 98        │ 643      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ LOW BATTERY (15-30%)              │          │          │          │           │          │
│ + ALERT zone                      │ 15       │ 120      │ GPRS     │ 706       │ 89       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ LOW BATTERY (15-30%)              │          │          │          │           │          │
│ + WARNING or DANGER zone          │ 5        │ 30       │ GPRS+SMS │ 2,753     │ 23       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ VERY LOW BATTERY (5-15%)          │          │          │          │           │          │
│ + NORMAL zone                     │ 120      │ 2880     │ GPRS     │ 75        │ 840      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ VERY LOW BATTERY (5-15%)          │          │          │          │           │          │
│ + ALERT zone                      │ 15       │ 120      │ SMS only │ 530       │ 119      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ VERY LOW BATTERY (5-15%)          │          │          │          │           │          │
│ + WARNING or DANGER zone          │ 5        │ 15       │ SMS only │ 4,100     │ 15       │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ CRITICAL BATTERY (< 5%)           │          │          │          │           │          │
│ + NORMAL zone                     │ 240      │ NONE     │ Local    │ 49        │ 1,286    │
│                                   │          │          │ only     │           │          │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ CRITICAL BATTERY (< 5%)           │          │          │          │           │          │
│ + WARNING or DANGER zone          │ 5        │ 15       │ SMS only │ 4,100     │ 15       │
│                                   │          │          │          │ Dies      │          │
│                                   │          │          │          │ screaming │          │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ DETACHMENT (first 24 hours)       │ 5        │ 30       │ GPRS+GPS │ 6,500     │ 9.7      │
├───────────────────────────────────┼──────────┼──────────┼──────────┼───────────┼──────────┤
│ DETACHMENT (after 24 hours)       │ 240      │ 720      │ GPRS+GPS │ 290       │ 217      │
└───────────────────────────────────┴──────────┴──────────┴──────────┴───────────┴──────────┘

USABLE BATTERY: 63,000 mWh (3.4V SIM800L cutoff)
```

---

# SECTION 9: COMPLETE DECISION MATRIX

```
THE FLOOD DETECTION DECISION MATRIX
24 combinations: 4 zones × 3 rates × 2 sustained states

┌──────────┬──────────┬───────────┬──────────────┬────────────────────────────────────────────┐
│ Zone     │ Rate     │ Sustained │ Response     │ Actions                                    │
├──────────┼──────────┼───────────┼──────────────┼────────────────────────────────────────────┤
│ NORMAL   │ SLOW     │ NO        │ NORMAL       │ Routine log. No action.                    │
│ NORMAL   │ SLOW     │ YES       │ NORMAL       │ Routine log. River filling normally.        │
│ NORMAL   │ MODERATE │ NO        │ NORMAL       │ Log. Likely transient pulse.                │
│ NORMAL   │ MODERATE │ YES       │ WATCH        │ Increase sampling. No alert.                │
│ NORMAL   │ FAST     │ NO        │ NORMAL       │ Boat wake or jitter. Ignore.                │
│ NORMAL   │ FAST     │ YES       │ WATCH        │ Increase sampling. May reach ALERT soon.    │
├──────────┼──────────┼───────────┼──────────────┼────────────────────────────────────────────┤
│ ALERT    │ SLOW     │ NO        │ WATCH        │ Elevated logging. Monitor.                  │
│ ALERT    │ SLOW     │ YES       │ WATCH        │ Steady rise in ALERT. Increase sampling.    │
│ ALERT    │ MODERATE │ NO        │ WATCH        │ May be transient. Watch next readings.       │
│ ALERT    │ MODERATE │ YES       │ WARNING      │ SMS Tier 1. Rising through ALERT.           │
│ ALERT    │ FAST     │ NO        │ WATCH        │ Single fast reading. Wait for confirmation. │
│ ALERT    │ FAST     │ YES       │ WARNING      │ SMS Tier 1. Fast sustained rise.            │
├──────────┼──────────┼───────────┼──────────────┼────────────────────────────────────────────┤
│ WARNING  │ SLOW     │ NO        │ WARNING      │ SMS Tier 1. Already high water.             │
│ WARNING  │ SLOW     │ YES       │ FLOOD ALERT  │ SMS Tier 1+2. Slow persistent rise.         │
│ WARNING  │ MODERATE │ NO        │ WARNING      │ SMS Tier 1. May be transient at high level. │
│ WARNING  │ MODERATE │ YES       │ FLOOD ALERT  │ SMS Tier 1+2. Consistent rise toward danger.│
│ WARNING  │ FAST     │ NO        │ FLOOD ALERT  │ SMS Tier 1+2. FAST at WARNING = dangerous.  │
│ WARNING  │ FAST     │ YES       │ CRITICAL     │ ALL TIERS. Voice calls. River breaching.     │
├──────────┼──────────┼───────────┼──────────────┼────────────────────────────────────────────┤
│ DANGER   │ SLOW     │ NO        │ FLOOD ALERT  │ Already overflowing. Full alert.            │
│ DANGER   │ SLOW     │ YES       │ CRITICAL     │ Overflowing and rising. Maximum escalation. │
│ DANGER   │ MODERATE │ NO        │ CRITICAL     │ Overflowing with inflow. CRITICAL.          │
│ DANGER   │ MODERATE │ YES       │ CRITICAL     │ Maximum emergency. All tiers. Voice calls.  │
│ DANGER   │ FAST     │ NO        │ CRITICAL     │ Maximum emergency.                          │
│ DANGER   │ FAST     │ YES       │ CRITICAL     │ Catastrophic. All channels activated.       │
└──────────┴──────────┴───────────┴──────────────┴────────────────────────────────────────────┘

OVERRIDE RULE:
    IF rate > 30 cm/15min AND zone >= ALERT:
        response_level = CRITICAL regardless of sustained
        (Physically unmistakable: dam release or landslide breach)
```

---

# SECTION 10: UNDERWATER AND DETACHMENT DETECTION

## 10.1 Underwater Detection via BMP180

```
BMP180 PRESSURE READING INTERPRETATION:

    Normal atmospheric: 990 - 1040 hPa (varies with weather/altitude)
    Per cm of water depth: +0.981 hPa
    
    Detection uses DEVIATION from rolling baseline, not absolute value.
    Baseline = 48-reading rolling average (24 hours at 30-min intervals)

    ┌──────────────────────────┬──────────────────────────────────────┐
    │ Pressure Deviation       │ Interpretation                       │
    ├──────────────────────────┼──────────────────────────────────────┤
    │ < 5 hPa above baseline   │ Normal weather variation             │
    │                          │ Update baseline                      │
    ├──────────────────────────┼──────────────────────────────────────┤
    │ 5-8 hPa above baseline   │ Possible weather or slight           │
    │                          │ submersion. Log but no action.       │
    ├──────────────────────────┼──────────────────────────────────────┤
    │ 8-15 hPa above baseline  │ SUSPECT UNDERWATER                   │
    │                          │ Reduce sample interval to verify     │
    │                          │ on next cycle. Estimated depth:      │
    │                          │ ~8-15cm                              │
    ├──────────────────────────┼──────────────────────────────────────┤
    │ > 15 hPa above baseline  │ CONFIRMED UNDERWATER                 │
    │                          │ Estimated depth = deviation / 0.981  │
    │                          │ Trigger alert. Force transmit.       │
    ├──────────────────────────┼──────────────────────────────────────┤
    │ > 1100 hPa absolute      │ Deep submersion (>1m) or sensor      │
    │                          │ failure. Alert regardless.           │
    ├──────────────────────────┼──────────────────────────────────────┤
    │ < 300 hPa or > 1200 hPa  │ SENSOR FAILURE                       │
    │ or negative               │ Mark BMP as unavailable              │
    │                          │ Send maintenance alert               │
    └──────────────────────────┴──────────────────────────────────────┘
    
    ePTFE MEMBRANE:
        Placed over BMP180 sensor port
        Allows air pressure equalization in normal operation
        Blocks water ingress during brief submersion
        At depth >2m, water may force through membrane
        Sensor may be damaged by prolonged deep submersion
        This is acceptable — if buoy is 2m underwater, 
        the system has bigger problems
```

## 10.2 Tether Detachment Detection

```
CROSS-VALIDATION USING MPU6050 + BMP180:

    ┌──────────────────┬─────────────────┬──────────────────────────────┐
    │ MPU6050 Theta    │ BMP180 Pressure │ Diagnosis                    │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ 5° - 80°         │ Normal          │ NORMAL OPERATION             │
    │ (normal range)   │ (near baseline) │ Water level measurable       │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ < 5°             │ Normal          │ HIGH WATER (theta near 0°    │
    │ (near zero)      │ (near baseline) │ means buoy above anchor)     │
    │                  │                 │ OR TETHER DETACHED           │
    │                  │                 │ Need sustained check         │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ < 5° sustained   │ Normal          │ TETHER DETACHED              │
    │ for 6+ readings  │ (near baseline) │ Buoy floating free           │
    │ + previous theta │                 │ ACTIVATE GPS + ALERT         │
    │ was > 10°        │                 │                              │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ < 5°             │ Elevated        │ BUOY SUBMERGED               │
    │ (near zero)      │ (>baseline+15)  │ Extreme flood pushing buoy   │
    │                  │                 │ underwater. CRITICAL ALERT.  │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ Any angle        │ Very high       │ PARTIAL SUBMERSION           │
    │                  │ (>baseline+50)  │ Sensor submerged but buoy    │
    │                  │                 │ may be partially above water │
    │                  │                 │ FLOOD ALERT                  │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ accZ < -0.3g     │ Any             │ BUOY INVERTED                │
    │ (upside down)    │                 │ Physical damage or tampering │
    │                  │                 │ ALERT + GPS                  │
    ├──────────────────┼─────────────────┼──────────────────────────────┤
    │ > 30° change     │ Any             │ SUDDEN DISTURBANCE           │
    │ between readings │                 │ Possible tampering or impact │
    │                  │                 │ Set MONITOR flag             │
    │                  │                 │ Increase sampling for 30 min │
    └──────────────────┴─────────────────┴──────────────────────────────┘


DETACHMENT CONFIRMATION ALGORITHM:

    Maintained in RAM (reset on boot):
        low_theta_count = 0
        last_normal_theta = 0.0

    EVERY SENSOR READING:
        
        IF theta > 10.0:
            last_normal_theta = theta
            low_theta_count = 0
        
        IF theta < 3.0 AND NOT underwater_flag:
            low_theta_count += 1
        ELSE:
            low_theta_count = 0
        
        IF low_theta_count >= 6 AND last_normal_theta > 10.0:
            TETHER DETACHMENT CONFIRMED
            
            detach_flag = TRUE
            detach_timestamp = current_timestamp
            Save both to NVS
            
            force_transmit = TRUE
            gps_needed = TRUE
            
            Enter DETACHMENT TRACKING MODE:
                sample_interval = 5 min
                transmit_interval = 30 min (with GPS)
                
                After 24 hours:
                    sample_interval = 240 min
                    transmit_interval = 720 min (with GPS)
```

---

# SECTION 11: REALISTIC BATTERY LIFE PROJECTIONS

## 11.1 Deployment Scenario Calculations

```
USABLE BATTERY: 63,000 mWh (8×18650 1S8P, cutoff at 3.4V)

SCENARIO A: DRY SEASON (no floods)
────────────────────────────────────
    All time in NORMAL mode
    Sample: 30 min, Transmit: 8 hours (battery > 50%)
    Transitions to 12-hour transmit as battery drops below 50%
    Transitions to 24-hour transmit below 30%
    
    Month 1-3: 214 mWh/day × 90 days    = 19,260 mWh  (battery ~69%)
    Month 4-6: 157 mWh/day × 90 days    = 14,130 mWh  (battery ~47%)  
    Month 7-8: 98 mWh/day × 60 days     = 5,880 mWh   (battery ~38%)
    Month 9+:  75 mWh/day × remaining   = continues...
    
    TOTAL DURATION: ~9-10 MONTHS

SCENARIO B: LIGHT MONSOON
────────────────────────────────────
    5 days WATCH + 3 days WARNING (no CRITICAL)
    
    Month 1-3 (pre-monsoon): 214 × 90   = 19,260 mWh
    Month 4 (early monsoon):
        20 days normal: 214 × 20         = 4,280 mWh
        5 days WATCH: 706 × 5            = 3,530 mWh
        3 days WARNING: 2,753 × 3        = 8,259 mWh
        2 days normal: 214 × 2           = 428 mWh
    Month 5+ (post-monsoon at conserve): 157 × days
    
    Used through Month 4: 35,757 mWh (remaining: 27,243 mWh)
    Remaining at 157 mWh/day: 173 days = ~5.8 months more
    
    TOTAL DURATION: ~7-8 MONTHS

SCENARIO C: TYPICAL MONSOON
────────────────────────────────────
    10 days WATCH + 5 days WARNING + 2 days CRITICAL
    
    Month 1-3: 214 × 90                 = 19,260 mWh
    Monsoon period:
        10 days WATCH: 706 × 10          = 7,060 mWh
        5 days WARNING: 2,753 × 5        = 13,765 mWh
        2 days CRITICAL: 5,445 × 2       = 10,890 mWh
        Rest normal: 214 × 43            = 9,202 mWh
    
    Used: 60,177 mWh (remaining: 2,823 mWh)
    Remaining at 75 mWh/day: 37 days
    
    TOTAL DURATION: ~5-6 MONTHS

SCENARIO D: HEAVY MONSOON
────────────────────────────────────
    15 days WATCH + 10 days WARNING + 5 days CRITICAL
    
    Month 1-2: 214 × 60                 = 12,840 mWh
    Monsoon:
        15 days WATCH: 706 × 15          = 10,590 mWh
        10 days WARNING: 2,753 × 10      = 27,530 mWh
        5 days CRITICAL: 5,445 × 5       = 27,225 mWh
    
    Used: 78,185 mWh → EXCEEDS 63,000 mWh
    Battery dies during monsoon.
    
    ACTUAL: ~120 days before WARNING events consume remaining battery
    
    TOTAL DURATION: ~4 MONTHS


SUMMARY:
┌──────────────────────────────────────┬──────────────────┐
│ Scenario                             │ Maximum Duration  │
├──────────────────────────────────────┼──────────────────┤
│ Dry season (zero flood events)       │ 9-10 months       │
│ Light monsoon (8 elevated days)      │ 7-8 months        │
│ Typical monsoon (17 elevated days)   │ 5-6 months        │
│ Heavy monsoon (30 elevated days)     │ ~4 months         │
│ Extreme continuous flooding          │ 11-23 days        │
└──────────────────────────────────────┴──────────────────┘
```

---

# SECTION 12: EDGE CASES AND FAILURE HANDLING

```
┌────────────────────────────────────┬─────────────────────────────────────────────┐
│ Edge Case                          │ Handling                                    │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Device reboots with no history     │ First 4 readings: zone classification only  │
│ (power loss, brownout, crash)      │ No rate or sustained data available         │
│                                    │ IF zone >= WARNING: alert immediately       │
│                                    │ Sustained buffer fills over 4 cycles        │
│                                    │ Load write_pointer from NVS to continue     │
│                                    │ data log without losing position            │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ MPU6050 fails mid-operation        │ I2C read returns error or WHO_AM_I wrong    │
│                                    │ CRITICAL FAILURE: primary sensor lost       │
│                                    │ Send "SENSOR FAULT" SMS                     │
│                                    │ Enter MAINTENANCE mode                      │
│                                    │ Continue transmitting last known level      │
│                                    │ Flag all readings as "sensor_fault"         │
│                                    │ Retry MPU6050 init every hour               │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ BMP180 fails                       │ Set bmp_available = FALSE                   │
│                                    │ Underwater detection disabled               │
│                                    │ Continue with MPU6050 only                  │
│                                    │ Send maintenance alert SMS                  │
│                                    │ System remains operational for water level  │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ DS3231 RTC loses time              │ Coin cell dead, time resets to 2000-01-01   │
│                                    │ Detect: year < 2024                         │
│                                    │ Use relative timestamps from boot_count     │
│                                    │ Request correct time from server on next TX │
│                                    │ Readings still valid, timestamps approximate│
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ SIM800L fails to register          │ No network coverage or SIM expired          │
│                                    │ TX:FAIL:2 returned to XIAO                  │
│                                    │ Data continues to be logged locally         │
│                                    │ Retry on next scheduled transmit            │
│                                    │ After 10 consecutive failures: reduce       │
│                                    │ transmit attempts to every 4 hours (save    │
│                                    │ power on futile SIM800L boot cycles)        │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ STM32 fails to boot                │ XIAO sends "WAKE" but no "READY" response  │
│                                    │ Retry 3 times with power cycling            │
│                                    │ IF all retries fail: log comms failure      │
│                                    │ Data continues to log locally               │
│                                    │ Try again on next scheduled transmit        │
│                                    │ All readings preserved in flash             │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Battery critical + river in DANGER │ FLOOD DETECTION OVERRIDES POWER SAVING      │
│                                    │ Switch to SMS-only (no GPRS, saves power)   │
│                                    │ Sample every 5 min, SMS every 15 min        │
│                                    │ Accept device will die soon                 │
│                                    │ Device dies transmitting warnings           │
│                                    │ NOT silently                                │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Flash storage full                 │ Circular buffer wraps automatically         │
│                                    │ Oldest transmitted records overwritten      │
│                                    │ IF untransmitted records exist at boundary: │
│                                    │ Force transmission before overwriting       │
│                                    │ In practice: 65,536 records = years of data │
│                                    │ This scenario is extremely unlikely         │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ GPS never gets fix (dense canopy)  │ Return GPS:NOFIX to XIAO                   │
│                                    │ Report last known location (from NVS)       │
│                                    │ Or report "NO GPS FIX" in alert SMS         │
│                                    │ Retry on next transmit cycle                │
│                                    │ After 3 consecutive NOFIX: extend timeout   │
│                                    │ to 120 seconds on next attempt              │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Simultaneous underwater + detach   │ BMP says underwater + theta near 0°         │
│                                    │ Underwater takes priority over detachment   │
│                                    │ This is an extreme flood, not tampering     │
│                                    │ CRITICAL alert sent                         │
│                                    │ GPS NOT activated (buoy still tethered)     │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Temperature extremes               │ MPU6050 operating range: -40°C to +85°C    │
│                                    │ BMP180 operating range: -40°C to +85°C     │
│                                    │ 18650 cells degrade below 0°C              │
│                                    │ System monitors BMP temperature             │
│                                    │ IF temp < 0°C: reduce transmit frequency   │
│                                    │ (cold batteries have less capacity)         │
│                                    │ IF temp > 60°C: possible fire/damage alert  │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Sustained false high theta         │ Debris caught on rope or arm                │
│ (rope tangled, float stuck)        │ Water level reads incorrectly low           │
│                                    │ Detection: theta stable at unusual value    │
│                                    │ for >24 hours with no weather correlation   │
│                                    │ Send maintenance alert:                     │
│                                    │ "SENSOR READING ANOMALY - CHECK FLOAT"      │
├────────────────────────────────────┼─────────────────────────────────────────────┤
│ Rapid oscillation (waves)          │ Multi-sample averaging handles this         │
│                                    │ 10 samples, discard 4 outliers, avg 6       │
│                                    │ Residual oscillation: ±0.5° maximum         │
│                                    │ At OLP=100cm: ±0.04cm error                 │
│                                    │ Completely acceptable                       │
└────────────────────────────────────┴─────────────────────────────────────────────┘
```

---

# SECTION 13: OPERATIONAL MODES SUMMARY

```
┌───────────────────┬────────────────────────────────────────────────────────────┐
│ Mode              │ Description and Behavior                                   │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ NORMAL            │ Standard operation. Sample every 30 min. Transmit per      │
│                   │ battery level (8h to 48h). All sensors active during       │
│                   │ reading cycle. Full flood detection algorithm running.     │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ WATCH             │ Elevated monitoring. Sample every 10-15 min. No SMS       │
│                   │ alerts sent. Internal flag only. Dashboard shows yellow.  │
│                   │ Entered when rate is significant but level is safe.       │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ WARNING           │ SMS sent to Tier 1 (district office). Sample every 5-10   │
│                   │ min. Transmit every 30-60 min. Entered when level crosses │
│                   │ ALERT zone with sustained rise OR enters WARNING zone.    │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ FLOOD ALERT       │ SMS to Tier 1 + Tier 2. Sample every 5 min. Transmit     │
│                   │ every 15-30 min. Entered when WARNING zone with           │
│                   │ sustained rise or DANGER zone reached.                    │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ CRITICAL          │ SMS to ALL tiers. Maximum sample rate (2 min). Maximum    │
│                   │ transmit rate (15 min). Voice call attempted if SMS not   │
│                   │ acknowledged. Entered when DANGER zone with rising trend. │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ CONSERVE          │ Battery saving mode. Longer sleep intervals. Fewer        │
│                   │ transmissions. Still full flood detection. Entered when   │
│                   │ battery < 30% and zone is NORMAL.                         │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ HIBERNATE         │ Extreme battery saving. Sample every 2-4 hours. Transmit  │
│                   │ daily or less. Entered when battery < 15% and NORMAL.     │
│                   │ Immediately exits if zone reaches WARNING.                │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ EMERGENCY         │ Battery < 5% or SIM800L voltage threshold reached.        │
│                   │ If NORMAL: local logging only, no transmission.           │
│                   │ If DANGER: SMS-only alerts, dies transmitting.            │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ DETACHMENT        │ Tether break confirmed. GPS tracking activated. Intensive │
│ TRACKING          │ for 24 hours, then hibernates with periodic GPS pings.    │
├───────────────────┼────────────────────────────────────────────────────────────┤
│ MAINTENANCE       │ Entered on critical sensor failure. Transmits diagnostic  │
│                   │ data. Awaits physical intervention. Retries sensor init   │
│                   │ periodically.                                             │
└───────────────────┴────────────────────────────────────────────────────────────┘
```

---

# SECTION 14: PHYSICAL INSTALLATION NOTES

```
BUOY ASSEMBLY:
    1. Mount MPU6050 FLAT on TOP of buoy surface
    2. MPU6050 AD0 pin connected to 3.3V (sets address to 0x69)
    3. Waterproof cable from MPU6050 to enclosure (I2C + power, 4 wires)
    4. BMP180 mounted INSIDE enclosure with ePTFE membrane over sensor port
    5. ePTFE membrane faces OUTWARD through enclosure wall
    6. All electronics except MPU6050 are inside sealed enclosure
    7. Enclosure mounted on buoy or on bank (cable to buoy MPU6050)

ANTENNA PLACEMENT:
    SIM800L GSM antenna: OUTSIDE enclosure or through RF-transparent window
    GPS antenna: OUTSIDE enclosure with clear sky view
    Both antennas must not be submerged

TETHER ROPE:
    Connects bottom of buoy to anchor on riverbed
    Length = OLP (configured via SMS)
    Stainless steel cable recommended for river deployment
    Anchor: concrete block or screw pile on riverbed

CALIBRATION:
    After installation, with buoy floating level:
    Send SMS: "CALIBRATE"
    Wait 3 minutes
    Confirm: receive "CALIBRATION SCHEDULED FOR NEXT CYCLE"
    Then receive status SMS confirming calibration complete
    Set OLP: send "SET OLP <measured_rope_length>"
    Set thresholds: send "SET THRESHOLD <alert>,<warning>,<danger>"
```

---

This document covers every aspect of the VARUNA field device: hardware, wiring, power, firmware logic for both MCUs, communication protocols, flood detection algorithm, adaptive sampling, underwater detection, tether detachment, GPS tracking, battery life projections, edge cases, and installation. Every feature from the original system specification is preserved and implemented.
