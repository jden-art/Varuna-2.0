/*
 * WATER LEVEL MEASURING SYSTEM
 * 
 * MPU6050 mounted TANGENTIALLY (FLAT) on buoy surface
 * Z-axis points UP (perpendicular to buoy surface)
 * X,Y axes are along the buoy surface
 * 
 *         Z↑ (UP from buoy surface)
 *         |
 *    ═════╬═════ MPU6050 flat on buoy
 *    ║  BUOY   ║
 *    ╚═════════╝
 *         |
 *         | OLP rope
 *         |
 *         ● ANCHOR
 * 
 * When buoy is level: Z = vertical up, accZ = +1g
 * When buoy tilts:    Z tilts, accX/accY pick up gravity components
 * 
 * θ = tilt from vertical = atan2(sqrt(accX² + accY²), accZ)
 * 
 * H = OLP × cos(θ)
 * 
 * WIRING:
 *   MPU6050 VCC → Arduino 3.3V
 *   MPU6050 GND → Arduino GND
 *   MPU6050 SCL → Arduino A5
 *   MPU6050 SDA → Arduino A4
 */

#include <Wire.h>
#include <math.h>

#define MPU6050_ADDR 0x68

int16_t accX, accY, accZ;
int16_t gyroX, gyroY, gyroZ;

/* Gyro calibration */
float gyroOffsetX = 0;
float gyroOffsetY = 0;
float gyroOffsetZ = 0;

/*
 * REFERENCE CALIBRATION
 * Stores the gravity vector direction at calibration
 * So we measure tilt RELATIVE to calibration position
 */
float refAccX = 0;
float refAccY = 0;
float refAccZ = 1.0;  /* Default: Z pointing straight up */

/* 
 * Reference angles at calibration (for tangential mounting)
 * These represent the "zero" tilt state
 */
float refTiltX = 0;  /* Reference tilt around X */
float refTiltY = 0;  /* Reference tilt around Y */

/* Filtered tilt angles (relative to buoy surface) */
float filtTiltX = 0;
float filtTiltY = 0;

unsigned long prevTime = 0;

#define ALPHA 0.98  /* Higher = trust gyro more, smoother but slower */

float olpLength = 100.0;

String inputBuffer = "";

#define LED_PIN 13

void setup()
{
    Serial.begin(9600);
    Wire.begin();
    pinMode(LED_PIN, OUTPUT);

    /* Initialize MPU6050 */
    writeReg(0x6B, 0x00);
    delay(100);
    writeReg(0x19, 0x07);   /* Sample rate divider */
    writeReg(0x1A, 0x03);   /* DLPF ~44Hz */
    writeReg(0x1B, 0x00);   /* Gyro ±250 deg/s */
    writeReg(0x1C, 0x00);   /* Accel ±2g */
    delay(100);

    uint8_t who = readReg(0x75);
    if (who != 0x68)
    {
        Serial.println("ERROR:MPU6050_NOT_FOUND");
        while (1)
        {
            digitalWrite(LED_PIN, !digitalRead(LED_PIN));
            delay(200);
        }
    }
    Serial.println("STATUS:MPU6050_OK");

    /*
     * ════════════════════════════════════════
     *  CALIBRATION
     *  MPU6050 is FLAT on buoy
     *  Keep buoy LEVEL and STILL
     *  This position = θ = 0°
     * ════════════════════════════════════════
     */
    Serial.println("STATUS:CALIBRATING");
    Serial.println("STATUS:KEEP_BUOY_LEVEL_AND_STILL");

    /* Blink LED during calibration */
    for (int i = 0; i < 6; i++)
    {
        digitalWrite(LED_PIN, HIGH);
        delay(250);
        digitalWrite(LED_PIN, LOW);
        delay(250);
    }

    /* STEP 1: Calibrate gyro offsets */
    Serial.println("STATUS:CALIBRATING_GYRO");
    float sumGX = 0, sumGY = 0, sumGZ = 0;
    for (int i = 0; i < 1000; i++)
    {
        readMPU();
        sumGX += gyroX;
        sumGY += gyroY;
        sumGZ += gyroZ;
        delay(2);
    }
    gyroOffsetX = sumGX / 1000.0;
    gyroOffsetY = sumGY / 1000.0;
    gyroOffsetZ = sumGZ / 1000.0;

    /* STEP 2: Find reference gravity vector (tangential mounting) */
    Serial.println("STATUS:CALIBRATING_REFERENCE");

    float sumAX = 0, sumAY = 0, sumAZ = 0;
    int validCount = 0;

    for (int i = 0; i < 500; i++)
    {
        readMPU();

        float ax = accX / 16384.0;
        float ay = accY / 16384.0;
        float az = accZ / 16384.0;

        float totalG = sqrt(ax * ax + ay * ay + az * az);
        if (totalG > 0.9 && totalG < 1.1)
        {
            sumAX += ax;
            sumAY += ay;
            sumAZ += az;
            validCount++;
        }
        delay(3);
    }

    if (validCount > 100)
    {
        refAccX = sumAX / validCount;
        refAccY = sumAY / validCount;
        refAccZ = sumAZ / validCount;
    }
    else
    {
        readMPU();
        refAccX = accX / 16384.0;
        refAccY = accY / 16384.0;
        refAccZ = accZ / 16384.0;
    }

    /*
     * Calculate reference tilt angles
     * For tangential mounting:
     * tiltX = atan2(accY, accZ) → tilt around X axis
     * tiltY = atan2(accX, accZ) → tilt around Y axis
     * 
     * These use accZ because Z points UP from the flat sensor
     */
    refTiltX = atan2(refAccY, refAccZ) * 180.0 / PI;
    refTiltY = atan2(refAccX, refAccZ) * 180.0 / PI;

    /* Initialize filtered angles to reference */
    filtTiltX = refTiltX;
    filtTiltY = refTiltY;

    prevTime = millis();

    digitalWrite(LED_PIN, HIGH);

    Serial.print("STATUS:REF_GRAVITY=");
    Serial.print(refAccX, 3);
    Serial.print(",");
    Serial.print(refAccY, 3);
    Serial.print(",");
    Serial.println(refAccZ, 3);
    Serial.print("STATUS:REF_TILTX=");
    Serial.println(refTiltX, 2);
    Serial.print("STATUS:REF_TILTY=");
    Serial.println(refTiltY, 2);
    Serial.println("STATUS:CALIBRATION_DONE");
    Serial.println("STATUS:ANGLE_IS_NOW_ZERO");
    Serial.println("STATUS:READY");
    delay(500);
}

void loop()
{
    checkSerialInput();
    readMPU();

    unsigned long now = millis();
    float dt = (now - prevTime) / 1000.0;
    prevTime = now;
    if (dt <= 0 || dt > 0.5) dt = 0.008;

    /*
     * TANGENTIAL MOUNTING ANGLE CALCULATION
     * 
     * MPU6050 is FLAT on buoy:
     *   Z axis = UP (perpendicular to buoy surface)
     *   X axis = forward along buoy surface
     *   Y axis = sideways along buoy surface
     * 
     * When buoy is level:
     *   accX ≈ 0, accY ≈ 0, accZ ≈ +1g
     * 
     * When buoy tilts:
     *   gravity projects onto X and Y axes
     *   accZ decreases (less gravity along Z)
     * 
     * Tilt angles from accelerometer:
     *   tiltX = atan2(accY, accZ)  → rotation around X axis
     *   tiltY = atan2(accX, accZ)  → rotation around Y axis
     * 
     * These are correct for FLAT/TANGENTIAL mounting
     * because Z is the "up" axis of the sensor
     */

    float ax = accX / 16384.0;
    float ay = accY / 16384.0;
    float az = accZ / 16384.0;

    /* Gyro rates in deg/s */
    float gx = (gyroX - gyroOffsetX) / 131.0;
    float gy = (gyroY - gyroOffsetY) / 131.0;

    /* Accelerometer tilt angles (tangential mounting) */
    float accTiltX = atan2(ay, az) * 180.0 / PI;
    float accTiltY = atan2(ax, az) * 180.0 / PI;

    /* Complementary filter */
    filtTiltX = ALPHA * (filtTiltX + gx * dt) + (1.0 - ALPHA) * accTiltX;
    filtTiltY = ALPHA * (filtTiltY + gy * dt) + (1.0 - ALPHA) * accTiltY;

    /*
     * SUBTRACT REFERENCE to get zero-corrected angles
     * After calibration: corrected = 0°
     * After tilting: corrected = actual tilt
     */
    float correctedTiltX = filtTiltX - refTiltX;
    float correctedTiltY = filtTiltY - refTiltY;

    /*
     * TOTAL TILT ANGLE θ
     * 
     * For tangential mounting, θ is the angle between
     * the sensor's Z-axis and true vertical
     * = angle the buoy surface has tilted from horizontal
     * = angle the rope has tilted from vertical
     * 
     * θ = sqrt(tiltX² + tiltY²) for small-medium angles
     * 
     * OR more accurately using the direct method:
     * θ = atan2(sqrt(ax² + ay²), az) → angle of Z from vertical
     * But we use the filtered version for stability
     */
    float theta = sqrt(correctedTiltX * correctedTiltX +
                       correctedTiltY * correctedTiltY);

    if (theta > 90.0) theta = 90.0;
    if (theta < 0.0)  theta = 0.0;

    float thetaRad = theta * PI / 180.0;

    /* H = OLP × cos(θ) */
    float waterHeight    = olpLength * cos(thetaRad);
    float horizontalDist = olpLength * sin(thetaRad);

    /* CSV: theta, waterHeight, correctedTiltX, correctedTiltY, olpLength, horizontal */
    Serial.print(theta, 2);
    Serial.print(",");
    Serial.print(waterHeight, 2);
    Serial.print(",");
    Serial.print(correctedTiltX, 2);
    Serial.print(",");
    Serial.print(correctedTiltY, 2);
    Serial.print(",");
    Serial.print(olpLength, 2);
    Serial.print(",");
    Serial.println(horizontalDist, 2);

    delay(50);
}

/* ========== MPU6050 FUNCTIONS ========== */

void writeReg(uint8_t reg, uint8_t val)
{
    Wire.beginTransmission(MPU6050_ADDR);
    Wire.write(reg);
    Wire.write(val);
    Wire.endTransmission();
}

uint8_t readReg(uint8_t reg)
{
    Wire.beginTransmission(MPU6050_ADDR);
    Wire.write(reg);
    Wire.endTransmission(false);
    Wire.requestFrom(MPU6050_ADDR, 1);
    return Wire.read();
}

void readMPU()
{
    Wire.beginTransmission(MPU6050_ADDR);
    Wire.write(0x3B);
    Wire.endTransmission(false);
    Wire.requestFrom(MPU6050_ADDR, 14);

    accX  = Wire.read() << 8 | Wire.read();
    accY  = Wire.read() << 8 | Wire.read();
    accZ  = Wire.read() << 8 | Wire.read();
    Wire.read(); Wire.read();
    gyroX = Wire.read() << 8 | Wire.read();
    gyroY = Wire.read() << 8 | Wire.read();
    gyroZ = Wire.read() << 8 | Wire.read();
}

/* ========== SERIAL INPUT ========== */

void checkSerialInput()
{
    while (Serial.available())
    {
        char c = Serial.read();
        if (c == '\n' || c == '\r')
        {
            inputBuffer.trim();

            if (inputBuffer.startsWith("OLP:"))
            {
                float val = inputBuffer.substring(4).toFloat();
                if (val > 0 && val < 10000)
                    olpLength = val;
            }
            else if (inputBuffer == "CAL")
            {
                recalibrate();
            }

            inputBuffer = "";
        }
        else
        {
            inputBuffer += c;
        }
    }
}

/* ========== RECALIBRATE ========== */

void recalibrate()
{
    Serial.println("STATUS:RECALIBRATING");

    /* Quick gyro recal */
    float sumGX = 0, sumGY = 0;
    for (int i = 0; i < 300; i++)
    {
        readMPU();
        sumGX += gyroX;
        sumGY += gyroY;
        delay(2);
    }
    gyroOffsetX = sumGX / 300.0;
    gyroOffsetY = sumGY / 300.0;

    /* New reference gravity vector */
    float sumAX = 0, sumAY = 0, sumAZ = 0;
    int count = 0;
    for (int i = 0; i < 300; i++)
    {
        readMPU();
        float ax = accX / 16384.0;
        float ay = accY / 16384.0;
        float az = accZ / 16384.0;

        float totalG = sqrt(ax * ax + ay * ay + az * az);
        if (totalG > 0.9 && totalG < 1.1)
        {
            sumAX += ax;
            sumAY += ay;
            sumAZ += az;
            count++;
        }
        delay(2);
    }

    if (count > 50)
    {
        refAccX = sumAX / count;
        refAccY = sumAY / count;
        refAccZ = sumAZ / count;
    }

    /* New reference tilt (tangential) */
    refTiltX = atan2(refAccY, refAccZ) * 180.0 / PI;
    refTiltY = atan2(refAccX, refAccZ) * 180.0 / PI;

    /* Reset filters to new reference */
    filtTiltX = refTiltX;
    filtTiltY = refTiltY;

    Serial.print("STATUS:NEW_REF_TILTX=");
    Serial.println(refTiltX, 2);
    Serial.print("STATUS:NEW_REF_TILTY=");
    Serial.println(refTiltY, 2);
    Serial.println("STATUS:RECALIBRATED_ZERO");
}
