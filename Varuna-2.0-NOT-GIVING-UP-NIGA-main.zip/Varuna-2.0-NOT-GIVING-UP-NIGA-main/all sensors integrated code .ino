#include <Wire.h>
#include <HardwareSerial.h>
#include <math.h>

#define MPU6050_ADDR 0x68
#define BMP280_ADDR 0x76
#define DS1307_ADDR 0x68

#define BUS0_SDA 8
#define BUS0_SCL 9

#define BUS1_SDA 4
#define BUS1_SCL 5

#define GPS_RX_PIN 6
#define GPS_TX_PIN 7

#define SIM_RX_PIN 15
#define SIM_TX_PIN 16
#define SIM_RST_PIN 17

#define LED_PIN 3

#define ALPHA 0.98

TwoWire I2C_BUS0 = TwoWire(0);
TwoWire I2C_BUS1 = TwoWire(1);
HardwareSerial GPS_Serial(1);
HardwareSerial SIM_Serial(2);

/* ========== MPU6050 VARIABLES ========== */

int16_t accX, accY, accZ;
int16_t gyroX, gyroY, gyroZ;

float gyroOffsetX = 0;
float gyroOffsetY = 0;
float gyroOffsetZ = 0;

float refAccX = 0;
float refAccY = 0;
float refAccZ = 1.0;

float refTiltX = 0;
float refTiltY = 0;

float filtTiltX = 0;
float filtTiltY = 0;

unsigned long prevTime = 0;

float olpLength = 100.0;

String inputBuffer = "";

/* ========== BMP280 VARIABLES ========== */

boolean bmpAvailable = false;

uint16_t bmpDigT1;
int16_t bmpDigT2, bmpDigT3;
uint16_t bmpDigP1;
int16_t bmpDigP2, bmpDigP3, bmpDigP4, bmpDigP5;
int16_t bmpDigP6, bmpDigP7, bmpDigP8, bmpDigP9;
int32_t bmpTFine;

float currentPressure = 0;
float currentTemperature = 0;

#define BASELINE_SIZE 48
float baselineBuffer[BASELINE_SIZE];
int baselineIndex = 0;
int baselineCount = 0;
float baselineSum = 0;
float baselinePressure = 0;

unsigned long lastBaselineUpdate = 0;
#define BASELINE_INTERVAL 1800000

unsigned long lastBmpRead = 0;
#define BMP_READ_INTERVAL 5000

int submersionState = 0;
float pressureDeviation = 0;
float estimatedDepth = 0;

/* ========== DS1307 RTC VARIABLES ========== */

boolean rtcAvailable = false;
boolean rtcTimeValid = false;
uint32_t currentUnixTime = 0;
uint8_t rtcSeconds, rtcMinutes, rtcHours;
uint8_t rtcDay, rtcMonth;
uint16_t rtcYear;
uint8_t rtcDayOfWeek;

unsigned long lastRtcRead = 0;
#define RTC_READ_INTERVAL 1000

uint32_t bootUnixTime = 0;
uint32_t sessionStartUnix = 0;
uint32_t sessionDuration = 0;

/* ========== RATE OF CHANGE VARIABLES ========== */

uint32_t prevReadingTime = 0;
float prevWaterHeight = 0;
float rateOfChange = 0;
float ratePer15Min = 0;

/* ========== DATA LOG VARIABLES ========== */

#define LOG_SIZE 120
float logHeight[LOG_SIZE];
float logTheta[LOG_SIZE];
float logPressure[LOG_SIZE];
uint32_t logTime[LOG_SIZE];
int logIndex = 0;
int logCount = 0;

unsigned long lastLogWrite = 0;
#define LOG_INTERVAL 10000

/* ========== FLOOD ALERT VARIABLES ========== */

int floodAlertLevel = 0;
float peakHeight = 0;
float minHeight = 9999;
uint32_t peakTime = 0;
uint32_t minTime = 0;

/* ========== GPS VARIABLES ========== */

double gpsLat = 0;
double gpsLon = 0;
float gpsAlt = 0;
float gpsSpeed = 0;
float gpsHdop = 99.9;
int gpsSatellites = 0;
boolean gpsFixValid = false;
boolean gpsAvailable = false;

uint8_t gpsHour = 0;
uint8_t gpsMin = 0;
uint8_t gpsSec = 0;
uint8_t gpsGGADay = 0;
uint8_t gpsGGAMonth = 0;
uint16_t gpsGGAYear = 0;
boolean gpsTimeValid = false;
boolean gpsTimeSynced = false;

char nmeaBuffer[120];
int nmeaIdx = 0;

unsigned long lastGpsProcess = 0;
#define GPS_PROCESS_INTERVAL 100

/* ========== SIM800L VARIABLES ========== */

#define SIM_RESPONSE_SIZE 256
char simResponseBuffer[SIM_RESPONSE_SIZE];

boolean simAvailable = false;
boolean simRegistered = false;
boolean simReady = false;
int simSignalRSSI = 0;
int simInitFailCode = 0;

unsigned long lastSimSignalCheck = 0;
#define SIM_SIGNAL_INTERVAL 60000

unsigned long lastSimRegistrationCheck = 0;
#define SIM_REG_CHECK_INTERVAL 30000

enum ATResult
{
    AT_SUCCESS = 0,
    AT_TIMEOUT = 1,
    AT_ERROR = 2
};

/* ========== BCD CONVERSION ========== */

uint8_t bcdToDec(uint8_t val)
{
    return ((val >> 4) * 10) + (val & 0x0F);
}

uint8_t decToBcd(uint8_t val)
{
    return ((val / 10) << 4) | (val % 10);
}

/* ========== DS1307 RTC FUNCTIONS ========== */

boolean rtcInit()
{
    I2C_BUS1.beginTransmission(DS1307_ADDR);
    uint8_t err = I2C_BUS1.endTransmission();
    if (err != 0)
    {
        return false;
    }

    I2C_BUS1.beginTransmission(DS1307_ADDR);
    I2C_BUS1.write(0x00);
    I2C_BUS1.endTransmission(false);
    I2C_BUS1.requestFrom((uint8_t)DS1307_ADDR, (uint8_t)1);
    uint8_t reg0 = I2C_BUS1.read();

    if (reg0 & 0x80)
    {
        I2C_BUS1.beginTransmission(DS1307_ADDR);
        I2C_BUS1.write(0x00);
        I2C_BUS1.write(reg0 & 0x7F);
        I2C_BUS1.endTransmission();
    }

    I2C_BUS1.beginTransmission(DS1307_ADDR);
    I2C_BUS1.write(0x07);
    I2C_BUS1.write(0x00);
    I2C_BUS1.endTransmission();

    return true;
}

void rtcReadRaw()
{
    I2C_BUS1.beginTransmission(DS1307_ADDR);
    I2C_BUS1.write(0x00);
    I2C_BUS1.endTransmission(false);
    I2C_BUS1.requestFrom((uint8_t)DS1307_ADDR, (uint8_t)7);

    rtcSeconds = bcdToDec(I2C_BUS1.read() & 0x7F);
    rtcMinutes = bcdToDec(I2C_BUS1.read() & 0x7F);

    uint8_t hourReg = I2C_BUS1.read();
    if (hourReg & 0x40)
    {
        uint8_t hr = bcdToDec(hourReg & 0x1F);
        if (hourReg & 0x20)
        {
            hr += 12;
        }
        if (hr == 12 && !(hourReg & 0x20))
        {
            hr = 0;
        }
        if (hr == 24)
        {
            hr = 12;
        }
        rtcHours = hr;
    }
    else
    {
        rtcHours = bcdToDec(hourReg & 0x3F);
    }

    rtcDayOfWeek = bcdToDec(I2C_BUS1.read() & 0x07);
    rtcDay = bcdToDec(I2C_BUS1.read() & 0x3F);
    rtcMonth = bcdToDec(I2C_BUS1.read() & 0x1F);
    rtcYear = 2000 + bcdToDec(I2C_BUS1.read());
}

boolean rtcIsTimeValid()
{
    return (rtcYear >= 2024 && rtcMonth >= 1 && rtcMonth <= 12 && rtcDay >= 1 && rtcDay <= 31);
}

uint32_t dateToUnix(uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second)
{
    uint16_t y = year;
    uint8_t m = month;

    if (m <= 2)
    {
        y -= 1;
        m += 12;
    }

    uint32_t dayCount = 365UL * y + y / 4 - y / 100 + y / 400;
    dayCount += (153UL * (m - 3) + 2) / 5;
    dayCount += day;
    dayCount -= 719469UL;

    uint32_t t = dayCount * 86400UL;
    t += (uint32_t)hour * 3600UL;
    t += (uint32_t)minute * 60UL;
    t += second;

    return t;
}

uint32_t rtcGetUnixTime()
{
    rtcReadRaw();
    if (!rtcIsTimeValid())
    {
        return 0;
    }
    return dateToUnix(rtcYear, rtcMonth, rtcDay, rtcHours, rtcMinutes, rtcSeconds);
}

void unixToDate(uint32_t unixTime, uint16_t *year, uint8_t *month, uint8_t *day, uint8_t *hour, uint8_t *minute, uint8_t *second, uint8_t *dow)
{
    *second = unixTime % 60;
    unixTime /= 60;
    *minute = unixTime % 60;
    unixTime /= 60;
    *hour = unixTime % 24;
    unixTime /= 24;

    *dow = ((unixTime + 4) % 7) + 1;

    uint32_t days = unixTime;
    uint32_t y = 1970;

    while (1)
    {
        boolean leap = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
        uint32_t daysInYear = leap ? 366 : 365;
        if (days < daysInYear)
        {
            break;
        }
        days -= daysInYear;
        y++;
    }
    *year = y;

    uint8_t daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    boolean leap = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
    if (leap)
    {
        daysInMonth[1] = 29;
    }

    uint8_t mo = 0;
    while (mo < 12 && days >= daysInMonth[mo])
    {
        days -= daysInMonth[mo];
        mo++;
    }
    *month = mo + 1;
    *day = days + 1;
}

void rtcSetUnixTime(uint32_t unixTime)
{
    uint16_t y;
    uint8_t mo, d, h, mi, s, dow;
    unixToDate(unixTime, &y, &mo, &d, &h, &mi, &s, &dow);

    I2C_BUS1.beginTransmission(DS1307_ADDR);
    I2C_BUS1.write(0x00);
    I2C_BUS1.write(decToBcd(s) & 0x7F);
    I2C_BUS1.write(decToBcd(mi));
    I2C_BUS1.write(decToBcd(h));
    I2C_BUS1.write(decToBcd(dow));
    I2C_BUS1.write(decToBcd(d));
    I2C_BUS1.write(decToBcd(mo));
    I2C_BUS1.write(decToBcd(y - 2000));
    I2C_BUS1.endTransmission();
}

void rtcSetDateTime(uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second)
{
    uint32_t unix = dateToUnix(year, month, day, hour, minute, second);
    rtcSetUnixTime(unix);
}

/* ========== GPS NMEA PARSING FUNCTIONS ========== */

double nmeaToDecimal(const char* coord, char dir)
{
    double raw = atof(coord);
    int degrees = (int)(raw / 100);
    double minutes = raw - (degrees * 100.0);
    double decimal = degrees + minutes / 60.0;
    if (dir == 'S' || dir == 'W')
    {
        decimal = -decimal;
    }
    return decimal;
}

void parseGPGGA(char* sentence)
{
    char* fields[15];
    int fieldCount = 0;
    char* ptr = sentence;

    fields[fieldCount++] = ptr;
    while (*ptr && fieldCount < 15)
    {
        if (*ptr == ',')
        {
            *ptr = '\0';
            fields[fieldCount++] = ptr + 1;
        }
        ptr++;
    }

    if (fieldCount < 10)
    {
        return;
    }

    if (strlen(fields[1]) >= 6)
    {
        char hh[3] = {fields[1][0], fields[1][1], 0};
        char mm[3] = {fields[1][2], fields[1][3], 0};
        char ss[3] = {fields[1][4], fields[1][5], 0};
        gpsHour = atoi(hh);
        gpsMin = atoi(mm);
        gpsSec = atoi(ss);
    }

    int fix = atoi(fields[6]);
    gpsSatellites = atoi(fields[7]);

    if (strlen(fields[8]) > 0)
    {
        gpsHdop = atof(fields[8]);
    }

    if (fix >= 1 && strlen(fields[2]) > 0 && strlen(fields[4]) > 0)
    {
        gpsFixValid = true;
        gpsLat = nmeaToDecimal(fields[2], fields[3][0]);
        gpsLon = nmeaToDecimal(fields[4], fields[5][0]);

        if (strlen(fields[9]) > 0)
        {
            gpsAlt = atof(fields[9]);
        }
    }
    else
    {
        gpsFixValid = false;
    }
}

void parseGPRMC(char* sentence)
{
    char* fields[14];
    int fieldCount = 0;
    char* ptr = sentence;

    fields[fieldCount++] = ptr;
    while (*ptr && fieldCount < 14)
    {
        if (*ptr == ',')
        {
            *ptr = '\0';
            fields[fieldCount++] = ptr + 1;
        }
        ptr++;
    }

    if (fieldCount < 10)
    {
        return;
    }

    if (fields[2][0] == 'A')
    {
        if (strlen(fields[3]) > 0 && strlen(fields[5]) > 0)
        {
            gpsFixValid = true;
            gpsLat = nmeaToDecimal(fields[3], fields[4][0]);
            gpsLon = nmeaToDecimal(fields[5], fields[6][0]);
        }

        if (strlen(fields[7]) > 0)
        {
            gpsSpeed = atof(fields[7]) * 1.852;
        }

        if (strlen(fields[9]) >= 6)
        {
            char dd[3] = {fields[9][0], fields[9][1], 0};
            char mm[3] = {fields[9][2], fields[9][3], 0};
            char yy[3] = {fields[9][4], fields[9][5], 0};
            gpsGGADay = atoi(dd);
            gpsGGAMonth = atoi(mm);
            gpsGGAYear = 2000 + atoi(yy);
            gpsTimeValid = true;
        }
    }

    if (strlen(fields[1]) >= 6)
    {
        char hh[3] = {fields[1][0], fields[1][1], 0};
        char mm[3] = {fields[1][2], fields[1][3], 0};
        char ss[3] = {fields[1][4], fields[1][5], 0};
        gpsHour = atoi(hh);
        gpsMin = atoi(mm);
        gpsSec = atoi(ss);
    }
}

void processNMEA(char* sentence)
{
    if (strncmp(sentence, "$GPGGA", 6) == 0 || strncmp(sentence, "$GNGGA", 6) == 0)
    {
        parseGPGGA(sentence);
        gpsAvailable = true;
    }
    else if (strncmp(sentence, "$GPRMC", 6) == 0 || strncmp(sentence, "$GNRMC", 6) == 0)
    {
        parseGPRMC(sentence);
        gpsAvailable = true;
    }
}

void readGPS()
{
    while (GPS_Serial.available())
    {
        char c = GPS_Serial.read();

        if (c == '$')
        {
            nmeaIdx = 0;
            nmeaBuffer[nmeaIdx++] = c;
        }
        else if (c == '\n' || c == '\r')
        {
            if (nmeaIdx > 5)
            {
                nmeaBuffer[nmeaIdx] = '\0';

                char* star = strchr(nmeaBuffer, '*');
                if (star)
                {
                    *star = '\0';
                }

                processNMEA(nmeaBuffer);
            }
            nmeaIdx = 0;
        }
        else if (nmeaIdx < 118)
        {
            nmeaBuffer[nmeaIdx++] = c;
        }
    }
}

void syncRTCfromGPS()
{
    if (!gpsTimeValid || !gpsFixValid || gpsTimeSynced)
    {
        return;
    }
    if (!rtcAvailable)
    {
        return;
    }
    if (gpsGGAYear < 2024)
    {
        return;
    }

    rtcSetDateTime(gpsGGAYear, gpsGGAMonth, gpsGGADay, gpsHour, gpsMin, gpsSec);
    rtcReadRaw();
    rtcTimeValid = rtcIsTimeValid();
    currentUnixTime = rtcGetUnixTime();
    gpsTimeSynced = true;

    Serial.print("STATUS:RTC_SYNCED_FROM_GPS=");
    Serial.print(gpsGGAYear);
    Serial.print("-");
    Serial.print(gpsGGAMonth);
    Serial.print("-");
    Serial.print(gpsGGADay);
    Serial.print(" ");
    Serial.print(gpsHour);
    Serial.print(":");
    Serial.print(gpsMin);
    Serial.print(":");
    Serial.println(gpsSec);
}

/* ========== SIM800L AT COMMAND ENGINE ========== */

void simFlushInput()
{
    while (SIM_Serial.available())
    {
        SIM_Serial.read();
    }
}

ATResult send_at_command(const char* command, const char* expected, unsigned long timeout_ms)
{
    simFlushInput();

    SIM_Serial.println(command);

    unsigned long startTime = millis();
    int bufIdx = 0;
    memset(simResponseBuffer, 0, SIM_RESPONSE_SIZE);

    while ((millis() - startTime) < timeout_ms)
    {
        while (SIM_Serial.available())
        {
            char c = SIM_Serial.read();

            if (bufIdx < SIM_RESPONSE_SIZE - 1)
            {
                simResponseBuffer[bufIdx++] = c;
                simResponseBuffer[bufIdx] = '\0';
            }

            if (strstr(simResponseBuffer, expected) != NULL)
            {
                return AT_SUCCESS;
            }

            if (strstr(simResponseBuffer, "ERROR") != NULL)
            {
                return AT_ERROR;
            }
        }
        delay(10);
    }

    return AT_TIMEOUT;
}

/* ========== SIM800L HARDWARE RESET ========== */

void simHardwareReset()
{
    Serial.println("STATUS:SIM800L_HARDWARE_RESET");

    pinMode(SIM_RST_PIN, OUTPUT);

    digitalWrite(SIM_RST_PIN, LOW);
    delay(200);
    digitalWrite(SIM_RST_PIN, HIGH);

    Serial.println("STATUS:SIM800L_RST_PULSE_DONE");

    delay(5000);

    Serial.println("STATUS:SIM800L_BOOT_WAIT_DONE");
}

/* ========== SIM800L POWER ON AND INIT ========== */

boolean simPowerOn()
{
    Serial.println("STATUS:SIM800L_INIT_START");

    simHardwareReset();

    /* ---- Wait for auto-baud with up to 5 attempts ---- */

    boolean atOk = false;

    for (int retry = 0; retry < 5; retry++)
    {
        Serial.print("STATUS:SIM800L_AT_ATTEMPT=");
        Serial.println(retry + 1);

        ATResult res = send_at_command("AT", "OK", 2000);

        if (res == AT_SUCCESS)
        {
            atOk = true;
            Serial.println("STATUS:SIM800L_AT_OK");
            break;
        }

        Serial.println("STATUS:SIM800L_AT_NO_RESPONSE_RETRYING");
        delay(2000);
    }

    if (!atOk)
    {
        Serial.println("ERROR:SIM800L_UNRESPONSIVE");
        simInitFailCode = 1;
        return false;
    }

    /* ---- Auto-baud sync: send AT a few more times ---- */

    send_at_command("AT", "OK", 1000);
    send_at_command("AT", "OK", 1000);

    /* ---- Echo off ---- */

    ATResult res = send_at_command("ATE0", "OK", 2000);
    if (res == AT_SUCCESS)
    {
        Serial.println("STATUS:SIM800L_ECHO_OFF_OK");
    }
    else
    {
        Serial.println("WARNING:SIM800L_ECHO_OFF_FAIL");
    }

    /* ---- SMS text mode ---- */

    res = send_at_command("AT+CMGF=1", "OK", 2000);
    if (res == AT_SUCCESS)
    {
        Serial.println("STATUS:SIM800L_SMS_MODE_OK");
    }
    else
    {
        Serial.println("WARNING:SIM800L_SMS_MODE_FAIL");
    }

    /* ---- SIM card check ---- */

    res = send_at_command("AT+CPIN?", "+CPIN: READY", 5000);
    if (res == AT_SUCCESS)
    {
        Serial.println("STATUS:SIM_CARD_READY");
        simReady = true;
    }
    else if (res == AT_TIMEOUT)
    {
        Serial.println("ERROR:SIM_CARD_TIMEOUT");
        simReady = false;
    }
    else
    {
        Serial.println("ERROR:SIM_CARD_NOT_READY");
        Serial.print("STATUS:SIM_RESPONSE=");
        Serial.println(simResponseBuffer);
        simReady = false;
    }

    /* ---- Get module info for debug ---- */

    res = send_at_command("ATI", "OK", 2000);
    if (res == AT_SUCCESS)
    {
        Serial.print("STATUS:SIM800L_INFO=");
        Serial.println(simResponseBuffer);
    }

    return true;
}

/* ========== SIM800L NETWORK REGISTRATION ========== */

boolean simWaitForNetwork()
{
    Serial.println("STATUS:SIM800L_WAITING_NETWORK");

    for (int attempt = 1; attempt <= 15; attempt++)
    {
        ATResult res = send_at_command("AT+CREG?", "+CREG:", 3000);

        if (res == AT_SUCCESS)
        {
            char* cregPos = strstr(simResponseBuffer, "+CREG:");

            if (cregPos != NULL)
            {
                char* commaPos = strchr(cregPos, ',');

                if (commaPos != NULL)
                {
                    int stat = atoi(commaPos + 1);

                    if (stat == 1 || stat == 5)
                    {
                        simRegistered = true;
                        Serial.print("STATUS:SIM800L_NETWORK_OK_ATTEMPT=");
                        Serial.println(attempt);

                        if (stat == 1)
                        {
                            Serial.println("STATUS:SIM800L_REG_HOME");
                        }
                        else
                        {
                            Serial.println("STATUS:SIM800L_REG_ROAMING");
                        }

                        return true;
                    }
                    else
                    {
                        Serial.print("STATUS:SIM800L_CREG_STAT=");
                        Serial.print(stat);
                        Serial.print("_ATTEMPT=");
                        Serial.println(attempt);
                    }
                }
            }
        }
        else
        {
            Serial.print("STATUS:SIM800L_CREG_FAIL_ATTEMPT=");
            Serial.println(attempt);
        }

        delay(2000);
    }

    Serial.println("ERROR:SIM800L_NO_NETWORK");
    simRegistered = false;
    simInitFailCode = 2;
    return false;
}

/* ========== SIM800L SIGNAL STRENGTH ========== */

int simGetSignalStrength()
{
    ATResult res = send_at_command("AT+CSQ", "+CSQ:", 3000);

    if (res == AT_SUCCESS)
    {
        char* csqPos = strstr(simResponseBuffer, "+CSQ:");

        if (csqPos != NULL)
        {
            int rssi = atoi(csqPos + 5);

            if (rssi >= 0 && rssi <= 31)
            {
                simSignalRSSI = rssi;
                return rssi;
            }
            else if (rssi == 99)
            {
                simSignalRSSI = 0;
                return 0;
            }
        }
    }

    return -1;
}

/* ========== SIM800L FULL INIT ========== */

void simFullInit()
{
    Serial.println("STATUS:SIM800L_FULL_INIT_BEGIN");

    simAvailable = false;
    simRegistered = false;
    simReady = false;
    simSignalRSSI = 0;
    simInitFailCode = 0;

    boolean powered = simPowerOn();

    if (!powered)
    {
        simAvailable = false;
        Serial.println("TX:FAIL:1");
        Serial.println("STATUS:SIM800L_INIT_FAILED_NO_RESPONSE");
        return;
    }

    simAvailable = true;

    if (!simReady)
    {
        Serial.println("WARNING:SIM800L_NO_SIM_CARD_DETECTED");
    }

    boolean registered = simWaitForNetwork();

    if (!registered)
    {
        Serial.println("TX:FAIL:2");
        Serial.println("STATUS:SIM800L_INIT_FAILED_NO_NETWORK");
    }

    int rssi = simGetSignalStrength();

    if (rssi >= 0)
    {
        Serial.print("STATUS:SIM800L_SIGNAL_RSSI=");
        Serial.println(rssi);
        Serial.print("SIGNAL:");
        Serial.println(rssi);

        int dbm = -113 + (rssi * 2);
        Serial.print("STATUS:SIM800L_SIGNAL_DBM=");
        Serial.println(dbm);

        if (rssi < 2)
        {
            Serial.println("STATUS:SIM800L_SIGNAL_NONE");
        }
        else if (rssi < 10)
        {
            Serial.println("STATUS:SIM800L_SIGNAL_MARGINAL");
        }
        else if (rssi < 15)
        {
            Serial.println("STATUS:SIM800L_SIGNAL_OK");
        }
        else if (rssi < 20)
        {
            Serial.println("STATUS:SIM800L_SIGNAL_GOOD");
        }
        else
        {
            Serial.println("STATUS:SIM800L_SIGNAL_EXCELLENT");
        }
    }
    else
    {
        Serial.println("STATUS:SIM800L_SIGNAL_READ_FAIL");
        Serial.print("SIGNAL:");
        Serial.println(0);
    }

    /* ---- Set GSM charset ---- */

    send_at_command("AT+CSCS=\"GSM\"", "OK", 2000);

    /* ---- Delete old SMS ---- */

    send_at_command("AT+CMGDA=\"DEL ALL\"", "OK", 5000);

    Serial.println("STATUS:SIM800L_FULL_INIT_COMPLETE");
}

/* ========== SIM800L PERIODIC CHECKS ========== */

void simCheckSignalPeriodic()
{
    if (!simAvailable)
    {
        return;
    }

    int rssi = simGetSignalStrength();

    if (rssi >= 0)
    {
        Serial.print("STATUS:SIM800L_RSSI=");
        Serial.println(rssi);
    }
}

void simCheckRegistrationPeriodic()
{
    if (!simAvailable)
    {
        return;
    }

    ATResult res = send_at_command("AT+CREG?", "+CREG:", 3000);

    if (res == AT_SUCCESS)
    {
        char* cregPos = strstr(simResponseBuffer, "+CREG:");

        if (cregPos != NULL)
        {
            char* commaPos = strchr(cregPos, ',');

            if (commaPos != NULL)
            {
                int stat = atoi(commaPos + 1);
                boolean wasRegistered = simRegistered;

                if (stat == 1 || stat == 5)
                {
                    simRegistered = true;

                    if (!wasRegistered)
                    {
                        Serial.println("STATUS:SIM800L_NETWORK_RECOVERED");
                    }
                }
                else
                {
                    simRegistered = false;

                    if (wasRegistered)
                    {
                        Serial.print("STATUS:SIM800L_NETWORK_LOST_STAT=");
                        Serial.println(stat);
                    }
                }
            }
        }
    }
}

/* ========== SIM800L SEND SMS ========== */

boolean simSendSMS(const char* phoneNumber, const char* message)
{
    if (!simAvailable || !simRegistered)
    {
        Serial.println("STATUS:SMS_FAIL_NOT_READY");
        return false;
    }

    char cmdBuf[40];
    snprintf(cmdBuf, sizeof(cmdBuf), "AT+CMGS=\"%s\"", phoneNumber);

    simFlushInput();
    SIM_Serial.println(cmdBuf);

    unsigned long startWait = millis();
    boolean gotPrompt = false;

    while ((millis() - startWait) < 5000)
    {
        if (SIM_Serial.available())
        {
            char c = SIM_Serial.read();

            if (c == '>')
            {
                gotPrompt = true;
                break;
            }
        }
        delay(10);
    }

    if (!gotPrompt)
    {
        Serial.println("STATUS:SMS_NO_PROMPT");
        SIM_Serial.write(0x1B);
        delay(1000);
        simFlushInput();
        return false;
    }

    SIM_Serial.print(message);
    delay(100);
    SIM_Serial.write(0x1A);

    unsigned long smsStart = millis();
    int respIdx = 0;
    memset(simResponseBuffer, 0, SIM_RESPONSE_SIZE);

    while ((millis() - smsStart) < 30000)
    {
        while (SIM_Serial.available())
        {
            char c = SIM_Serial.read();

            if (respIdx < SIM_RESPONSE_SIZE - 1)
            {
                simResponseBuffer[respIdx++] = c;
                simResponseBuffer[respIdx] = '\0';
            }

            if (strstr(simResponseBuffer, "+CMGS:") != NULL)
            {
                Serial.println("STATUS:SMS_SENT_OK");
                return true;
            }

            if (strstr(simResponseBuffer, "ERROR") != NULL)
            {
                Serial.println("STATUS:SMS_SEND_ERROR");
                return false;
            }
        }
        delay(100);
    }

    Serial.println("STATUS:SMS_SEND_TIMEOUT");
    return false;
}

/* ========== RATE OF CHANGE FUNCTION ========== */

void calculateRateOfChange(float currentHeight, uint32_t currentTime)
{
    if (prevReadingTime == 0 || currentTime == 0 || currentTime <= prevReadingTime)
    {
        prevReadingTime = currentTime;
        prevWaterHeight = currentHeight;
        rateOfChange = 0;
        ratePer15Min = 0;
        return;
    }

    uint32_t elapsed = currentTime - prevReadingTime;
    if (elapsed < 1)
    {
        elapsed = 1;
    }

    float change = currentHeight - prevWaterHeight;
    rateOfChange = change / (float)elapsed;
    ratePer15Min = change * (900.0 / (float)elapsed);

    if (ratePer15Min > 10.0)
    {
        floodAlertLevel = 3;
    }
    else if (ratePer15Min > 5.0)
    {
        floodAlertLevel = 2;
    }
    else if (ratePer15Min > 2.0)
    {
        floodAlertLevel = 1;
    }
    else
    {
        floodAlertLevel = 0;
    }

    prevReadingTime = currentTime;
    prevWaterHeight = currentHeight;
}

/* ========== DATA LOG FUNCTIONS ========== */

void logReading(float height, float thetaVal, float press, uint32_t timestamp)
{
    logHeight[logIndex] = height;
    logTheta[logIndex] = thetaVal;
    logPressure[logIndex] = press;
    logTime[logIndex] = timestamp;
    logIndex = (logIndex + 1) % LOG_SIZE;
    if (logCount < LOG_SIZE)
    {
        logCount++;
    }

    if (height > peakHeight)
    {
        peakHeight = height;
        peakTime = timestamp;
    }
    if (height < minHeight)
    {
        minHeight = height;
        minTime = timestamp;
    }
}

void dumpLog()
{
    Serial.println("LOG:START");
    Serial.println("LOG:UNIX,DATE_TIME,THETA,HEIGHT,PRESSURE,LAT,LON");

    int count = min(logCount, LOG_SIZE);
    int start = (logCount >= LOG_SIZE) ? logIndex : 0;

    for (int i = 0; i < count; i++)
    {
        int idx = (start + i) % LOG_SIZE;
        uint16_t y;
        uint8_t mo, d, h, mi, s, dow;
        unixToDate(logTime[idx], &y, &mo, &d, &h, &mi, &s, &dow);

        Serial.print("LOG:");
        Serial.print(logTime[idx]);
        Serial.print(",");
        Serial.print(y);
        Serial.print("-");
        if (mo < 10) Serial.print("0");
        Serial.print(mo);
        Serial.print("-");
        if (d < 10) Serial.print("0");
        Serial.print(d);
        Serial.print(" ");
        if (h < 10) Serial.print("0");
        Serial.print(h);
        Serial.print(":");
        if (mi < 10) Serial.print("0");
        Serial.print(mi);
        Serial.print(":");
        if (s < 10) Serial.print("0");
        Serial.print(s);
        Serial.print(",");
        Serial.print(logTheta[idx], 2);
        Serial.print(",");
        Serial.print(logHeight[idx], 2);
        Serial.print(",");
        Serial.print(logPressure[idx], 2);
        Serial.print(",");
        Serial.print(gpsLat, 6);
        Serial.print(",");
        Serial.println(gpsLon, 6);
    }

    Serial.print("LOG:PEAK_HEIGHT=");
    Serial.print(peakHeight, 2);
    Serial.print(",PEAK_TIME=");
    Serial.println(peakTime);
    Serial.print("LOG:MIN_HEIGHT=");
    Serial.print(minHeight, 2);
    Serial.print(",MIN_TIME=");
    Serial.println(minTime);
    Serial.print("LOG:TOTAL_READINGS=");
    Serial.println(logCount);
    Serial.println("LOG:END");
}

/* ========== MPU6050 FUNCTIONS ========== */

void mpuWriteReg(uint8_t reg, uint8_t val)
{
    I2C_BUS0.beginTransmission(MPU6050_ADDR);
    I2C_BUS0.write(reg);
    I2C_BUS0.write(val);
    I2C_BUS0.endTransmission();
}

uint8_t mpuReadReg(uint8_t reg)
{
    I2C_BUS0.beginTransmission(MPU6050_ADDR);
    I2C_BUS0.write(reg);
    I2C_BUS0.endTransmission(false);
    I2C_BUS0.requestFrom((uint8_t)MPU6050_ADDR, (uint8_t)1);
    return I2C_BUS0.read();
}

void readMPU()
{
    I2C_BUS0.beginTransmission(MPU6050_ADDR);
    I2C_BUS0.write(0x3B);
    I2C_BUS0.endTransmission(false);
    I2C_BUS0.requestFrom((uint8_t)MPU6050_ADDR, (uint8_t)14);

    accX  = (int16_t)(I2C_BUS0.read() << 8 | I2C_BUS0.read());
    accY  = (int16_t)(I2C_BUS0.read() << 8 | I2C_BUS0.read());
    accZ  = (int16_t)(I2C_BUS0.read() << 8 | I2C_BUS0.read());
    I2C_BUS0.read();
    I2C_BUS0.read();
    gyroX = (int16_t)(I2C_BUS0.read() << 8 | I2C_BUS0.read());
    gyroY = (int16_t)(I2C_BUS0.read() << 8 | I2C_BUS0.read());
    gyroZ = (int16_t)(I2C_BUS0.read() << 8 | I2C_BUS0.read());
}

/* ========== BMP280 FUNCTIONS ========== */

uint8_t bmpRead8(uint8_t reg)
{
    I2C_BUS1.beginTransmission(BMP280_ADDR);
    I2C_BUS1.write(reg);
    I2C_BUS1.endTransmission(false);
    I2C_BUS1.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)1);
    return I2C_BUS1.read();
}

uint16_t bmpRead16LE(uint8_t reg)
{
    I2C_BUS1.beginTransmission(BMP280_ADDR);
    I2C_BUS1.write(reg);
    I2C_BUS1.endTransmission(false);
    I2C_BUS1.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)2);
    uint16_t val = I2C_BUS1.read();
    val |= (uint16_t)I2C_BUS1.read() << 8;
    return val;
}

int16_t bmpReadS16LE(uint8_t reg)
{
    return (int16_t)bmpRead16LE(reg);
}

void bmpWrite8(uint8_t reg, uint8_t val)
{
    I2C_BUS1.beginTransmission(BMP280_ADDR);
    I2C_BUS1.write(reg);
    I2C_BUS1.write(val);
    I2C_BUS1.endTransmission();
}

boolean initBMP280()
{
    uint8_t chipId = bmpRead8(0xD0);
    Serial.print("STATUS:BMP_CHIP_ID=0x");
    Serial.println(chipId, HEX);

    if (chipId != 0x58 && chipId != 0x56 && chipId != 0x57)
    {
        return false;
    }

    bmpDigT1 = bmpRead16LE(0x88);
    bmpDigT2 = bmpReadS16LE(0x8A);
    bmpDigT3 = bmpReadS16LE(0x8C);
    bmpDigP1 = bmpRead16LE(0x8E);
    bmpDigP2 = bmpReadS16LE(0x90);
    bmpDigP3 = bmpReadS16LE(0x92);
    bmpDigP4 = bmpReadS16LE(0x94);
    bmpDigP5 = bmpReadS16LE(0x96);
    bmpDigP6 = bmpReadS16LE(0x98);
    bmpDigP7 = bmpReadS16LE(0x9A);
    bmpDigP8 = bmpReadS16LE(0x9C);
    bmpDigP9 = bmpReadS16LE(0x9E);

    bmpWrite8(0xF4, 0x27);
    bmpWrite8(0xF5, 0xA0);

    delay(100);

    return true;
}

void bmpReadData(float *temperature, float *pressure)
{
    I2C_BUS1.beginTransmission(BMP280_ADDR);
    I2C_BUS1.write(0xF7);
    I2C_BUS1.endTransmission(false);
    I2C_BUS1.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)6);

    uint32_t pressRaw = (uint32_t)I2C_BUS1.read() << 12;
    pressRaw |= (uint32_t)I2C_BUS1.read() << 4;
    pressRaw |= (uint32_t)I2C_BUS1.read() >> 4;

    uint32_t tempRaw = (uint32_t)I2C_BUS1.read() << 12;
    tempRaw |= (uint32_t)I2C_BUS1.read() << 4;
    tempRaw |= (uint32_t)I2C_BUS1.read() >> 4;

    int32_t var1, var2;

    var1 = ((((int32_t)tempRaw >> 3) - ((int32_t)bmpDigT1 << 1)) * ((int32_t)bmpDigT2)) >> 11;
    var2 = (((((int32_t)tempRaw >> 4) - ((int32_t)bmpDigT1)) * (((int32_t)tempRaw >> 4) - ((int32_t)bmpDigT1))) >> 12) * ((int32_t)bmpDigT3) >> 14;
    bmpTFine = var1 + var2;

    *temperature = (float)((bmpTFine * 5 + 128) >> 8) / 100.0;

    int64_t p_var1, p_var2, p;

    p_var1 = ((int64_t)bmpTFine) - 128000;
    p_var2 = p_var1 * p_var1 * (int64_t)bmpDigP6;
    p_var2 = p_var2 + ((p_var1 * (int64_t)bmpDigP5) << 17);
    p_var2 = p_var2 + (((int64_t)bmpDigP4) << 35);
    p_var1 = ((p_var1 * p_var1 * (int64_t)bmpDigP3) >> 8) + ((p_var1 * (int64_t)bmpDigP2) << 12);
    p_var1 = (((((int64_t)1) << 47) + p_var1)) * ((int64_t)bmpDigP1) >> 33;

    if (p_var1 == 0)
    {
        *pressure = 0;
        return;
    }

    p = 1048576 - (int64_t)pressRaw;
    p = (((p << 31) - p_var2) * 3125) / p_var1;
    p_var1 = (((int64_t)bmpDigP9) * (p >> 13) * (p >> 13)) >> 25;
    p_var2 = (((int64_t)bmpDigP8) * p) >> 19;
    p = ((p + p_var1 + p_var2) >> 8) + (((int64_t)bmpDigP7) << 4);

    *pressure = (float)((uint32_t)p) / 25600.0;
}

/* ========== BASELINE AND SUBMERSION ========== */

void updateBaseline(float press)
{
    if (press < 300 || press > 1200)
    {
        return;
    }

    if (baselineCount >= BASELINE_SIZE)
    {
        baselineSum -= baselineBuffer[baselineIndex];
    }

    baselineBuffer[baselineIndex] = press;
    baselineSum += press;
    baselineIndex = (baselineIndex + 1) % BASELINE_SIZE;
    if (baselineCount < BASELINE_SIZE)
    {
        baselineCount++;
    }

    baselinePressure = baselineSum / baselineCount;
}

int evaluateSubmersion(float press, float base)
{
    if (press < 300 || press > 1200 || press < 0)
    {
        return -1;
    }

    if (press > 1100)
    {
        return 4;
    }

    float dev = press - base;
    pressureDeviation = dev;

    if (dev > 15)
    {
        estimatedDepth = dev / 0.981;
        return 3;
    }
    else if (dev > 8)
    {
        estimatedDepth = dev / 0.981;
        return 2;
    }
    else if (dev > 5)
    {
        estimatedDepth = 0;
        return 1;
    }
    else
    {
        estimatedDepth = 0;
        return 0;
    }
}

/* ========== SERIAL INPUT HANDLER ========== */

void checkSerialInput()
{
    while (Serial.available())
    {
        char c = Serial.read();
        if (c == '\n' || c == '\r')
        {
            inputBuffer.trim();

            if (inputBuffer.startsWith("OLP:"))
            {
                float val = inputBuffer.substring(4).toFloat();
                if (val > 0 && val < 10000)
                {
                    olpLength = val;
                }
            }
            else if (inputBuffer == "CAL")
            {
                recalibrate();
            }
            else if (inputBuffer == "DUMP")
            {
                dumpLog();
            }
            else if (inputBuffer.startsWith("TIME:"))
            {
                uint32_t ts = strtoul(inputBuffer.substring(5).c_str(), NULL, 10);
                if (ts > 1700000000UL)
                {
                    rtcSetUnixTime(ts);
                    rtcReadRaw();
                    rtcTimeValid = rtcIsTimeValid();
                    Serial.print("STATUS:RTC_SET=");
                    Serial.println(ts);
                }
            }
            else if (inputBuffer.startsWith("SETDATE:"))
            {
                int yr, mo, dy, hr, mi, sc;
                int parsed = sscanf(inputBuffer.c_str(), "SETDATE:%d-%d-%d %d:%d:%d", &yr, &mo, &dy, &hr, &mi, &sc);
                if (parsed == 6 && yr >= 2024 && mo >= 1 && mo <= 12 && dy >= 1 && dy <= 31)
                {
                    rtcSetDateTime(yr, mo, dy, hr, mi, sc);
                    rtcReadRaw();
                    rtcTimeValid = rtcIsTimeValid();
                    Serial.print("STATUS:RTC_SET_DATE=");
                    Serial.print(yr);
                    Serial.print("-");
                    Serial.print(mo);
                    Serial.print("-");
                    Serial.print(dy);
                    Serial.print(" ");
                    Serial.print(hr);
                    Serial.print(":");
                    Serial.print(mi);
                    Serial.print(":");
                    Serial.println(sc);
                }
            }
            else if (inputBuffer.startsWith("SMS:"))
            {
                int firstColon = inputBuffer.indexOf(':', 4);
                if (firstColon > 4)
                {
                    String phone = inputBuffer.substring(4, firstColon);
                    String msg = inputBuffer.substring(firstColon + 1);
                    Serial.print("STATUS:SMS_SENDING_TO=");
                    Serial.println(phone);
                    boolean sent = simSendSMS(phone.c_str(), msg.c_str());
                    if (sent)
                    {
                        Serial.println("STATUS:SMS_DELIVERED");
                    }
                    else
                    {
                        Serial.println("STATUS:SMS_FAILED");
                    }
                }
            }
            else if (inputBuffer == "SIMSTATUS")
            {
                Serial.print("STATUS:SIM_AVAILABLE=");
                Serial.println(simAvailable ? 1 : 0);
                Serial.print("STATUS:SIM_REGISTERED=");
                Serial.println(simRegistered ? 1 : 0);
                Serial.print("STATUS:SIM_READY=");
                Serial.println(simReady ? 1 : 0);
                Serial.print("STATUS:SIM_RSSI=");
                Serial.println(simSignalRSSI);
                Serial.print("STATUS:SIM_FAIL_CODE=");
                Serial.println(simInitFailCode);
            }
            else if (inputBuffer == "SIMREINIT")
            {
                simFullInit();
            }
            else if (inputBuffer == "SIMSIGNAL")
            {
                int rssi = simGetSignalStrength();
                Serial.print("SIGNAL:");
                Serial.println(rssi >= 0 ? rssi : 0);
            }
            else if (inputBuffer == "SIMRESET")
            {
                simHardwareReset();
                Serial.println("STATUS:SIM800L_RESET_DONE");
            }

            inputBuffer = "";
        }
        else
        {
            inputBuffer += c;
        }
    }
}

/* ========== RECALIBRATE ========== */

void recalibrate()
{
    Serial.println("STATUS:RECALIBRATING");

    float sumGX = 0, sumGY = 0;
    for (int i = 0; i < 300; i++)
    {
        readMPU();
        sumGX += gyroX;
        sumGY += gyroY;
        delay(2);
    }
    gyroOffsetX = sumGX / 300.0;
    gyroOffsetY = sumGY / 300.0;

    float sumAX = 0, sumAY = 0, sumAZ = 0;
    int count = 0;
    for (int i = 0; i < 300; i++)
    {
        readMPU();
        float ax = accX / 16384.0;
        float ay = accY / 16384.0;
        float az = accZ / 16384.0;

        float totalG = sqrt(ax * ax + ay * ay + az * az);
        if (totalG > 0.9 && totalG < 1.1)
        {
            sumAX += ax;
            sumAY += ay;
            sumAZ += az;
            count++;
        }
        delay(2);
    }

    if (count > 50)
    {
        refAccX = sumAX / count;
        refAccY = sumAY / count;
        refAccZ = sumAZ / count;
    }

    refTiltX = atan2(refAccY, refAccZ) * 180.0 / PI;
    refTiltY = atan2(refAccX, refAccZ) * 180.0 / PI;

    filtTiltX = refTiltX;
    filtTiltY = refTiltY;

    Serial.print("STATUS:NEW_REF_TILTX=");
    Serial.println(refTiltX, 2);
    Serial.print("STATUS:NEW_REF_TILTY=");
    Serial.println(refTiltY, 2);
    Serial.println("STATUS:RECALIBRATED_ZERO");
}

/* ========== SETUP ========== */

void setup()
{
    Serial.begin(9600);
    pinMode(LED_PIN, OUTPUT);

    I2C_BUS0.begin(BUS0_SDA, BUS0_SCL, 100000);
    I2C_BUS1.begin(BUS1_SDA, BUS1_SCL, 100000);
    GPS_Serial.begin(9600, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);
    SIM_Serial.begin(9600, SERIAL_8N1, SIM_RX_PIN, SIM_TX_PIN);

    delay(200);

    /* ---- RTC INIT ---- */

    rtcAvailable = rtcInit();
    if (rtcAvailable)
    {
        Serial.println("STATUS:DS1307_OK");
        rtcReadRaw();
        rtcTimeValid = rtcIsTimeValid();

        if (rtcTimeValid)
        {
            currentUnixTime = rtcGetUnixTime();
            bootUnixTime = currentUnixTime;
            sessionStartUnix = currentUnixTime;
            prevReadingTime = currentUnixTime;

            Serial.print("STATUS:RTC_TIME=");
            Serial.print(rtcYear);
            Serial.print("-");
            if (rtcMonth < 10) Serial.print("0");
            Serial.print(rtcMonth);
            Serial.print("-");
            if (rtcDay < 10) Serial.print("0");
            Serial.print(rtcDay);
            Serial.print(" ");
            if (rtcHours < 10) Serial.print("0");
            Serial.print(rtcHours);
            Serial.print(":");
            if (rtcMinutes < 10) Serial.print("0");
            Serial.print(rtcMinutes);
            Serial.print(":");
            if (rtcSeconds < 10) Serial.print("0");
            Serial.println(rtcSeconds);
            Serial.print("STATUS:BOOT_UNIX=");
            Serial.println(bootUnixTime);
        }
        else
        {
            Serial.println("STATUS:RTC_TIME_INVALID_SETTING_DEFAULT");
            rtcSetDateTime(2026, 2, 24, 0, 0, 0);
            rtcReadRaw();
            rtcTimeValid = rtcIsTimeValid();
            currentUnixTime = rtcGetUnixTime();
            bootUnixTime = currentUnixTime;
            sessionStartUnix = currentUnixTime;
            prevReadingTime = currentUnixTime;
            Serial.println("STATUS:RTC_SET_TO_2026-02-24");
        }
    }
    else
    {
        Serial.println("STATUS:DS1307_NOT_FOUND");
    }

    /* ---- MPU6050 INIT ---- */

    mpuWriteReg(0x6B, 0x00);
    delay(100);
    mpuWriteReg(0x19, 0x07);
    mpuWriteReg(0x1A, 0x03);
    mpuWriteReg(0x1B, 0x00);
    mpuWriteReg(0x1C, 0x00);
    delay(100);

    uint8_t who = mpuReadReg(0x75);
    Serial.print("STATUS:MPU_WHO_AM_I=0x");
    Serial.println(who, HEX);
    if (who != 0x68)
    {
        Serial.println("ERROR:MPU6050_NOT_FOUND");
        while (1)
        {
            digitalWrite(LED_PIN, !digitalRead(LED_PIN));
            delay(200);
        }
    }
    Serial.println("STATUS:MPU6050_OK");

    /* ---- BMP280 INIT ---- */

    bmpAvailable = initBMP280();
    if (bmpAvailable)
    {
        Serial.println("STATUS:BMP280_OK");

        float initPressure = 0;
        float initTemp = 0;
        float pressSum = 0;
        int validReadings = 0;
        for (int i = 0; i < 10; i++)
        {
            bmpReadData(&initTemp, &initPressure);
            if (initPressure > 300 && initPressure < 1200)
            {
                pressSum += initPressure;
                validReadings++;
            }
            delay(100);
        }

        if (validReadings > 0)
        {
            float avgPress = pressSum / validReadings;
            for (int i = 0; i < BASELINE_SIZE; i++)
            {
                baselineBuffer[i] = avgPress;
            }
            baselineCount = BASELINE_SIZE;
            baselineSum = avgPress * BASELINE_SIZE;
            baselineIndex = 0;
            baselinePressure = avgPress;
            currentPressure = avgPress;
            currentTemperature = initTemp;

            Serial.print("STATUS:BASELINE_INIT=");
            Serial.println(avgPress, 2);
        }
    }
    else
    {
        Serial.println("STATUS:BMP280_NOT_FOUND");
    }

    /* ---- GPS STATUS ---- */

    Serial.println("STATUS:GPS_UART_INIT");

    /* ---- SIM800L INIT ---- */

    simFullInit();

    /* ---- MPU6050 CALIBRATION ---- */

    Serial.println("STATUS:CALIBRATING");
    Serial.println("STATUS:KEEP_BUOY_LEVEL_AND_STILL");

    for (int i = 0; i < 6; i++)
    {
        digitalWrite(LED_PIN, HIGH);
        delay(250);
        digitalWrite(LED_PIN, LOW);
        delay(250);
    }

    Serial.println("STATUS:CALIBRATING_GYRO");
    float sumGX = 0, sumGY = 0, sumGZ = 0;
    for (int i = 0; i < 1000; i++)
    {
        readMPU();
        sumGX += gyroX;
        sumGY += gyroY;
        sumGZ += gyroZ;
        delay(2);
    }
    gyroOffsetX = sumGX / 1000.0;
    gyroOffsetY = sumGY / 1000.0;
    gyroOffsetZ = sumGZ / 1000.0;

    Serial.println("STATUS:CALIBRATING_REFERENCE");

    float sumAX = 0, sumAY = 0, sumAZ = 0;
    int validCount = 0;

    for (int i = 0; i < 500; i++)
    {
        readMPU();

        float ax = accX / 16384.0;
        float ay = accY / 16384.0;
        float az = accZ / 16384.0;

        float totalG = sqrt(ax * ax + ay * ay + az * az);
        if (totalG > 0.9 && totalG < 1.1)
        {
            sumAX += ax;
            sumAY += ay;
            sumAZ += az;
            validCount++;
        }
        delay(3);
    }

    if (validCount > 100)
    {
        refAccX = sumAX / validCount;
        refAccY = sumAY / validCount;
        refAccZ = sumAZ / validCount;
    }
    else
    {
        readMPU();
        refAccX = accX / 16384.0;
        refAccY = accY / 16384.0;
        refAccZ = accZ / 16384.0;
    }

    refTiltX = atan2(refAccY, refAccZ) * 180.0 / PI;
    refTiltY = atan2(refAccX, refAccZ) * 180.0 / PI;

    filtTiltX = refTiltX;
    filtTiltY = refTiltY;

    prevTime = millis();
    lastBaselineUpdate = millis();
    lastBmpRead = millis();
    lastRtcRead = millis();
    lastLogWrite = millis();
    lastGpsProcess = millis();
    lastSimSignalCheck = millis();
    lastSimRegistrationCheck = millis();

    prevWaterHeight = olpLength;

    digitalWrite(LED_PIN, HIGH);

    Serial.print("STATUS:REF_GRAVITY=");
    Serial.print(refAccX, 3);
    Serial.print(",");
    Serial.print(refAccY, 3);
    Serial.print(",");
    Serial.println(refAccZ, 3);
    Serial.print("STATUS:REF_TILTX=");
    Serial.println(refTiltX, 2);
    Serial.print("STATUS:REF_TILTY=");
    Serial.println(refTiltY, 2);
    Serial.println("STATUS:CALIBRATION_DONE");
    Serial.println("STATUS:ANGLE_IS_NOW_ZERO");
    Serial.println("STATUS:READY");
    delay(500);
}

/* ========== MAIN LOOP ========== */

void loop()
{
    checkSerialInput();
    readGPS();
    readMPU();

    unsigned long now = millis();
    float dt = (now - prevTime) / 1000.0;
    prevTime = now;
    if (dt <= 0 || dt > 0.5)
    {
        dt = 0.008;
    }

    /* ---- RTC UPDATE ---- */

    if (rtcAvailable && (now - lastRtcRead >= RTC_READ_INTERVAL))
    {
        lastRtcRead = now;
        currentUnixTime = rtcGetUnixTime();
        rtcTimeValid = rtcIsTimeValid();
        if (currentUnixTime > 0 && sessionStartUnix > 0)
        {
            sessionDuration = currentUnixTime - sessionStartUnix;
        }
    }

    /* ---- GPS TO RTC SYNC ---- */

    if (gpsTimeValid && !gpsTimeSynced && rtcAvailable)
    {
        syncRTCfromGPS();
    }

    /* ---- SIM800L PERIODIC SIGNAL CHECK ---- */

    if (simAvailable && (now - lastSimSignalCheck >= SIM_SIGNAL_INTERVAL))
    {
        lastSimSignalCheck = now;
        simCheckSignalPeriodic();
    }

    /* ---- SIM800L PERIODIC REGISTRATION CHECK ---- */

    if (simAvailable && (now - lastSimRegistrationCheck >= SIM_REG_CHECK_INTERVAL))
    {
        lastSimRegistrationCheck = now;
        simCheckRegistrationPeriodic();
    }

    /* ---- TILT CALCULATION ---- */

    float ax = accX / 16384.0;
    float ay = accY / 16384.0;
    float az = accZ / 16384.0;

    float gx = (gyroX - gyroOffsetX) / 131.0;
    float gy = (gyroY - gyroOffsetY) / 131.0;

    float accTiltX = atan2(ay, az) * 180.0 / PI;
    float accTiltY = atan2(ax, az) * 180.0 / PI;

    filtTiltX = ALPHA * (filtTiltX + gx * dt) + (1.0 - ALPHA) * accTiltX;
    filtTiltY = ALPHA * (filtTiltY + gy * dt) + (1.0 - ALPHA) * accTiltY;

    float correctedTiltX = filtTiltX - refTiltX;
    float correctedTiltY = filtTiltY - refTiltY;

    float theta = sqrt(correctedTiltX * correctedTiltX + correctedTiltY * correctedTiltY);

    if (theta > 90.0)
    {
        theta = 90.0;
    }
    if (theta < 0.0)
    {
        theta = 0.0;
    }

    float thetaRad = theta * PI / 180.0;

    /* ---- WATER HEIGHT CALCULATION ---- */

    float waterHeight = olpLength * cos(thetaRad);
    float horizontalDist = olpLength * sin(thetaRad);

    /* ---- BMP280 PRESSURE UPDATE ---- */

    if (bmpAvailable && (now - lastBmpRead >= BMP_READ_INTERVAL))
    {
        lastBmpRead = now;
        float temp, press;
        bmpReadData(&temp, &press);

        if (press > 300 && press < 1200)
        {
            currentPressure = press;
            currentTemperature = temp;
            submersionState = evaluateSubmersion(press, baselinePressure);

            if (submersionState == 0 && (now - lastBaselineUpdate >= BASELINE_INTERVAL))
            {
                lastBaselineUpdate = now;
                updateBaseline(press);
            }
        }
        else if (press < 300 || press > 1200)
        {
            submersionState = -1;
        }
    }

    /* ---- RATE OF CHANGE ---- */

    if (rtcTimeValid && currentUnixTime > 0)
    {
        calculateRateOfChange(waterHeight, currentUnixTime);
    }

    /* ---- DATA LOGGING ---- */

    if (now - lastLogWrite >= LOG_INTERVAL)
    {
        lastLogWrite = now;
        logReading(waterHeight, theta, currentPressure, currentUnixTime);
    }

    /* ---- SERIAL OUTPUT: 29 CSV FIELDS ---- */

    Serial.print(theta, 2);                                     /* 1  */
    Serial.print(",");
    Serial.print(waterHeight, 2);                               /* 2  */
    Serial.print(",");
    Serial.print(correctedTiltX, 2);                            /* 3  */
    Serial.print(",");
    Serial.print(correctedTiltY, 2);                            /* 4  */
    Serial.print(",");
    Serial.print(olpLength, 2);                                 /* 5  */
    Serial.print(",");
    Serial.print(horizontalDist, 2);                            /* 6  */
    Serial.print(",");
    Serial.print(currentPressure, 2);                           /* 7  */
    Serial.print(",");
    Serial.print(currentTemperature, 2);                        /* 8  */
    Serial.print(",");
    Serial.print(baselinePressure, 2);                          /* 9  */
    Serial.print(",");
    Serial.print(pressureDeviation, 2);                         /* 10 */
    Serial.print(",");
    Serial.print(submersionState);                              /* 11 */
    Serial.print(",");
    Serial.print(estimatedDepth, 2);                            /* 12 */
    Serial.print(",");
    Serial.print(bmpAvailable ? 1 : 0);                        /* 13 */
    Serial.print(",");
    Serial.print(currentUnixTime);                              /* 14 */
    Serial.print(",");
    Serial.print(rtcYear);                                      /* 15 */
    Serial.print("-");
    if (rtcMonth < 10) Serial.print("0");
    Serial.print(rtcMonth);
    Serial.print("-");
    if (rtcDay < 10) Serial.print("0");
    Serial.print(rtcDay);
    Serial.print(" ");
    if (rtcHours < 10) Serial.print("0");
    Serial.print(rtcHours);
    Serial.print(":");
    if (rtcMinutes < 10) Serial.print("0");
    Serial.print(rtcMinutes);
    Serial.print(":");
    if (rtcSeconds < 10) Serial.print("0");
    Serial.print(rtcSeconds);
    Serial.print(",");
    Serial.print(rtcAvailable && rtcTimeValid ? 1 : 0);        /* 16 */
    Serial.print(",");
    Serial.print(ratePer15Min, 3);                              /* 17 */
    Serial.print(",");
    Serial.print(floodAlertLevel);                              /* 18 */
    Serial.print(",");
    Serial.print(sessionDuration);                              /* 19 */
    Serial.print(",");
    Serial.print(peakHeight, 2);                                /* 20 */
    Serial.print(",");
    Serial.print(minHeight > 9000 ? 0.0 : minHeight, 2);       /* 21 */
    Serial.print(",");
    Serial.print(gpsLat, 6);                                    /* 22 */
    Serial.print(",");
    Serial.print(gpsLon, 6);                                    /* 23 */
    Serial.print(",");
    Serial.print(gpsAlt, 1);                                    /* 24 */
    Serial.print(",");
    Serial.print(gpsSatellites);                                /* 25 */
    Serial.print(",");
    Serial.print(gpsFixValid ? 1 : 0);                         /* 26 */
    Serial.print(",");
    Serial.print(simSignalRSSI);                                /* 27 */
    Serial.print(",");
    Serial.print(simRegistered ? 1 : 0);                       /* 28 */
    Serial.print(",");
    Serial.println(simAvailable ? 1 : 0);                      /* 29 */

    delay(50);
}
